CREATE TABLE public.anuncios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo text NOT NULL DEFAULT '',
  imagen_url text,
  tamano text NOT NULL DEFAULT 'mediano' CHECK (tamano IN ('chico', 'mediano', 'grande')),
  tiene_boton boolean NOT NULL DEFAULT false,
  boton_texto text NOT NULL DEFAULT '',
  destino_tipo text NOT NULL DEFAULT 'link' CHECK (destino_tipo IN ('producto', 'categoria', 'link')),
  destino text,
  activo boolean NOT NULL DEFAULT true,
  orden integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.anuncios TO anon, authenticated;
GRANT ALL ON public.anuncios TO service_role;
ALTER TABLE public.anuncios ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anuncios_all" ON public.anuncios FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER anuncios_touch_trg BEFORE UPDATE ON public.anuncios FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
ALTER TABLE public.anuncios REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.anuncios;