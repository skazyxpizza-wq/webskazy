-- Bucket público para imágenes del menú (productos, QR, logos y anuncios).
-- Ejecutar en Supabase > SQL Editor.
-- AVISO: mientras el panel no use autenticación real (Etapa 2 de seguridad),
-- la subida queda abierta a cualquier visitante; se limita por tamaño y tipo de archivo.
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('skazy', 'skazy', true, 5242880, ARRAY['image/webp', 'image/png', 'image/jpeg'])
ON CONFLICT (id) DO UPDATE
  SET public = true,
      file_size_limit = 5242880,
      allowed_mime_types = ARRAY['image/webp', 'image/png', 'image/jpeg'];

DROP POLICY IF EXISTS "skazy_lectura_publica" ON storage.objects;
DROP POLICY IF EXISTS "skazy_subida" ON storage.objects;
DROP POLICY IF EXISTS "skazy_borrado" ON storage.objects;

CREATE POLICY "skazy_lectura_publica" ON storage.objects
  FOR SELECT USING (bucket_id = 'skazy');
CREATE POLICY "skazy_subida" ON storage.objects
  FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'skazy');
CREATE POLICY "skazy_borrado" ON storage.objects
  FOR DELETE TO anon, authenticated USING (bucket_id = 'skazy');
