-- ============ CATEGORIAS ============
CREATE TABLE public.categorias (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  orden integer NOT NULL DEFAULT 0,
  visible boolean NOT NULL DEFAULT true,
  logo_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.categorias TO anon, authenticated;
GRANT ALL ON public.categorias TO service_role;
ALTER TABLE public.categorias ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categorias_all" ON public.categorias FOR ALL USING (true) WITH CHECK (true);

-- ============ PRODUCTOS ============
CREATE TABLE public.productos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  categoria_id uuid REFERENCES public.categorias(id) ON DELETE SET NULL,
  nombre text NOT NULL,
  descripcion text DEFAULT '',
  precio numeric(12,2) NOT NULL DEFAULT 0,
  imagen_url text,
  imagen_hover_url text,
  orden integer NOT NULL DEFAULT 0,
  visible boolean NOT NULL DEFAULT true,
  agotado boolean NOT NULL DEFAULT false,
  destacado boolean NOT NULL DEFAULT false,
  mas_vendido boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.productos TO anon, authenticated;
GRANT ALL ON public.productos TO service_role;
ALTER TABLE public.productos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "productos_all" ON public.productos FOR ALL USING (true) WITH CHECK (true);

-- ============ CADETES ============
CREATE TABLE public.cadetes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  telefono text,
  activo boolean NOT NULL DEFAULT true,
  lat double precision,
  lng double precision,
  ubicacion_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cadetes TO anon, authenticated;
GRANT ALL ON public.cadetes TO service_role;
ALTER TABLE public.cadetes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cadetes_all" ON public.cadetes FOR ALL USING (true) WITH CHECK (true);

-- ============ CODIGOS DESCUENTO ============
CREATE TABLE public.codigos_descuento (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  codigo text NOT NULL UNIQUE,
  porcentaje numeric(5,2) NOT NULL DEFAULT 0,
  activo boolean NOT NULL DEFAULT true,
  expira_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.codigos_descuento TO anon, authenticated;
GRANT ALL ON public.codigos_descuento TO service_role;
ALTER TABLE public.codigos_descuento ENABLE ROW LEVEL SECURITY;
CREATE POLICY "codigos_all" ON public.codigos_descuento FOR ALL USING (true) WITH CHECK (true);

-- ============ PEDIDOS ============
CREATE TABLE public.pedidos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  codigo text NOT NULL UNIQUE,
  cliente_nombre text NOT NULL,
  telefono text NOT NULL,
  domicilio text NOT NULL,
  lat double precision,
  lng double precision,
  metodo_pago text NOT NULL DEFAULT 'EFECTIVO',
  paga_con numeric(12,2),
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  codigo_descuento text,
  descuento_porcentaje numeric(5,2) NOT NULL DEFAULT 0,
  monto_descuento numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  monto_recibido numeric(12,2),
  vuelto numeric(12,2),
  estado text NOT NULL DEFAULT 'CLIENTE',
  cadete_id uuid REFERENCES public.cadetes(id) ON DELETE SET NULL,
  grupo_codigo text,
  notas text,
  cancelado_motivo text,
  entregado_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.pedidos TO anon, authenticated;
GRANT ALL ON public.pedidos TO service_role;
ALTER TABLE public.pedidos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pedidos_all" ON public.pedidos FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX pedidos_estado_idx ON public.pedidos(estado);

-- ============ PEDIDO ITEMS ============
CREATE TABLE public.pedido_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id uuid NOT NULL REFERENCES public.pedidos(id) ON DELETE CASCADE,
  producto_id uuid REFERENCES public.productos(id) ON DELETE SET NULL,
  nombre text NOT NULL,
  cantidad integer NOT NULL DEFAULT 1,
  precio_unitario numeric(12,2) NOT NULL DEFAULT 0,
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.pedido_items TO anon, authenticated;
GRANT ALL ON public.pedido_items TO service_role;
ALTER TABLE public.pedido_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pedido_items_all" ON public.pedido_items FOR ALL USING (true) WITH CHECK (true);
CREATE INDEX pedido_items_pedido_idx ON public.pedido_items(pedido_id);

-- ============ STOCK ============
CREATE TABLE public.stock (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ingrediente text NOT NULL,
  disponible boolean NOT NULL DEFAULT true,
  aviso text,
  orden integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stock TO anon, authenticated;
GRANT ALL ON public.stock TO service_role;
ALTER TABLE public.stock ENABLE ROW LEVEL SECURITY;
CREATE POLICY "stock_all" ON public.stock FOR ALL USING (true) WITH CHECK (true);

-- ============ BANNERS ============
CREATE TABLE public.banners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  imagen_url text,
  titulo text DEFAULT '',
  titulo_tamano integer NOT NULL DEFAULT 24,
  descripcion text DEFAULT '',
  descripcion_tamano integer NOT NULL DEFAULT 14,
  banner_alto integer NOT NULL DEFAULT 180,
  activo boolean NOT NULL DEFAULT true,
  destino text,
  orden integer NOT NULL DEFAULT 0,
  expira_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.banners TO anon, authenticated;
GRANT ALL ON public.banners TO service_role;
ALTER TABLE public.banners ENABLE ROW LEVEL SECURITY;
CREATE POLICY "banners_all" ON public.banners FOR ALL USING (true) WITH CHECK (true);

-- ============ LOGOS CATEGORIA ============
CREATE TABLE public.logos_categoria (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  categoria_id uuid REFERENCES public.categorias(id) ON DELETE SET NULL,
  titulo text DEFAULT '',
  imagen_url text,
  orden integer NOT NULL DEFAULT 0,
  activo boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.logos_categoria TO anon, authenticated;
GRANT ALL ON public.logos_categoria TO service_role;
ALTER TABLE public.logos_categoria ENABLE ROW LEVEL SECURITY;
CREATE POLICY "logos_all" ON public.logos_categoria FOR ALL USING (true) WITH CHECK (true);

-- ============ CONFIGURACION GENERAL ============
CREATE TABLE public.configuracion_general (
  clave text PRIMARY KEY,
  valor jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.configuracion_general TO anon, authenticated;
GRANT ALL ON public.configuracion_general TO service_role;
ALTER TABLE public.configuracion_general ENABLE ROW LEVEL SECURITY;
CREATE POLICY "config_all" ON public.configuracion_general FOR ALL USING (true) WITH CHECK (true);

-- ============ ACCESOS SECTORES (contraseñas, no legibles) ============
CREATE TABLE public.accesos_sectores (
  sector text PRIMARY KEY,
  password text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.accesos_sectores TO service_role;
ALTER TABLE public.accesos_sectores ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.verificar_acceso(_sector text, _password text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.accesos_sectores WHERE sector = _sector AND password = _password);
$$;
GRANT EXECUTE ON FUNCTION public.verificar_acceso(text, text) TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.cambiar_acceso(_admin_password text, _sector text, _nueva text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.accesos_sectores WHERE sector = 'admin' AND password = _admin_password) THEN
    RETURN false;
  END IF;
  INSERT INTO public.accesos_sectores(sector, password) VALUES (_sector, _nueva)
  ON CONFLICT (sector) DO UPDATE SET password = EXCLUDED.password, updated_at = now();
  RETURN true;
END;
$$;
GRANT EXECUTE ON FUNCTION public.cambiar_acceso(text, text, text) TO anon, authenticated;

INSERT INTO public.accesos_sectores(sector, password) VALUES
  ('admin','Nereaaime8'), ('cocina','cocina2026'), ('envios','envios2026');

-- ============ CODIGO DE PEDIDO ============
CREATE SEQUENCE public.pedido_codigo_seq START 1;
GRANT USAGE, SELECT ON SEQUENCE public.pedido_codigo_seq TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.set_pedido_codigo()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.codigo IS NULL OR NEW.codigo = '' THEN
    NEW.codigo := '#' || lpad(nextval('public.pedido_codigo_seq')::text, 4, '0');
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;
CREATE TRIGGER pedidos_codigo_trg BEFORE INSERT ON public.pedidos
FOR EACH ROW EXECUTE FUNCTION public.set_pedido_codigo();

CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END;
$$;
CREATE TRIGGER pedidos_touch_trg BEFORE UPDATE ON public.pedidos
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ============ REALTIME ============
ALTER TABLE public.pedidos REPLICA IDENTITY FULL;
ALTER TABLE public.pedido_items REPLICA IDENTITY FULL;
ALTER TABLE public.cadetes REPLICA IDENTITY FULL;
ALTER TABLE public.stock REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.pedidos;
ALTER PUBLICATION supabase_realtime ADD TABLE public.pedido_items;
ALTER PUBLICATION supabase_realtime ADD TABLE public.cadetes;
ALTER PUBLICATION supabase_realtime ADD TABLE public.stock;
ALTER PUBLICATION supabase_realtime ADD TABLE public.productos;
ALTER PUBLICATION supabase_realtime ADD TABLE public.categorias;
ALTER PUBLICATION supabase_realtime ADD TABLE public.configuracion_general;

-- ============ DATOS INICIALES ============
INSERT INTO public.categorias (nombre, orden) VALUES
  ('Promos', 1), ('Combos', 2), ('Pizzas', 3), ('Empanadas', 4), ('Resto', 5);

INSERT INTO public.productos (categoria_id, nombre, descripcion, precio, orden, destacado, mas_vendido)
SELECT c.id, p.nombre, p.descripcion, p.precio, p.orden, p.destacado, p.mas_vendido
FROM public.categorias c
JOIN (VALUES
  ('Promos','Promo 2x1 Pizza Muzzarella','Dos pizzas grandes de muzzarella',18000,1,true,true),
  ('Promos','Promo Familiar','Pizza grande + 12 empanadas + gaseosa 1.5L',26000,2,true,false),
  ('Combos','Combo Individual','Pizza chica + 3 empanadas + bebida',9500,1,false,true),
  ('Combos','Combo Pareja','2 pizzas chicas + 6 empanadas',15000,2,false,false),
  ('Pizzas','Pizza Muzzarella','Salsa de tomate, muzzarella y oregano',10000,1,false,true),
  ('Pizzas','Pizza Napolitana','Muzzarella, tomate en rodajas y ajo',11500,2,false,false),
  ('Pizzas','Pizza Especial','Muzzarella, jamon y morron',12500,3,true,false),
  ('Empanadas','Empanada de Carne','Carne cortada a cuchillo',1400,1,false,true),
  ('Empanadas','Empanada de Pollo','Pollo con verdeo',1400,2,false,false),
  ('Empanadas','Empanada de Jamon y Queso','Clasica',1400,3,false,false),
  ('Resto','Gaseosa 1.5L','Linea Coca-Cola',3000,1,false,false),
  ('Resto','Agua Mineral 500ml','Sin gas',1500,2,false,false)
) AS p(cat, nombre, descripcion, precio, orden, destacado, mas_vendido) ON p.cat = c.nombre;

INSERT INTO public.logos_categoria (categoria_id, titulo, orden)
SELECT id, nombre, orden FROM public.categorias;

INSERT INTO public.codigos_descuento (codigo, porcentaje, activo) VALUES
  ('SKAZY40', 40, true), ('SKAZY10', 10, true);

INSERT INTO public.stock (ingrediente, disponible, aviso, orden) VALUES
  ('Muzzarella', true, null, 1),
  ('Harina', true, null, 2),
  ('Carne picada', true, null, 3),
  ('Salsa de tomate', true, null, 4),
  ('Gaseosas', true, null, 5);

INSERT INTO public.banners (titulo, descripcion, activo, orden) VALUES
  ('2x1 EN PIZZAS', 'Solo por hoy, aprovechalo antes de que se termine', true, 1);

INSERT INTO public.cadetes (nombre, telefono, activo) VALUES
  ('Cadete 1', '3810000001', true), ('Cadete 2', '3810000002', true);

INSERT INTO public.configuracion_general (clave, valor) VALUES
('general', jsonb_build_object(
  'nombre_local','SKAZY',
  'whatsapp','5493812119906',
  'sucursales_texto','🚚 SUCURSALES SOLO CON ENVIOS',
  'texto_confianza','Pago seguro · Entrega estimada · Sin costos ocultos',
  'aviso_checkout','⚠️ Completá Nombre, Domicilio, Forma de pago y Tel/Celular antes de enviar.',
  'texto_zona','El vendedor determinará si llegamos a tu zona con el envío seleccionado.',
  'texto_vuelto','Indicale al vendedor el monto con el que vas a pagar para que pueda preparar el cambio.',
  'texto_final','cuenta con nosotros, siempre te atenderemos con el corazón en Skazy',
  'tiempo_lun_jue','20 min – 40 min aprox.',
  'tiempo_vie_dom','35 min – 45 min aprox.',
  'texto_dudas_tiempo','💬 ¿Dudas sobre el tiempo de entrega? Consultá con el vendedor',
  'abierto', true,
  'horarios','Lun a Dom de 19:00 a 00:30',
  'urgencia_texto','⚡ Pedidos limitados por horario',
  'tutorial_activo', true
)),
('zona', jsonb_build_object(
  'lat_min',-26.761972,'lat_max',-26.713999,'lng_min',-65.271194,'lng_max',-65.233750,
  'mensaje_fuera','Lo sentimos, por el momento no realizamos entregas en esta zona.',
  'mensaje_dentro','Ubicación confirmada. Realizamos entregas en esta zona.',
  'sucursal_lat',-26.7350,'sucursal_lng',-65.2520
)),
('logos', jsonb_build_object('cantidad',5,'velocidad',30,'segundos',20,'activo',true)),
('pagos', jsonb_build_object('alias','SKAZY.PZ','titular','Isaías Chaile','medio','Mercado Pago','qr_url',''));