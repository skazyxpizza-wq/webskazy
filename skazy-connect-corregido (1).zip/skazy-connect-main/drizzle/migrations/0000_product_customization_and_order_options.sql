ALTER TABLE public.productos ADD COLUMN descripcion_detallada text NOT NULL DEFAULT '';
ALTER TABLE public.productos ADD COLUMN grupos_modificadores jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.productos ADD COLUMN sugeridos_ids uuid[] NOT NULL DEFAULT '{}'::uuid[];
ALTER TABLE public.pedido_items ADD COLUMN opciones jsonb NOT NULL DEFAULT '[]'::jsonb;