import { useState, type ReactNode } from "react";
import { subirImagen } from "@/lib/storage";

export function Campo({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block text-sm">
      <span className="text-muted-foreground">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

export function CampoTexto({
  label,
  value,
  onChange,
  tipo = "text",
  placeholder,
}: {
  label: string;
  value: string | number;
  onChange: (v: string) => void;
  tipo?: string;
  placeholder?: string;
}) {
  return (
    <Campo label={label}>
      <input
        type={tipo}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="field"
      />
    </Campo>
  );
}

export function CampoArea({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <Campo label={label}>
      <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={3} className="field" />
    </Campo>
  );
}

export function CampoSwitch({
  label,
  value,
  onChange,
}: {
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!value)}
      className={`btn-base w-full justify-between text-sm ${value ? "btn-accent" : "btn-ghost"}`}
    >
      <span>{label}</span>
      <span className="font-bold">{value ? "ACTIVO" : "INACTIVO"}</span>
    </button>
  );
}

export function Seccion({ titulo, children }: { titulo: string; children: ReactNode }) {
  return (
    <section className="panel mb-4 p-4">
      <h2 className="mb-3 text-2xl text-accent">{titulo}</h2>
      {children}
    </section>
  );
}


export function CampoImagen({
  label,
  value,
  onChange,
  carpeta,
  ancho = 1400,
  tipo = "image/webp",
}: {
  label: string;
  value: string;
  onChange: (url: string) => void;
  carpeta: string;
  ancho?: number;
  tipo?: "image/webp" | "image/png";
}) {
  const [subiendo, setSubiendo] = useState(false);
  const [error, setError] = useState("");

  async function elegir(file?: File) {
    if (!file) return;
    setSubiendo(true);
    setError("");
    try {
      onChange(await subirImagen(file, carpeta, ancho, tipo));
    } catch (e) {
      setError(e instanceof Error ? e.message : "No se pudo subir la imagen.");
    } finally {
      setSubiendo(false);
    }
  }

  return (
    <div className="space-y-1 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <div className="flex flex-wrap items-center gap-3">
        {value ? (
          <img src={value} alt="" className="h-16 w-16 rounded-lg bg-surface-2 object-contain" />
        ) : (
          <div className="h-16 w-16 rounded-lg bg-surface-2" aria-hidden="true" />
        )}
        <label className="btn-base btn-ghost grid min-h-11 cursor-pointer place-items-center px-3">
          {subiendo ? "Subiendo…" : value ? "Cambiar imagen" : "Subir imagen"}
          <input
            type="file"
            accept="image/*"
            className="sr-only"
            disabled={subiendo}
            onChange={(e) => {
              void elegir(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
        </label>
        {value && (
          <button type="button" onClick={() => onChange("")} className="btn-base btn-ghost min-h-11 px-3">
            Quitar
          </button>
        )}
      </div>
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
