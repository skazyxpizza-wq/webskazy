import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { calcularPedidoGrupal, unidadesCarrito } from "@/lib/pedido-grupal";
import { money } from "@/lib/skazy";
import type { CarritoItem, PersonaGrupo } from "@/lib/types";

interface Props {
  carrito: CarritoItem[];
  total: number;
  activo: boolean;
  onActivo: (valor: boolean) => void;
  personas: PersonaGrupo[];
  onPersonas: (personas: PersonaGrupo[]) => void;
  asignaciones: Record<string, string>;
  onAsignaciones: (asignaciones: Record<string, string>) => void;
}

export default function PedidoGrupalEditor({ carrito, total, activo, onActivo, personas, onPersonas, asignaciones, onAsignaciones }: Props) {
  const resumen = calcularPedidoGrupal(carrito, personas, asignaciones, total);
  const actualizar = (id: string, campos: Partial<PersonaGrupo>) => onPersonas(personas.map((p) => p.id === id ? { ...p, ...campos } : p));
  return <section className="group-order mb-5 border-b border-border pb-5">
    <h3 className="mb-3 text-2xl">¿Es un pedido en grupo?</h3>
    <div className="flex gap-2" role="group" aria-label="Pedido en grupo">
      {[false, true].map((valor) => <Button key={String(valor)} type="button" variant={activo === valor ? "default" : "outline"} aria-pressed={activo === valor} className="min-h-11 flex-1" onClick={() => onActivo(valor)}>{valor ? "Sí" : "No"}</Button>)}
    </div>
    {activo && <>
      <div className="mt-4 space-y-4">{personas.map((persona, index) => <fieldset key={persona.id} className="border-b border-border pb-4">
        <legend className="font-semibold">Persona {index + 1}</legend>
        <div className="mt-2 flex gap-2"><input aria-label={`Nombre de persona ${index + 1}`} value={persona.nombre} maxLength={80} onChange={(e) => actualizar(persona.id, { nombre: e.target.value })} className="field min-w-0 flex-1" placeholder="Nombre" />
          <Button variant="ghost" size="icon" type="button" className="h-12 w-12 shrink-0" disabled={personas.length <= 2} title="Eliminar persona" aria-label={`Eliminar persona ${index + 1}`} onClick={() => {
            onPersonas(personas.filter((p) => p.id !== persona.id));
            onAsignaciones(Object.fromEntries(Object.entries(asignaciones).filter(([, id]) => id !== persona.id)));
          }}><Trash2 /></Button></div>
        <label className="mt-2 block text-sm">Método de pago<select className="field mt-1" value={persona.metodo_pago} onChange={(e) => actualizar(persona.id, { metodo_pago: e.target.value === "TRANSFERENCIA" ? "TRANSFERENCIA" : "EFECTIVO", paga_con: null })}><option value="EFECTIVO">Efectivo</option><option value="TRANSFERENCIA">Transferencia</option></select></label>
        {persona.metodo_pago === "EFECTIVO" && <label className="mt-2 block text-sm">Abona con (opcional)<input className="field mt-1" inputMode="decimal" type="number" min={resumen.personas[index]?.total ?? 0} value={persona.paga_con ?? ""} onChange={(e) => actualizar(persona.id, { paga_con: e.target.value ? Number(e.target.value) : null })} /></label>}
      </fieldset>)}</div>
      <Button type="button" variant="outline" className="mt-3 min-h-11" onClick={() => onPersonas([...personas, { id: crypto.randomUUID(), nombre: "", metodo_pago: "EFECTIVO", paga_con: null }])}><Plus />Agregar persona</Button>
      <h4 className="mt-5 font-display text-2xl">Productos por persona</h4>
      <div className="mt-2 space-y-3">{unidadesCarrito(carrito).map((unidad) => <label key={unidad.clave} className="block text-sm"><span className="block font-semibold">1 × {unidad.nombre} · {money(unidad.precio)}</span><select aria-label={`Asignar ${unidad.nombre}`} className="field mt-1" value={asignaciones[unidad.clave] ?? "todos"} onChange={(e) => onAsignaciones({ ...asignaciones, [unidad.clave]: e.target.value })}><option value="todos">A dividir entre todos</option>{personas.map((p, i) => <option key={p.id} value={p.id}>{p.nombre.trim() || `Persona ${i + 1}`}</option>)}</select></label>)}</div>
      <h4 className="mt-5 font-display text-2xl">Desglose por persona</h4>
      <div className="mt-2 space-y-3">{resumen.personas.map((p, index) => <div key={p.id} className="border-b border-border pb-3 text-sm"><strong>{p.nombre || `Persona ${index + 1}`}</strong><p>Subtotal: {money(p.subtotal)} · Descuento: {money(p.descuento)}</p><p className="font-semibold text-primary">Total: {money(p.total)} · {p.metodo_pago === "EFECTIVO" ? "Efectivo" : "Transferencia"}</p>{p.paga_con != null && <p>Abona con {money(p.paga_con)} · Vuelto {money(p.paga_con - p.total)}</p>}</div>)}</div>
    </>}
  </section>;
}