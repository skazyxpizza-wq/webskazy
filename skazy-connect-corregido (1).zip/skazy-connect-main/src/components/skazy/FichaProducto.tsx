import { useEffect, useMemo, useState } from "react";
import { Check, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Drawer, DrawerContent, DrawerTitle, DrawerDescription } from "@/components/ui/drawer";
import { money } from "@/lib/skazy";
import type { Producto, SeleccionModificador } from "@/lib/types";
import pizzaFallback from "@/assets/skazy-product-pizza.webp";

interface Props {
  producto: Producto | null;
  productos: Producto[];
  onCerrar: () => void;
  onAgregar: (producto: Producto, opciones: SeleccionModificador[]) => void;
  onElegir: (producto: Producto) => void;
}

export default function FichaProducto({ producto, productos, onCerrar, onAgregar, onElegir }: Props) {
  const [seleccion, setSeleccion] = useState<Record<string, string[]>>({});
  const [intento, setIntento] = useState(false);
  useEffect(() => { setSeleccion({}); setIntento(false); }, [producto?.id]);
  const grupos = useMemo(() => Array.isArray(producto?.grupos_modificadores) ? producto.grupos_modificadores : [], [producto]);
  const opciones = useMemo(() => grupos.flatMap((grupo) =>
    grupo.opciones.filter((opcion) => (seleccion[grupo.id] ?? []).includes(opcion.id)).map((opcion) => ({
      grupo: grupo.nombre, opcion: opcion.nombre, precio: Number(opcion.precio) || 0,
    }))), [grupos, seleccion]);
  const pendientes = grupos.filter((g) => g.obligatorio && !(seleccion[g.id]?.length));
  const sugeridos = productos.filter((p) => p.visible && !p.agotado && producto?.sugeridos_ids?.includes(p.id) && p.id !== producto.id).slice(0, 3);

  function elegir(grupoId: string, opcionId: string, obligatorio: boolean) {
    setSeleccion((prev) => {
      const actual = prev[grupoId] ?? [];
      return { ...prev, [grupoId]: obligatorio ? [opcionId] : actual.includes(opcionId) ? actual.filter((id) => id !== opcionId) : [...actual, opcionId] };
    });
  }

  function confirmar() {
    setIntento(true);
    if (!producto || pendientes.length || producto.agotado) return;
    onAgregar(producto, opciones);
    onCerrar();
  }

  function agregarYVerSugerido(sugerido: Producto) {
    setIntento(true);
    if (!producto || pendientes.length || producto.agotado) return;
    onAgregar(producto, opciones);
    onElegir(sugerido);
  }

  return (
    <Drawer open={Boolean(producto)} onOpenChange={(open) => { if (!open) onCerrar(); }} shouldScaleBackground={false}>
      <DrawerContent className="client-shell product-sheet max-h-[92dvh] border-border bg-background text-foreground" aria-describedby="product-sheet-description">
        {producto && <>
          <div className="flex items-start justify-between gap-3 px-5 pt-4">
            <div className="min-w-0"><DrawerTitle className="text-left font-display text-4xl leading-none">{producto.nombre}</DrawerTitle><DrawerDescription id="product-sheet-description" className="sr-only">Elegí opciones para tu pedido</DrawerDescription></div>
            <Button type="button" variant="ghost" size="icon" className="h-11 w-11 shrink-0 rounded-full" onClick={onCerrar} aria-label="Cerrar ficha"><X /></Button>
          </div>
          <div className="product-sheet-scroll overflow-y-auto overscroll-contain px-5 pb-5">
            <img src={producto.imagen_url || pizzaFallback} alt={producto.nombre} decoding="async" className="mt-4 aspect-[16/10] w-full rounded-md object-cover" />
            <p className="mt-4 whitespace-pre-line text-base leading-relaxed">{producto.descripcion_detallada || producto.descripcion}</p>
            <p className="mt-3 font-display text-3xl text-primary">{money(producto.precio)}</p>
            {grupos.map((grupo) => <fieldset key={grupo.id} className="product-sheet-group mt-6 pt-5">
              <legend className="font-display text-2xl">{grupo.nombre} <span className="font-sans text-xs font-semibold text-muted-foreground">{grupo.obligatorio ? "Obligatorio · Elegí una" : "Opcional · Elegí las que quieras"}</span></legend>
              <div className="mt-3 space-y-2">{grupo.opciones.map((opcion) => {
                const checked = (seleccion[grupo.id] ?? []).includes(opcion.id);
                return <label key={opcion.id} className={`product-option flex min-h-14 items-center gap-3 rounded-md border px-4 py-3 ${checked ? "is-selected" : ""}`}>
                  <input type={grupo.obligatorio ? "radio" : "checkbox"} name={grupo.id} checked={checked} onChange={() => elegir(grupo.id, opcion.id, grupo.obligatorio)} className="h-5 w-5 shrink-0 accent-primary" />
                  <span className="min-w-0 flex-1 font-semibold">{opcion.nombre}</span>
                  {Number(opcion.precio) > 0 && <span className="shrink-0 font-bold text-primary">+{money(opcion.precio)}</span>}
                </label>;
              })}</div>
              {intento && pendientes.some((p) => p.id === grupo.id) && <p className="mt-2 text-sm font-semibold text-destructive">Elegí una opción para continuar.</p>}
            </fieldset>)}
            {sugeridos.length > 0 && <section className="product-sheet-group mt-6 pt-5"><h3 className="font-display text-2xl">¿Le agregás algo más?</h3>
              <div className="mt-3 space-y-2">{sugeridos.map((p) => <Button key={p.id} type="button" variant="outline" onClick={() => agregarYVerSugerido(p)} className="h-auto min-h-16 w-full justify-start gap-3 whitespace-normal rounded-md p-2 text-left" aria-label={`Agregar ${producto.nombre} y ver ${p.nombre}`}>
                <img src={p.imagen_url || pizzaFallback} alt="" loading="lazy" decoding="async" className="h-12 w-12 shrink-0 rounded-sm object-cover" /><span className="min-w-0 flex-1">{p.nombre}<small className="block text-primary">{money(p.precio)}</small></span><Plus className="shrink-0" />
              </Button>)}</div>
            </section>}
          </div>
          <div className="product-sheet-footer border-t border-border bg-background px-5 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3">
            <Button type="button" onClick={confirmar} disabled={producto.agotado} className="min-h-14 w-full rounded-md bg-primary text-base text-primary-foreground hover:bg-primary/90"><Check /> {producto.agotado ? "Agotado" : `Agregar al pedido · ${money(Number(producto.precio) + opciones.reduce((s, o) => s + o.precio, 0))}`}</Button>
          </div>
        </>}
      </DrawerContent>
    </Drawer>
  );
}