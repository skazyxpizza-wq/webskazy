import { useEffect, useRef } from "react";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

export interface MarcadorMapa {
  lat: number;
  lng: number;
  titulo?: string;
  color?: string;
}

interface MapaProps {
  centro: { lat: number; lng: number };
  zoom?: number;
  marcadores?: MarcadorMapa[];
  ruta?: { lat: number; lng: number }[];
  rectangulo?: { lat_min: number; lat_max: number; lng_min: number; lng_max: number };
  circulo?: { lat: number; lng: number; radio: number };
  alClickear?: (lat: number, lng: number) => void;
  alto?: number;
}

function iconoColor(color: string) {
  return L.divIcon({
    className: "",
    html: `<span style="display:block;width:16px;height:16px;border-radius:50%;background:${color};border:2px solid white;box-shadow:0 0 6px rgba(0,0,0,.6)"></span>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
  });
}

export default function Mapa({
  centro,
  zoom = 14,
  marcadores = [],
  ruta,
  rectangulo,
  circulo,
  alClickear,
  alto = 280,
}: MapaProps) {
  const divRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const capaRef = useRef<L.LayerGroup | null>(null);
  const clickRef = useRef(alClickear);
  clickRef.current = alClickear;

  useEffect(() => {
    if (!divRef.current || mapRef.current) return;
    const map = L.map(divRef.current, { attributionControl: false }).setView(
      [centro.lat, centro.lng],
      zoom,
    );
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(map);
    capaRef.current = L.layerGroup().addTo(map);
    map.on("click", (e: L.LeafletMouseEvent) => {
      clickRef.current?.(e.latlng.lat, e.latlng.lng);
    });
    mapRef.current = map;
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, [centro.lat, centro.lng, zoom]);

  useEffect(() => {
    const map = mapRef.current;
    const capa = capaRef.current;
    if (!map || !capa) return;
    capa.clearLayers();

    if (rectangulo) {
      L.rectangle(
        [
          [rectangulo.lat_min, rectangulo.lng_min],
          [rectangulo.lat_max, rectangulo.lng_max],
        ],
        { color: "#f97316", weight: 2, fillOpacity: 0.06 },
      ).addTo(capa);
    }
    if (circulo) L.circle([circulo.lat, circulo.lng], { radius: circulo.radio, color: "#d9272a", weight: 2, fillOpacity: 0.08 }).addTo(capa);
    if (ruta && ruta.length > 1) {
      L.polyline(
        ruta.map((p) => [p.lat, p.lng] as [number, number]),
        { color: "#22c55e", weight: 4, opacity: 0.85 },
      ).addTo(capa);
    }
    marcadores.forEach((m) => {
      const mk = L.marker([m.lat, m.lng], { icon: iconoColor(m.color ?? "#ef4444") }).addTo(capa);
      if (m.titulo) mk.bindTooltip(m.titulo, { permanent: false });
    });
  }, [marcadores, ruta, rectangulo, circulo]);

  useEffect(() => {
    mapRef.current?.setView([centro.lat, centro.lng], mapRef.current.getZoom());
  }, [centro.lat, centro.lng]);

  return <div ref={divRef} style={{ height: alto, width: "100%" }} className="rounded-xl" />;
}
