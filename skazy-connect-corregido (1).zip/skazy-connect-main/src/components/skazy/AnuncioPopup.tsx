import { useEffect, useState } from "react";
import { ExternalLink, X } from "lucide-react";
import type { Anuncio } from "@/lib/types";
import MarcaSkazy from "@/components/skazy/MarcaSkazy";

interface Props {
  anuncios: Anuncio[];
  onProducto: (id: string) => void;
  onCategoria: (id: string) => void;
}

export default function AnuncioPopup({ anuncios, onProducto, onCategoria }: Props) {
  const activos = anuncios.filter((a) => a.activo).sort((a, b) => a.orden - b.orden);
  const [indice, setIndice] = useState(0);
  const [visible, setVisible] = useState(false);
  const actual = activos[indice];

  useEffect(() => {
    if (!actual) return;
    const esperaEntrada = indice === 0 ? 1100 : 260;
    const entrada = window.setTimeout(() => setVisible(true), esperaEntrada);
    const salida = window.setTimeout(() => setVisible(false), esperaEntrada + 10000);
    const siguiente = window.setTimeout(() => setIndice((i) => i + 1), esperaEntrada + 10400);
    return () => {
      window.clearTimeout(entrada);
      window.clearTimeout(salida);
      window.clearTimeout(siguiente);
    };
  }, [actual, indice]);

  if (!actual) return null;

  const cerrar = () => {
    setVisible(false);
    window.setTimeout(() => setIndice((i) => i + 1), 380);
  };

  const accionar = () => {
    const destino = actual.destino ?? "";
    if (actual.destino_tipo === "producto") onProducto(destino);
    else if (actual.destino_tipo === "categoria") onCategoria(destino);
    else if (destino) window.open(destino, "_blank", "noopener,noreferrer");
    cerrar();
  };

  return (
    <div className={`ad-overlay ${visible ? "is-visible" : "is-leaving"}`} role="dialog" aria-modal="true" aria-label={actual.titulo || "Anuncio"}>
      <article className={`ad-popup ad-${actual.tamano}`}>
        <MarcaSkazy variante="isologo" decorativo className="ad-brand" />
        <button type="button" onClick={cerrar} className="ad-close" aria-label="Cerrar anuncio">
          <X size={24} strokeWidth={2.4} />
        </button>
        {actual.imagen_url ? <img src={actual.imagen_url} alt={actual.titulo} className="h-full w-full object-cover" /> : null}
        {(actual.titulo || actual.tiene_boton) && (
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-foreground/95 via-foreground/65 to-transparent p-5 pt-16 text-background">
            {actual.titulo ? <h2 className="text-3xl leading-none sm:text-4xl">{actual.titulo}</h2> : null}
            {actual.tiene_boton ? (
              <button type="button" onClick={accionar} className="client-cta mt-4 min-h-12 w-full px-5">
                {actual.boton_texto || "Ver ahora"}<ExternalLink size={17} />
              </button>
            ) : null}
          </div>
        )}
        <span className="ad-timer" />
      </article>
    </div>
  );
}