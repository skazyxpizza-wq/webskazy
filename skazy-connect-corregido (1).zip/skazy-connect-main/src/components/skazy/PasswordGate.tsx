import { useEffect, useState } from "react";
import { verificarAcceso } from "@/lib/data";

interface Props {
  sector: "admin" | "cocina" | "envios";
  titulo: string;
  children: (password: string) => React.ReactNode;
}

export default function PasswordGate({ sector, titulo, children }: Props) {
  const [password, setPassword] = useState("");
  const [valor, setValor] = useState("");
  const [error, setError] = useState("");
  const [cargando, setCargando] = useState(false);
  const [listo, setListo] = useState(false);
  const storageKey = `skazy_acceso_${sector}`;

  useEffect(() => {
    const guardado = sessionStorage.getItem(storageKey);
    if (!guardado) {
      setListo(true);
      return;
    }
    verificarAcceso(sector, guardado)
      .then((ok) => {
        if (ok) setPassword(guardado);
        else sessionStorage.removeItem(storageKey);
      })
      .catch(() => sessionStorage.removeItem(storageKey))
      .finally(() => setListo(true));
  }, [sector, storageKey]);

  async function entrar(e: React.FormEvent) {
    e.preventDefault();
    setCargando(true);
    setError("");
    try {
      const ok = await verificarAcceso(sector, valor);
      if (ok) {
        sessionStorage.setItem(storageKey, valor);
        setPassword(valor);
      } else {
        setError("Contraseña incorrecta.");
      }
    } catch {
      setError("No pudimos verificar la contraseña. Revisá tu conexión.");
    } finally {
      setCargando(false);
    }
  }

  if (password) return <>{children(password)}</>;

  return (
    <main className="flex min-h-screen items-center justify-center p-6">
      <form onSubmit={entrar} className="panel w-full max-w-sm p-6">
        <h1 className="text-3xl text-accent">{titulo}</h1>
        <p className="mt-1 text-sm text-muted-foreground">Ingresá la contraseña del sector.</p>
        <input
          type="password"
          value={valor}
          onChange={(e) => setValor(e.target.value)}
          placeholder="Contraseña"
          className="field mt-4"
          autoComplete="current-password"
        />
        {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
        <button type="submit" disabled={cargando || !listo} className="btn-base btn-base-active btn-primary mt-4 w-full">
          {cargando ? "Verificando…" : "Entrar"}
        </button>
      </form>
    </main>
  );
}
