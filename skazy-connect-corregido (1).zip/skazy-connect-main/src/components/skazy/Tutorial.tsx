import { useEffect, useMemo, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, X } from "lucide-react";
import MarcaSkazy from "@/components/skazy/MarcaSkazy";

export interface PasoTutorial {
  titulo: string;
  texto: string;
  objetivo: string;
}

export const PASOS_CLIENTE: PasoTutorial[] = [
  { titulo: "Encontrá tu antojo", texto: "Tocá la lupa y buscá cualquier producto por nombre.", objetivo: "busqueda" },
  { titulo: "Guardá favoritos", texto: "El corazón conserva lo que más te gusta.", objetivo: "favoritos" },
  { titulo: "Recorré el menú", texto: "Saltá directo a Promos, Combos, Pizzas o Empanadas.", objetivo: "categorias" },
  { titulo: "Sumalo al pedido", texto: "Agregá productos y ajustá cantidades cuando quieras.", objetivo: "producto" },
  { titulo: "Tu carrito", texto: "La isla muestra cantidad y total, siempre al alcance.", objetivo: "carrito" },
  { titulo: "Seguí tu pedido", texto: "Mirá cada etapa y la ubicación del envío en vivo.", objetivo: "seguimiento" },
];

type Rect = { top: number; left: number; width: number; height: number };

export default function Tutorial({ pasos = PASOS_CLIENTE, onFinalizar }: { pasos?: PasoTutorial[]; onFinalizar: () => void }) {
  const [i, setI] = useState(0);
  const [rect, setRect] = useState<Rect | null>(null);
  const paso = pasos[i];

  useEffect(() => {
    if (!paso) return;
    const actualizar = () => {
      const element = document.querySelector<HTMLElement>(`[data-tour="${paso.objetivo}"]`);
      if (!element) {
        setRect(null);
        return;
      }
      element.scrollIntoView({ behavior: "smooth", block: "center" });
      window.setTimeout(() => {
        const box = element.getBoundingClientRect();
        const gap = 8;
        setRect({ top: Math.max(8, box.top - gap), left: Math.max(8, box.left - gap), width: Math.min(window.innerWidth - 16, box.width + gap * 2), height: box.height + gap * 2 });
      }, 380);
    };
    actualizar();
    window.addEventListener("resize", actualizar);
    window.addEventListener("scroll", actualizar, { passive: true });
    return () => {
      window.removeEventListener("resize", actualizar);
      window.removeEventListener("scroll", actualizar);
    };
  }, [paso]);

  const placement = useMemo(() => {
    if (!rect) return { top: "50%", left: 16, right: 16, transform: "translateY(-50%)" };
    const below = rect.top + rect.height + 190 < window.innerHeight;
    return below
      ? { top: rect.top + rect.height + 18, left: 16, right: 16 }
      : { bottom: window.innerHeight - rect.top + 18, left: 16, right: 16 };
  }, [rect]);

  if (!paso) return null;
  const siguiente = () => (i + 1 >= pasos.length ? onFinalizar() : setI(i + 1));
  const Arrow = rect && rect.top < window.innerHeight / 2 ? ArrowUp : ArrowDown;

  return (
    <div className="fixed inset-0 z-[80]" aria-label="Tutorial del menú">
      {rect ? (
        <>
          <div className="tour-shade" style={{ top: 0, left: 0, right: 0, height: rect.top }} />
          <div className="tour-shade" style={{ top: rect.top, left: 0, width: rect.left, height: rect.height }} />
          <div className="tour-shade" style={{ top: rect.top, left: rect.left + rect.width, right: 0, height: rect.height }} />
          <div className="tour-shade" style={{ top: rect.top + rect.height, left: 0, right: 0, bottom: 0 }} />
          <div className="tour-focus" style={rect} />
        </>
      ) : <div className="tour-shade inset-0" />}

      <article className="tour-card" style={placement}>
        <MarcaSkazy variante="isologo" decorativo className="tour-brand" />
        <div className="mb-2 flex items-center justify-between text-primary">
          <Arrow size={28} />
          <button type="button" onClick={onFinalizar} className="tour-icon" aria-label="Cerrar tutorial"><X size={22} /></button>
        </div>
        <p className="text-xs font-bold uppercase text-primary">Paso {i + 1} de {pasos.length}</p>
        <h3 className="mt-1 text-3xl leading-none">{paso.titulo}</h3>
        <p className="mt-2 text-sm text-muted-foreground">{paso.texto}</p>
        <div className="mt-4 grid grid-cols-[auto_1fr] gap-2">
          <button type="button" onClick={() => i > 0 && setI(i - 1)} disabled={i === 0} className="tour-secondary" aria-label="Paso anterior"><ArrowLeft size={20} /></button>
          <button type="button" onClick={siguiente} className="client-cta min-h-12 px-5">{i + 1 >= pasos.length ? "Empezar" : "Siguiente"}<ArrowRight size={19} /></button>
        </div>
      </article>
    </div>
  );
}