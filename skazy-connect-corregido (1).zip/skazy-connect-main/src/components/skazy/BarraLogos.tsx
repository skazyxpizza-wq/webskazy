import type { ConfigLogos, LogoCategoria } from "@/lib/types";

interface Props {
  logos: LogoCategoria[];
  config: ConfigLogos;
  onSeleccionar?: (categoriaId: string | null) => void;
}

export default function BarraLogos({ logos, config, onSeleccionar }: Props) {
  if (!config.activo) return null;
  const visibles = logos.filter((l) => l.activo).slice(0, Math.max(1, config.cantidad));
  if (!visibles.length) return null;
  const duracion = Math.max(4, config.segundos || 20);

  return (
    <div className="client-logo-bar overflow-hidden border-y border-border py-4">
      <div className="marquee-track gap-6" style={{ animationDuration: `${duracion}s` }}>
        {[0, 1].map((copia) => (
          <div key={copia} className="flex gap-6 pr-6" aria-hidden={copia === 1}>
            {visibles.map((logo) => (
              <button
                key={`${copia}-${logo.id}`}
                type="button"
                onClick={() => onSeleccionar?.(logo.categoria_id)}
                className="flex min-h-20 w-24 shrink-0 flex-col items-center justify-center gap-1"
              >
                <span className="flex h-14 w-14 items-center justify-center overflow-hidden rounded-full border border-border bg-card">
                  {logo.imagen_url ? (
                    <img src={logo.imagen_url} alt={logo.titulo} loading="lazy" decoding="async" className="h-full w-full object-cover" />
                  ) : (
                    <span className="text-xl">🍕</span>
                  )}
                </span>
                <span className="truncate text-[11px] text-muted-foreground">{logo.titulo}</span>
              </button>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
