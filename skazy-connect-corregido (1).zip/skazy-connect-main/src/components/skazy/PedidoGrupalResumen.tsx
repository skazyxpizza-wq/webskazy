import type { PedidoGrupal } from "@/lib/types";
import { money } from "@/lib/skazy";

export default function PedidoGrupalResumen({ grupo }: { grupo: PedidoGrupal | null | undefined }) {
  if (!grupo) return null;
  return <section className="mt-4 border-t border-border pt-3"><h3 className="text-xl">Pedido grupal</h3>{grupo.personas.map((p) => <div key={p.id} className="mt-3 text-sm"><strong>{p.nombre} · {money(p.total)} · {p.metodo_pago}</strong><p>Subtotal {money(p.subtotal)} · Descuento {money(p.descuento)}</p><ul>{grupo.unidades.filter((u) => u.compartido || u.persona_id === p.id).map((u) => <li key={u.clave}>1 × {u.nombre}{u.compartido ? " (a dividir entre todos)" : ""}</li>)}</ul>{p.paga_con != null && <p>Abona con {money(p.paga_con)} · Vuelto {money(p.paga_con - p.total)}</p>}</div>)}</section>;
}