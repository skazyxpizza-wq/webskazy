import { ClientOnly } from "@tanstack/react-router";
import { Suspense, lazy } from "react";
import type { ComponentProps } from "react";
import type MapaTipo from "./Mapa";

const Mapa = lazy(() => import("./Mapa"));

type Props = ComponentProps<typeof MapaTipo>;

function Placeholder({ alto = 280 }: { alto?: number }) {
  return (
    <div
      style={{ height: alto }}
      className="flex w-full items-center justify-center rounded-xl bg-surface-2 text-sm text-muted-foreground"
    >
      Cargando mapa…
    </div>
  );
}

export default function MapaClient(props: Props) {
  return (
    <ClientOnly fallback={<Placeholder alto={props.alto ?? 280} />}>
      <Suspense fallback={<Placeholder alto={props.alto ?? 280} />}>
        <Mapa {...props} />
      </Suspense>
    </ClientOnly>
  );
}
