import { useState } from "react";

/**
 * Las piezas de marca viven en /public/marca:
 *   - logo-principal.png  (logo completo)
 *   - isologo.webp        (versión con el nombre SKAZY)
 * Si un archivo no existe todavía, se muestra /marca/fallback.png.
 */
interface MarcaSkazyProps {
  variante?: "principal" | "isologo";
  className?: string;
  decorativo?: boolean;
}

const RUTAS = {
  principal: "/marca/logo-principal.png",
  isologo: "/marca/isologo.webp",
} as const;

export default function MarcaSkazy({
  variante = "principal",
  className = "",
  decorativo = false,
}: MarcaSkazyProps) {
  const [fallo, setFallo] = useState(false);
  const descripcion = variante === "principal" ? "Logo de SKAZY" : "SKAZY";

  return (
    <img
      src={fallo ? "/marca/fallback.png" : RUTAS[variante]}
      alt={decorativo ? "" : descripcion}
      aria-hidden={decorativo || undefined}
      className={className}
      onError={() => setFallo(true)}
    />
  );
}
