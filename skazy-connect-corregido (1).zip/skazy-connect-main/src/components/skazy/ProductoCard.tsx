import { useRef, useState, type PointerEvent } from "react";
import { Heart, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { money } from "@/lib/skazy";
import type { Producto } from "@/lib/types";
import pizzaFallback from "@/assets/skazy-product-pizza.webp";
import empanadaFallback from "@/assets/skazy-product-empanadas.webp";
import promoFallback from "@/assets/skazy-promo-pizza.webp";

interface Props {
  producto: Producto;
  esFavorito: boolean;
  onFavorito: (id: string) => void;
  onAbrir: (p: Producto) => void;
  onAgregar: (p: Producto) => void;
  destacado?: boolean;
  tipo?: "promo" | "combo" | "producto";
}

export default function ProductoCard({ producto, esFavorito, onFavorito, onAbrir, onAgregar, destacado = false, tipo = "producto" }: Props) {
  const [activo, setActivo] = useState(false);
  const card = useRef<HTMLElement>(null);
  const texto = `${producto.nombre} ${producto.descripcion ?? ""}`.toLowerCase();
  const fallback = destacado ? promoFallback : texto.includes("empanada") ? empanadaFallback : pizzaFallback;
  const imagen = producto.imagen_url || fallback;
  const requiereFicha = Boolean(producto.descripcion_detallada?.trim()) || producto.grupos_modificadores.length > 0;

  const agregar = () => {
    if (requiereFicha) onAbrir(producto);
    else onAgregar(producto);
  };

  const mover = (event: PointerEvent<HTMLElement>) => {
    if (!card.current || event.pointerType === "touch" || destacado) return;
    const box = card.current.getBoundingClientRect();
    const rotateY = ((event.clientX - box.left) / box.width - 0.5) * 8;
    const rotateX = -((event.clientY - box.top) / box.height - 0.5) * 8;
    card.current.style.setProperty("--rotate-x", `${rotateX}deg`);
    card.current.style.setProperty("--rotate-y", `${rotateY}deg`);
  };

  const salir = () => {
    setActivo(false);
    card.current?.style.setProperty("--rotate-x", "0deg");
    card.current?.style.setProperty("--rotate-y", "0deg");
  };

  if (tipo !== "producto") {
    const datoPromo = `${producto.nombre} ${producto.descripcion ?? ""}`.match(/\b\d+\s*[xX×]\s*\d+\b|[-−]?\d+\s*%/)?.[0]?.toUpperCase();
    return <article data-tour="producto" className={`offer-card ${tipo === "promo" ? "promo-card" : "combo-card"}`}>
      <div className="offer-photo"><Button variant="ghost" className="offer-photo-button" type="button" onClick={() => onAbrir(producto)} aria-label={`Ver ficha de ${producto.nombre}`}><img src={imagen} alt={producto.nombre} loading="lazy" decoding="async" width={700} height={500} /></Button>
        <Button type="button" variant="ghost" size="icon" className="favorite-button" aria-label={esFavorito ? "Quitar de favoritos" : "Agregar a favoritos"} onClick={() => onFavorito(producto.id)}><Heart fill={esFavorito ? "currentColor" : "none"} className={esFavorito ? "text-primary" : ""} /></Button>
      </div>
      <div className="offer-copy">
        {tipo === "promo" && <><span className="offer-label">OFERTA</span>{datoPromo && <strong className="offer-value">{datoPromo}</strong>}</>}
        <h3 className={tipo === "promo" ? "promo-name" : "combo-name"}><Button variant="ghost" onClick={() => onAbrir(producto)} type="button" className="offer-title">{producto.nombre}</Button></h3>
        {tipo === "combo" && producto.descripcion && <p className="offer-description">{producto.descripcion}</p>}
        {(producto.mas_vendido || producto.destacado) && <span className="offer-label">{producto.mas_vendido ? "Más vendido" : "Destacado"}</span>}
        <div className="offer-bottom"><span className="product-price">{money(producto.precio)}</span>{producto.agotado ? <span className="sold-out">Agotado</span> : <Button type="button" onClick={agregar} className={`offer-add ${tipo === "combo" ? "combo-add" : ""}`}><Plus />Agregar</Button>}</div>
      </div>
    </article>;
  }

  return (
    <article ref={card} data-tour="producto" className={`product-card ${destacado ? "product-feature" : ""}`} onPointerMove={mover} onPointerEnter={() => { if (!destacado) setActivo(true); }} onPointerLeave={salir} onPointerDown={() => { if (!destacado) setActivo(true); }} onPointerUp={salir} onPointerCancel={salir}>
      <div className="product-visual">
        <button type="button" className="absolute inset-0 z-[3] w-full cursor-pointer" onClick={() => onAbrir(producto)} aria-label={`Ver ficha de ${producto.nombre}`} />
        <img src={imagen} alt={producto.nombre} loading="lazy" decoding="async" width={1408} height={1408} className={`product-main ${activo ? "is-active" : destacado ? "" : "gira"}`} />
        {!destacado && <img src={producto.imagen_hover_url || imagen} alt="" aria-hidden="true" loading="lazy" decoding="async" width={1408} height={1408} className={`product-hover ${activo ? "is-active" : ""}`} />}
        <button type="button" aria-label={esFavorito ? "Quitar de favoritos" : "Agregar a favoritos"} onClick={() => onFavorito(producto.id)} className={`favorite-button ${esFavorito ? "is-active" : ""}`}>
          <Heart size={21} fill={esFavorito ? "currentColor" : "none"} />
        </button>
        {(producto.mas_vendido || producto.destacado) && <span className="bestseller-badge">{producto.mas_vendido ? "Más vendido" : "Destacado"}</span>}
      </div>
      <div className="product-copy">
        <div className="min-w-0">
          <h3 className="text-2xl leading-none sm:text-3xl"><button type="button" onClick={() => onAbrir(producto)} className="text-left">{producto.nombre}</button></h3>
          {producto.descripcion ? <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{producto.descripcion}</p> : null}
        </div>
        <div className="mt-4 flex items-center justify-between gap-3">
          <span className="product-price">{money(producto.precio)}</span>
          {producto.agotado ? <span className="sold-out">Agotado</span> : (
            <button type="button" onClick={agregar} className="client-cta min-h-12 px-4"><Plus size={19} />Agregar</button>
          )}
        </div>
      </div>
    </article>
  );
}