import { useState } from "react";
import { Plus, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { GrupoModificador, Producto } from "@/lib/types";

interface Props {
  producto: Producto;
  productos: Producto[];
  guardar: (id: string, campos: object) => Promise<void>;
  avisar: (mensaje: string) => void;
}

export default function ProductoOpcionesAdmin({ producto, productos, guardar, avisar }: Props) {
  const [descripcion, setDescripcion] = useState(producto.descripcion_detallada ?? "");
  const [grupos, setGrupos] = useState<GrupoModificador[]>(Array.isArray(producto.grupos_modificadores) ? producto.grupos_modificadores : []);
  const [sugeridos, setSugeridos] = useState<string[]>(producto.sugeridos_ids ?? []);
  const [guardando, setGuardando] = useState(false);

  const editarGrupo = (id: string, cambios: Partial<GrupoModificador>) => setGrupos((prev) => prev.map((g) => g.id === id ? { ...g, ...cambios } : g));

  async function confirmar() {
    if (grupos.some((g) => !g.nombre.trim() || !g.opciones.length || g.opciones.some((o) => !o.nombre.trim() || !Number.isFinite(Number(o.precio)) || Number(o.precio) < 0))) {
      avisar("Cada grupo necesita nombre y opciones con nombre y precio válido.");
      return;
    }
    setGuardando(true);
    try {
      await guardar(producto.id, {
        descripcion_detallada: descripcion.trim(),
        grupos_modificadores: grupos.map((g) => ({ ...g, nombre: g.nombre.trim(), opciones: g.opciones.map((o) => ({ ...o, nombre: o.nombre.trim(), precio: Number(o.precio) || 0 })) })),
        sugeridos_ids: sugeridos,
      });
      avisar("Ficha del producto guardada");
    } catch { avisar("No se pudo guardar la ficha. Intentá de nuevo."); }
    finally { setGuardando(false); }
  }

  return <div className="space-y-4 border-t border-border pt-4 md:col-span-2">
    <label className="block text-sm text-muted-foreground">Descripción detallada
      <textarea className="field mt-1" rows={4} value={descripcion} onChange={(e) => setDescripcion(e.target.value)} placeholder="Ingredientes, preparación y detalles del producto" />
    </label>
    <div className="flex items-center justify-between gap-2"><h3 className="text-xl">Grupos de modificadores</h3>
      <Button type="button" variant="outline" className="min-h-11" onClick={() => setGrupos((prev) => [...prev, { id: crypto.randomUUID(), nombre: "", obligatorio: false, opciones: [{ id: crypto.randomUUID(), nombre: "", precio: 0 }] }])}><Plus /> Grupo</Button>
    </div>
    {grupos.map((g) => <div key={g.id} className="space-y-3 border-t border-border pt-3">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-2">
        <input aria-label="Nombre del grupo" className="field min-w-0" placeholder="Estilo de masa" value={g.nombre} onChange={(e) => editarGrupo(g.id, { nombre: e.target.value })} />
        <Button type="button" variant="destructive" size="icon" className="h-11 w-11" aria-label="Eliminar grupo" onClick={() => setGrupos((prev) => prev.filter((item) => item.id !== g.id))}><Trash2 /></Button>
      </div>
      <label className="flex min-h-11 items-center gap-3 text-sm"><input type="checkbox" className="h-5 w-5" checked={g.obligatorio} onChange={(e) => editarGrupo(g.id, { obligatorio: e.target.checked })} /> Obligatorio: elegir una opción</label>
      {g.opciones.map((o) => <div key={o.id} className="grid grid-cols-[minmax(0,1fr)_5.5rem_auto] gap-2">
        <input aria-label="Nombre de opción" className="field min-w-0" placeholder="Opción" value={o.nombre} onChange={(e) => editarGrupo(g.id, { opciones: g.opciones.map((item) => item.id === o.id ? { ...item, nombre: e.target.value } : item) })} />
        <input aria-label="Precio adicional" className="field min-w-0" type="number" inputMode="decimal" min="0" step="0.01" value={o.precio} onChange={(e) => editarGrupo(g.id, { opciones: g.opciones.map((item) => item.id === o.id ? { ...item, precio: Number(e.target.value) } : item) })} />
        <Button type="button" variant="ghost" size="icon" className="h-11 w-11" aria-label="Eliminar opción" onClick={() => editarGrupo(g.id, { opciones: g.opciones.filter((item) => item.id !== o.id) })}><Trash2 /></Button>
      </div>)}
      <Button type="button" variant="outline" className="min-h-11" onClick={() => editarGrupo(g.id, { opciones: [...g.opciones, { id: crypto.randomUUID(), nombre: "", precio: 0 }] })}><Plus /> Opción</Button>
    </div>)}
    <div className="border-t border-border pt-4"><h3 className="text-xl">Productos sugeridos</h3><p className="mb-2 text-xs text-muted-foreground">Hasta 3 complementos en esta ficha.</p>
      <div className="grid gap-2 sm:grid-cols-2">{productos.filter((p) => p.id !== producto.id).map((p) => <label key={p.id} className="flex min-h-11 items-center gap-3 text-sm">
        <input type="checkbox" checked={sugeridos.includes(p.id)} disabled={!sugeridos.includes(p.id) && sugeridos.length >= 3} onChange={(e) => setSugeridos((prev) => e.target.checked ? [...prev, p.id] : prev.filter((id) => id !== p.id))} className="h-5 w-5 shrink-0" /><span className="min-w-0">{p.nombre}</span>
      </label>)}</div>
    </div>
    <Button type="button" onClick={confirmar} disabled={guardando} className="min-h-12"><Save />{guardando ? "Guardando…" : "Guardar ficha y opciones"}</Button>
  </div>;
}