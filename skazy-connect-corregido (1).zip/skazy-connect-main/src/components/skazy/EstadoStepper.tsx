import { ESTADOS } from "@/lib/skazy";
import type { Estado } from "@/lib/types";

export default function EstadoStepper({ estado }: { estado: Estado }) {
  if (estado === "CANCELADO") {
    return (
      <div className="rounded-lg bg-destructive/15 p-2 text-center text-sm font-semibold text-destructive">
        PEDIDO CANCELADO
      </div>
    );
  }
  const actual = ESTADOS.indexOf(estado);
  return (
    <ol className="flex flex-col gap-1">
      {ESTADOS.map((e, i) => (
        <li key={e} className="flex items-center gap-2">
          <span
            className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${
              i <= actual ? "bg-success text-success-foreground" : "bg-surface-2 text-muted-foreground"
            }`}
          >
            {i <= actual ? "✓" : i + 1}
          </span>
          <span className={i === actual ? "font-bold text-accent" : "text-muted-foreground"}>{e}</span>
          {i < ESTADOS.length - 1 && <span className="text-muted-foreground">↓</span>}
        </li>
      ))}
    </ol>
  );
}
