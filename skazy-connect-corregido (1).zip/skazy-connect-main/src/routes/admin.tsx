import MarcaSkazy from "@/components/skazy/MarcaSkazy";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import PasswordGate from "@/components/skazy/PasswordGate";
import MapaClient from "@/components/skazy/MapaClient";
import { Campo, CampoArea, CampoImagen, CampoSwitch, CampoTexto, Seccion } from "@/components/skazy/AdminCampos";
import {
  cambiarAcceso,
  fetchAnuncios,
  fetchCadetes,
  fetchCategorias,
  fetchCodigos,
  fetchConfig,
  fetchLogos,
  fetchPedidos,
  fetchProductos,
  fetchStock,
  guardarConfig,
} from "@/lib/data";
import { exportarPedidosExcel } from "@/lib/excel";
import { fechaCorta, horaCorta, money } from "@/lib/skazy";
import type { Config } from "@/lib/types";
import { subirImagen } from "@/lib/storage";
import ProductoOpcionesAdmin from "@/components/skazy/ProductoOpcionesAdmin";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Administración — SKAZY" },
      { name: "description", content: "Panel de administración de SKAZY." },
      { property: "og:title", content: "Administración — SKAZY" },
      { property: "og:description", content: "Panel interno de administración de SKAZY." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => (
    <PasswordGate sector="admin" titulo="ADMINISTRACIÓN">
      {(password) => <Admin adminPassword={password} />}
    </PasswordGate>
  ),
});

const SECCIONES = [
  "Accesos y seguridad",
  "Contenido del menú",
  "Códigos de descuento",
  "Anuncios / Ventanas Emergentes",
  "Barra de logos",
  "Pagos y cobros",
  "Mapa de envíos en vivo",
  "Balances y cadetes",
  "Historial y Excel",
  "Tutorial del cliente",
  "Configuración general",
] as const;

type SeccionNombre = (typeof SECCIONES)[number];

function Admin({ adminPassword }: { adminPassword: string }) {
  const [seccion, setSeccion] = useState<SeccionNombre>("Accesos y seguridad");
  const [mensaje, setMensaje] = useState("");

  const config = useQuery({ queryKey: ["config"], queryFn: fetchConfig });
  const categorias = useQuery({ queryKey: ["categorias"], queryFn: fetchCategorias });
  const productos = useQuery({ queryKey: ["productos"], queryFn: fetchProductos });
  const codigos = useQuery({ queryKey: ["codigos"], queryFn: fetchCodigos });
  const anuncios = useQuery({ queryKey: ["anuncios"], queryFn: fetchAnuncios });
  const logos = useQuery({ queryKey: ["logos"], queryFn: fetchLogos });
  const cadetes = useQuery({ queryKey: ["cadetes"], queryFn: fetchCadetes, refetchInterval: 10000 });
  const stock = useQuery({ queryKey: ["stock"], queryFn: fetchStock });
  const pedidos = useQuery({ queryKey: ["admin-pedidos"], queryFn: () => fetchPedidos() });

  useEffect(() => {
    const channel = supabase
      .channel("admin-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "pedidos" }, () => {
        void pedidos.refetch();
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "cadetes" }, () => {
        void cadetes.refetch();
      })
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [pedidos, cadetes]);

  function avisar(texto: string) {
    setMensaje(texto);
    setTimeout(() => setMensaje(""), 3000);
  }

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <aside className="border-b border-border bg-surface p-3 md:w-64 md:border-b-0 md:border-r">
        <h1 className="mb-3 flex justify-center">
          <MarcaSkazy variante="isologo" className="h-14 w-auto max-w-full object-contain" />
          <span className="sr-only">SKAZY — Administración</span>
        </h1>
        <nav className="flex flex-wrap gap-1 md:flex-col">
          {SECCIONES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSeccion(s)}
              className={`btn-base justify-start text-sm ${seccion === s ? "chip-activa" : "btn-ghost"}`}
            >
              {s}
            </button>
          ))}
        </nav>
      </aside>

      <main className="flex-1 p-4">
        {mensaje && <p className="panel mb-3 border-success p-2 text-sm text-success">{mensaje}</p>}

        {seccion === "Accesos y seguridad" && (
          <AccesosSeccion adminPassword={adminPassword} avisar={avisar} />
        )}

        {seccion === "Contenido del menú" && (
          <MenuSeccion
            categorias={categorias.data ?? []}
            productos={productos.data ?? []}
            recargar={() => {
              void categorias.refetch();
              void productos.refetch();
            }}
            avisar={avisar}
          />
        )}

        {seccion === "Códigos de descuento" && (
          <CodigosSeccion codigos={codigos.data ?? []} recargar={() => void codigos.refetch()} avisar={avisar} />
        )}

        {seccion === "Anuncios / Ventanas Emergentes" && (
          <AnunciosSeccion anuncios={anuncios.data ?? []} categorias={categorias.data ?? []} productos={productos.data ?? []} recargar={() => void anuncios.refetch()} avisar={avisar} />
        )}

        {seccion === "Barra de logos" && config.data && (
          <LogosSeccion
            logos={logos.data ?? []}
            categorias={categorias.data ?? []}
            config={config.data}
            recargar={() => {
              void logos.refetch();
              void config.refetch();
            }}
            avisar={avisar}
          />
        )}

        {seccion === "Pagos y cobros" && config.data && (
          <PagosSeccion config={config.data} recargar={() => void config.refetch()} avisar={avisar} />
        )}

        {seccion === "Mapa de envíos en vivo" && config.data && (
          <Seccion titulo="Mapa de envíos en vivo">
            <MapaClient
              centro={{ lat: config.data.zona.sucursal_lat, lng: config.data.zona.sucursal_lng }}
              alto={420}
              rectangulo={config.data.zona}
              marcadores={[
                {
                  lat: config.data.zona.sucursal_lat,
                  lng: config.data.zona.sucursal_lng,
                  titulo: "Sucursal",
                  color: "#f59e0b",
                },
                ...(cadetes.data ?? [])
                  .filter((c) => c.activo && c.lat != null && c.lng != null)
                  .map((c) => ({ lat: c.lat!, lng: c.lng!, titulo: c.nombre, color: "#22c55e" })),
              ]}
            />
            <ul className="mt-3 space-y-1 text-sm">
              {(cadetes.data ?? []).map((c) => (
                <li key={c.id} className="flex gap-2 border-b border-border py-1">
                  <span className="font-semibold">{c.nombre}</span>
                  <span className="text-muted-foreground">
                    {c.lat != null ? `${c.lat.toFixed(5)}, ${c.lng?.toFixed(5)}` : "sin ubicación"}
                  </span>
                  <span className="ml-auto text-muted-foreground">
                    {c.ubicacion_at ? horaCorta(c.ubicacion_at) : "—"}
                  </span>
                </li>
              ))}
            </ul>
          </Seccion>
        )}

        {seccion === "Balances y cadetes" && (
          <BalancesSeccion pedidos={pedidos.data ?? []} cadetes={cadetes.data ?? []} />
        )}

        {seccion === "Historial y Excel" && <HistorialSeccion pedidos={pedidos.data ?? []} />}

        {seccion === "Tutorial del cliente" && config.data && (
          <Seccion titulo="Tutorial del cliente">
            <CampoSwitch
              label="Tutorial en el primer acceso"
              value={config.data.general.tutorial_activo}
              onChange={async (v) => {
                await guardarConfig("general", { ...config.data!.general, tutorial_activo: v });
                void config.refetch();
                avisar("Tutorial actualizado");
              }}
            />
          </Seccion>
        )}

        {seccion === "Configuración general" && config.data && (
          <ConfiguracionSeccion
            config={config.data}
            stock={stock.data ?? []}
            cadetes={cadetes.data ?? []}
            recargar={() => {
              void config.refetch();
              void stock.refetch();
              void cadetes.refetch();
            }}
            avisar={avisar}
          />
        )}
      </main>
    </div>
  );
}

function AnunciosSeccion({ anuncios, categorias, productos, recargar, avisar }: {
  anuncios: Awaited<ReturnType<typeof fetchAnuncios>>;
  categorias: Awaited<ReturnType<typeof fetchCategorias>>;
  productos: Awaited<ReturnType<typeof fetchProductos>>;
  recargar: () => void;
  avisar: (texto: string) => void;
}) {
  const [subiendo, setSubiendo] = useState<string | null>(null);
  const actualizar = async (id: string, campos: object) => {
    const { error } = await supabase.from("anuncios").update(campos).eq("id", id);
    if (error) throw error;
    recargar();
  };
  const cargarImagen = async (id: string, file?: File) => {
    if (!file) return;
    setSubiendo(id);
    try {
      const imagen_url = await subirImagen(file, "anuncios", 1200);
      await actualizar(id, { imagen_url });
      avisar("Imagen del anuncio cargada");
    } catch (error) {
      avisar(error instanceof Error ? error.message : "No pudimos cargar la imagen");
    } finally {
      setSubiendo(null);
    }
  };

  return (
    <Seccion titulo="Anuncios / Ventanas Emergentes">
      <button type="button" onClick={async () => {
        await supabase.from("anuncios").insert({ titulo: "Nuevo anuncio", orden: anuncios.length + 1 });
        recargar();
        avisar("Anuncio creado");
      }} className="btn-base btn-primary mb-4 text-sm">+ Nuevo anuncio</button>
      <div className="space-y-4">
        {anuncios.map((anuncio) => (
          <div key={anuncio.id} className="panel grid gap-3 p-3 md:grid-cols-2">
            <CampoTexto label="Título" value={anuncio.titulo} onChange={(value) => void actualizar(anuncio.id, { titulo: value })} />
            <Campo label="Tamaño">
              <select value={anuncio.tamano} onChange={(event) => void actualizar(anuncio.id, { tamano: event.target.value })} className="field">
                <option value="chico">Chico</option><option value="mediano">Mediano</option><option value="grande">Grande</option>
              </select>
            </Campo>
            <Campo label="Subir imagen propia">
              <input type="file" accept="image/*" disabled={subiendo === anuncio.id} onChange={(event) => void cargarImagen(anuncio.id, event.target.files?.[0])} className="field" />
              {subiendo === anuncio.id ? <span className="text-xs text-muted-foreground">Optimizando imagen…</span> : null}
            </Campo>
            <CampoTexto label="Imagen alternativa (URL)" value={anuncio.imagen_url?.startsWith("data:") ? "" : anuncio.imagen_url ?? ""} placeholder="https://…" onChange={(value) => void actualizar(anuncio.id, { imagen_url: value })} />
            {anuncio.imagen_url ? <img src={anuncio.imagen_url} alt="Vista previa" className="h-40 w-full rounded-lg object-cover md:col-span-2" /> : null}
            <CampoSwitch label="Botón de acción" value={anuncio.tiene_boton} onChange={(value) => void actualizar(anuncio.id, { tiene_boton: value })} />
            <CampoSwitch label="Anuncio activo" value={anuncio.activo} onChange={(value) => void actualizar(anuncio.id, { activo: value })} />
            {anuncio.tiene_boton ? <>
              <CampoTexto label="Texto del botón" value={anuncio.boton_texto} onChange={(value) => void actualizar(anuncio.id, { boton_texto: value })} />
              <Campo label="Destino">
                <select value={anuncio.destino_tipo} onChange={(event) => void actualizar(anuncio.id, { destino_tipo: event.target.value, destino: null })} className="field">
                  <option value="producto">Producto</option><option value="categoria">Categoría</option><option value="link">Link externo</option>
                </select>
              </Campo>
              <Campo label={anuncio.destino_tipo === "link" ? "Link externo" : anuncio.destino_tipo === "producto" ? "Producto" : "Categoría"}>
                {anuncio.destino_tipo === "link" ? <input value={anuncio.destino ?? ""} onChange={(event) => void actualizar(anuncio.id, { destino: event.target.value })} placeholder="https://…" className="field" /> : (
                  <select value={anuncio.destino ?? ""} onChange={(event) => void actualizar(anuncio.id, { destino: event.target.value })} className="field">
                    <option value="">Elegir…</option>
                    {(anuncio.destino_tipo === "producto" ? productos : categorias).map((item) => <option key={item.id} value={item.id}>{item.nombre}</option>)}
                  </select>
                )}
              </Campo>
            </> : null}
            <CampoTexto label="Orden" tipo="number" value={anuncio.orden} onChange={(value) => void actualizar(anuncio.id, { orden: Number(value) || 0 })} />
            <button type="button" onClick={async () => { await supabase.from("anuncios").delete().eq("id", anuncio.id); recargar(); }} className="btn-base btn-danger self-end text-sm">Eliminar anuncio</button>
          </div>
        ))}
      </div>
    </Seccion>
  );
}

/* ---------- 1. Accesos ---------- */
function AccesosSeccion({
  adminPassword,
  avisar,
}: {
  adminPassword: string;
  avisar: (t: string) => void;
}) {
  const [valores, setValores] = useState({ admin: "", cocina: "", envios: "" });
  const [error, setError] = useState("");

  async function guardar(sector: "admin" | "cocina" | "envios") {
    const nueva = valores[sector].trim();
    if (nueva.length < 4) {
      setError("La contraseña debe tener al menos 4 caracteres.");
      return;
    }
    setError("");
    const ok = await cambiarAcceso(adminPassword, sector, nueva);
    if (!ok) {
      setError("No se pudo actualizar la contraseña.");
      return;
    }
    if (sector === "admin") sessionStorage.setItem("skazy_acceso_admin", nueva);
    setValores((v) => ({ ...v, [sector]: "" }));
    avisar(`Contraseña de ${sector} actualizada`);
  }

  return (
    <Seccion titulo="Accesos y seguridad">
      {error && <p className="mb-2 text-sm text-destructive">{error}</p>}
      {(["admin", "cocina", "envios"] as const).map((s) => (
        <div key={s} className="mb-4 border-b border-border pb-4">
          <CampoTexto
            label={`Contraseña de ${s === "admin" ? "Administración" : s === "cocina" ? "Cocina" : "Envíos"}`}
            tipo="password"
            value={valores[s]}
            onChange={(v) => setValores((prev) => ({ ...prev, [s]: v }))}
          />
          <button type="button" onClick={() => guardar(s)} className="btn-base btn-base-active btn-primary mt-2 text-sm">
            Guardar
          </button>
        </div>
      ))}
    </Seccion>
  );
}

/* ---------- 2. Menú ---------- */
function MenuSeccion({
  categorias,
  productos,
  recargar,
  avisar,
}: {
  categorias: Awaited<ReturnType<typeof fetchCategorias>>;
  productos: Awaited<ReturnType<typeof fetchProductos>>;
  recargar: () => void;
  avisar: (t: string) => void;
}) {
  const [nuevaCat, setNuevaCat] = useState("");

  async function crearCategoria() {
    if (!nuevaCat.trim()) return;
    const { error } = await supabase.from("categorias").insert({ nombre: nuevaCat.trim(), orden: categorias.length + 1 });
    if (error) {
      avisar("No se pudo crear la categoría");
      return;
    }
    setNuevaCat("");
    recargar();
    avisar("Categoría creada");
  }

  async function actualizarCat(id: string, campos: object) {
    const { error } = await supabase.from("categorias").update(campos).eq("id", id);
    if (error) {
      avisar("No se pudo actualizar la categoría");
      return;
    }
    recargar();
    avisar("Categoría actualizada");
  }

  async function borrarCat(id: string) {
    const { error: productosError } = await supabase.from("productos").update({ categoria_id: null }).eq("categoria_id", id);
    if (productosError) {
      avisar("No se pudo desvincular la categoría de sus productos");
      return;
    }
    const { error } = await supabase.from("categorias").delete().eq("id", id);
    if (error) {
      avisar("No se pudo eliminar la categoría");
      return;
    }
    recargar();
    avisar("Categoría eliminada; sus productos se conservaron");
  }

  async function crearProducto() {
    await supabase.from("productos").insert({
      nombre: "Producto nuevo",
      precio: 0,
      categoria_id: categorias[0]?.id ?? null,
      orden: productos.length + 1,
    });
    recargar();
    avisar("Producto creado");
  }

  async function actualizarProd(id: string, campos: object) {
    const { error } = await supabase.from("productos").update(campos).eq("id", id);
    if (error) throw error;
    recargar();
  }

  async function borrarProd(id: string) {
    await supabase.from("productos").delete().eq("id", id);
    recargar();
  }

  return (
    <>
      <Seccion titulo="Categorías">
        <div className="mb-3 flex gap-2">
          <input
            value={nuevaCat}
            onChange={(e) => setNuevaCat(e.target.value)}
            placeholder="Nombre de la categoría"
            className="field"
          />
          <button type="button" onClick={crearCategoria} className="btn-base btn-primary text-sm">
            Agregar
          </button>
        </div>
        {categorias.map((c) => (
          <div key={c.id} className="mb-2 flex flex-wrap items-end gap-2 border-b border-border pb-2">
            <input
              defaultValue={c.nombre}
              onBlur={(e) => actualizarCat(c.id, { nombre: e.target.value })}
              className="field max-w-52"
            />
            <input
              type="number"
              defaultValue={c.orden}
              onBlur={(e) => actualizarCat(c.id, { orden: Number(e.target.value) })}
              className="field max-w-24"
              title="Orden"
            />
            <input
              defaultValue={c.logo_url ?? ""}
              onBlur={(e) => actualizarCat(c.id, { logo_url: e.target.value })}
              placeholder="URL del logo"
              className="field max-w-64"
            />
            <button
              type="button"
              onClick={() => actualizarCat(c.id, { visible: !c.visible })}
              className={`btn-base text-sm ${c.visible ? "btn-accent" : "btn-ghost"}`}
            >
              {c.visible ? "Visible" : "Oculta"}
            </button>
            <button type="button" onClick={() => borrarCat(c.id)} className="btn-base btn-danger text-sm">
              Eliminar
            </button>
          </div>
        ))}
      </Seccion>

      <Seccion titulo="Productos">
        <button type="button" onClick={crearProducto} className="btn-base btn-primary mb-3 text-sm">
          + Nuevo producto
        </button>
        <div className="space-y-3">
          {productos.map((p) => (
            <div key={p.id} className="panel grid gap-2 p-3 md:grid-cols-2">
              <CampoTexto label="Nombre" value={p.nombre} onChange={(v) => actualizarProd(p.id, { nombre: v })} />
              <CampoTexto
                label="Precio"
                tipo="number"
                value={p.precio}
                onChange={(v) => actualizarProd(p.id, { precio: Number(v) || 0 })}
              />
              <CampoArea
                label="Descripción"
                value={p.descripcion ?? ""}
                onChange={(v) => actualizarProd(p.id, { descripcion: v })}
              />
              <ProductoOpcionesAdmin key={`${p.id}-${JSON.stringify(p.grupos_modificadores)}-${p.descripcion_detallada}-${p.sugeridos_ids?.join(",")}`} producto={p} productos={productos} guardar={actualizarProd} avisar={avisar} />
              <div className="grid gap-2">
                <CampoImagen
                  label="Imagen principal (sin fondo)"
                  value={p.imagen_url ?? ""}
                  carpeta="productos"
                  onChange={(v) => actualizarProd(p.id, { imagen_url: v })}
                />
                <CampoImagen
                  label="Segunda imagen (aparece al tocar)"
                  value={p.imagen_hover_url ?? ""}
                  carpeta="productos"
                  onChange={(v) => actualizarProd(p.id, { imagen_hover_url: v })}
                />
              </div>
              <Campo label="Categoría">
                <select
                  value={p.categoria_id ?? ""}
                  onChange={(e) => actualizarProd(p.id, { categoria_id: e.target.value || null })}
                  className="field"
                >
                  <option value="">Sin categoría</option>
                  {categorias.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.nombre}
                    </option>
                  ))}
                </select>
              </Campo>
              <CampoTexto
                label="Orden"
                tipo="number"
                value={p.orden}
                onChange={(v) => actualizarProd(p.id, { orden: Number(v) || 0 })}
              />
              <div className="grid grid-cols-2 gap-2 md:col-span-2">
                <CampoSwitch label="Visible" value={p.visible} onChange={(v) => actualizarProd(p.id, { visible: v })} />
                <CampoSwitch label="Agotado" value={p.agotado} onChange={(v) => actualizarProd(p.id, { agotado: v })} />
                <CampoSwitch
                  label="Destacado"
                  value={p.destacado}
                  onChange={(v) => actualizarProd(p.id, { destacado: v })}
                />
                <CampoSwitch
                  label="Más vendido"
                  value={p.mas_vendido}
                  onChange={(v) => actualizarProd(p.id, { mas_vendido: v })}
                />
              </div>
              <button
                type="button"
                onClick={() => borrarProd(p.id)}
                className="btn-base btn-danger text-sm md:col-span-2"
              >
                Eliminar producto
              </button>
            </div>
          ))}
        </div>
      </Seccion>
    </>
  );
}

/* ---------- 3. Códigos ---------- */
function CodigosSeccion({
  codigos,
  recargar,
  avisar,
}: {
  codigos: Awaited<ReturnType<typeof fetchCodigos>>;
  recargar: () => void;
  avisar: (t: string) => void;
}) {
  const [nuevo, setNuevo] = useState({ codigo: "", porcentaje: "" });

  async function crear() {
    if (!nuevo.codigo.trim()) return;
    await supabase.from("codigos_descuento").insert({
      codigo: nuevo.codigo.trim().toUpperCase(),
      porcentaje: Number(nuevo.porcentaje) || 0,
    });
    setNuevo({ codigo: "", porcentaje: "" });
    recargar();
    avisar("Código creado");
  }

  return (
    <Seccion titulo="Códigos de descuento">
      <div className="mb-4 flex flex-wrap gap-2">
        <input
          value={nuevo.codigo}
          onChange={(e) => setNuevo({ ...nuevo, codigo: e.target.value })}
          placeholder="Código"
          className="field max-w-40"
        />
        <input
          value={nuevo.porcentaje}
          onChange={(e) => setNuevo({ ...nuevo, porcentaje: e.target.value })}
          placeholder="%"
          type="number"
          className="field max-w-24"
        />
        <button type="button" onClick={crear} className="btn-base btn-primary text-sm">
          Agregar
        </button>
      </div>
      {codigos.map((c) => (
        <div key={c.id} className="mb-2 flex flex-wrap items-center gap-2 border-b border-border pb-2">
          <input
            defaultValue={c.codigo}
            onBlur={(e) =>
              supabase
                .from("codigos_descuento")
                .update({ codigo: e.target.value.toUpperCase() })
                .eq("id", c.id)
                .then(recargar)
            }
            className="field max-w-40"
          />
          <input
            type="number"
            defaultValue={c.porcentaje}
            onBlur={(e) =>
              supabase
                .from("codigos_descuento")
                .update({ porcentaje: Number(e.target.value) || 0 })
                .eq("id", c.id)
                .then(recargar)
            }
            className="field max-w-24"
          />
          <input
            type="date"
            defaultValue={c.expira_at ? c.expira_at.slice(0, 10) : ""}
            onBlur={(e) =>
              supabase
                .from("codigos_descuento")
                .update({ expira_at: e.target.value ? new Date(e.target.value).toISOString() : null })
                .eq("id", c.id)
                .then(recargar)
            }
            className="field max-w-44"
          />
          <button
            type="button"
            onClick={() =>
              supabase.from("codigos_descuento").update({ activo: !c.activo }).eq("id", c.id).then(recargar)
            }
            className={`btn-base text-sm ${c.activo ? "btn-accent" : "btn-ghost"}`}
          >
            {c.activo ? "Activo" : "Inactivo"}
          </button>
          <button
            type="button"
            onClick={() => supabase.from("codigos_descuento").delete().eq("id", c.id).then(recargar)}
            className="btn-base btn-danger text-sm"
          >
            Eliminar
          </button>
        </div>
      ))}
    </Seccion>
  );
}

/* ---------- 5. Barra de logos ---------- */
function LogosSeccion({
  logos,
  categorias,
  config,
  recargar,
  avisar,
}: {
  logos: Awaited<ReturnType<typeof fetchLogos>>;
  categorias: Awaited<ReturnType<typeof fetchCategorias>>;
  config: Config;
  recargar: () => void;
  avisar: (t: string) => void;
}) {
  const [cfg, setCfg] = useState(config.logos);

  return (
    <Seccion titulo="Barra de logos por categoría">
      <div className="mb-4 grid gap-2 md:grid-cols-2">
        <CampoTexto
          label="Cantidad de logos"
          tipo="number"
          value={cfg.cantidad}
          onChange={(v) => setCfg({ ...cfg, cantidad: Number(v) || 1 })}
        />
        <CampoTexto
          label="Velocidad (px por segundo aprox.)"
          tipo="number"
          value={cfg.velocidad}
          onChange={(v) => setCfg({ ...cfg, velocidad: Number(v) || 30 })}
        />
        <CampoTexto
          label="Segundos de movimiento (duración del ciclo)"
          tipo="number"
          value={cfg.segundos}
          onChange={(v) => setCfg({ ...cfg, segundos: Number(v) || 20 })}
        />
        <CampoSwitch label="Barra visible" value={cfg.activo} onChange={(v) => setCfg({ ...cfg, activo: v })} />
      </div>
      <button
        type="button"
        onClick={async () => {
          await guardarConfig("logos", cfg);
          recargar();
          avisar("Barra de logos actualizada");
        }}
        className="btn-base btn-primary mb-4 text-sm"
      >
        Guardar
      </button>

      <button
        type="button"
        onClick={async () => {
          await supabase.from("logos_categoria").insert({ titulo: "Nuevo logo", orden: logos.length + 1 });
          recargar();
        }}
        className="btn-base btn-ghost mb-3 ml-2 text-sm"
      >
        + Nuevo logo
      </button>

      {logos.map((l) => (
        <div key={l.id} className="mb-2 flex flex-wrap items-center gap-2 border-b border-border pb-2">
          <input
            defaultValue={l.titulo}
            onBlur={(e) => supabase.from("logos_categoria").update({ titulo: e.target.value }).eq("id", l.id).then(recargar)}
            className="field max-w-40"
          />
          <CampoImagen
            label="Imagen del logo"
            value={l.imagen_url ?? ""}
            carpeta="logos"
            ancho={600}
            onChange={(v) => supabase.from("logos_categoria").update({ imagen_url: v }).eq("id", l.id).then(recargar)}
          />
          <select
            defaultValue={l.categoria_id ?? ""}
            onChange={(e) =>
              supabase
                .from("logos_categoria")
                .update({ categoria_id: e.target.value || null })
                .eq("id", l.id)
                .then(recargar)
            }
            className="field max-w-40"
          >
            <option value="">Sin categoría</option>
            {categorias.map((c) => (
              <option key={c.id} value={c.id}>
                {c.nombre}
              </option>
            ))}
          </select>
          <input
            type="number"
            defaultValue={l.orden}
            onBlur={(e) =>
              supabase.from("logos_categoria").update({ orden: Number(e.target.value) || 0 }).eq("id", l.id).then(recargar)
            }
            className="field max-w-24"
          />
          <button
            type="button"
            onClick={() => supabase.from("logos_categoria").update({ activo: !l.activo }).eq("id", l.id).then(recargar)}
            className={`btn-base text-sm ${l.activo ? "btn-accent" : "btn-ghost"}`}
          >
            {l.activo ? "Activo" : "Inactivo"}
          </button>
          <button
            type="button"
            onClick={() => supabase.from("logos_categoria").delete().eq("id", l.id).then(recargar)}
            className="btn-base btn-danger text-sm"
          >
            Eliminar
          </button>
        </div>
      ))}
    </Seccion>
  );
}

/* ---------- 6. Pagos ---------- */
function PagosSeccion({
  config,
  recargar,
  avisar,
}: {
  config: Config;
  recargar: () => void;
  avisar: (t: string) => void;
}) {
  const [pagos, setPagos] = useState(config.pagos);
  return (
    <Seccion titulo="Pagos y cobros">
      <div className="grid gap-2 md:grid-cols-2">
        <CampoTexto label="Alias" value={pagos.alias} onChange={(v) => setPagos({ ...pagos, alias: v })} />
        <CampoTexto label="Medio de pago" value={pagos.medio} onChange={(v) => setPagos({ ...pagos, medio: v })} />
        <CampoTexto label="Titular" value={pagos.titular} onChange={(v) => setPagos({ ...pagos, titular: v })} />
        <CampoImagen label="Imagen del QR de pago" value={pagos.qr_url} carpeta="pagos" ancho={900} tipo="image/png" onChange={(v) => setPagos({ ...pagos, qr_url: v })} />
      </div>
      {pagos.qr_url && (
        <div className="mt-3">
          <p className="text-sm text-muted-foreground">Vista previa del QR:</p>
          <img src={pagos.qr_url} alt="QR de pago" className="mt-1 h-48 w-48 rounded-lg object-contain" />
        </div>
      )}
      <button
        type="button"
        onClick={async () => {
          await guardarConfig("pagos", pagos);
          recargar();
          avisar("Datos de pago actualizados");
        }}
        className="btn-base btn-primary mt-3 text-sm"
      >
        Guardar
      </button>
    </Seccion>
  );
}

/* ---------- 8. Balances ---------- */
function BalancesSeccion({
  pedidos,
  cadetes,
}: {
  pedidos: Awaited<ReturnType<typeof fetchPedidos>>;
  cadetes: Awaited<ReturnType<typeof fetchCadetes>>;
}) {
  const [filtro, setFiltro] = useState<"dia" | "semana" | "mes">("dia");

  const entregados = useMemo(() => {
    const ahora = Date.now();
    const rango = filtro === "dia" ? 1 : filtro === "semana" ? 7 : 30;
    return pedidos.filter(
      (p) =>
        p.estado === "ENTREGADO" &&
        ahora - new Date(p.entregado_at ?? p.created_at).getTime() <= rango * 24 * 3600 * 1000,
    );
  }, [pedidos, filtro]);

  const efectivo = entregados.filter((p) => p.metodo_pago === "EFECTIVO");
  const transfer = entregados.filter((p) => p.metodo_pago === "TRANSFERENCIA");

  return (
    <Seccion titulo="Balances y cadetes">
      <div className="mb-3 flex gap-2">
        {(["dia", "semana", "mes"] as const).map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => setFiltro(f)}
            className={`btn-base text-sm ${filtro === f ? "chip-activa" : "btn-ghost"}`}
          >
            {f === "dia" ? "Día" : f === "semana" ? "Semana" : "Mes"}
          </button>
        ))}
      </div>
      <div className="grid gap-2 md:grid-cols-3">
        <div className="total-box p-3">
          <p className="text-sm text-muted-foreground">Total efectivo</p>
          <p className="text-2xl font-bold text-accent">
            {money(efectivo.reduce((a, p) => a + Number(p.total), 0))}
          </p>
          <p className="text-xs text-muted-foreground">{efectivo.length} pagos</p>
        </div>
        <div className="total-box p-3">
          <p className="text-sm text-muted-foreground">Total transferencias</p>
          <p className="text-2xl font-bold text-accent">
            {money(transfer.reduce((a, p) => a + Number(p.total), 0))}
          </p>
          <p className="text-xs text-muted-foreground">{transfer.length} pagos</p>
        </div>
        <div className="total-box p-3">
          <p className="text-sm text-muted-foreground">Pedidos entregados</p>
          <p className="text-2xl font-bold text-primary">{entregados.length}</p>
        </div>
      </div>

      <h3 className="mb-2 mt-4 text-xl">Por cadete</h3>
      {cadetes.map((c) => {
        const suyos = entregados.filter((p) => p.cadete_id === c.id);
        const ef = suyos.filter((p) => p.metodo_pago === "EFECTIVO");
        return (
          <div key={c.id} className="flex flex-wrap gap-3 border-b border-border py-2 text-sm">
            <span className="font-semibold">{c.nombre}</span>
            <span>{suyos.length} entregas</span>
            <span>Efectivo: {money(ef.reduce((a, p) => a + Number(p.total), 0))}</span>
            <span>
              Transferencias:{" "}
              {money(
                suyos
                  .filter((p) => p.metodo_pago === "TRANSFERENCIA")
                  .reduce((a, p) => a + Number(p.total), 0),
              )}
            </span>
          </div>
        );
      })}
    </Seccion>
  );
}

/* ---------- 9. Historial ---------- */
function HistorialSeccion({ pedidos }: { pedidos: Awaited<ReturnType<typeof fetchPedidos>> }) {
  const [estado, setEstado] = useState("");
  const filtrados = pedidos.filter((p) => (estado ? p.estado === estado : true));

  return (
    <Seccion titulo="Historial y Excel">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <select value={estado} onChange={(e) => setEstado(e.target.value)} className="field max-w-48">
          <option value="">Todos los estados</option>
          {["CLIENTE", "COCINA", "ENVIOS", "ENTREGADO", "CANCELADO"].map((e) => (
            <option key={e} value={e}>
              {e}
            </option>
          ))}
        </select>
        <button
          type="button"
          onClick={() => void exportarPedidosExcel(pedidos)}
          className="btn-base btn-base-active btn-primary text-sm"
        >
          Descargar todos los pedidos
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="text-muted-foreground">
            <tr>
              {["Código", "Nombre", "Teléfono", "Detalle", "Monto", "Pago", "Fecha", "Hora", "Estado"].map((h) => (
                <th key={h} className="border-b border-border py-2 pr-3">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtrados.map((p) => (
              <tr key={p.id}>
                <td className="border-b border-border py-2 pr-3 text-accent">{p.grupo_codigo || p.codigo}</td>
                <td className="border-b border-border py-2 pr-3">{p.cliente_nombre}</td>
                <td className="border-b border-border py-2 pr-3">{p.telefono}</td>
                <td className="border-b border-border py-2 pr-3">
                  {(p.pedido_items ?? []).map((i) => `${i.cantidad}x ${i.nombre}`).join(", ")}
                </td>
                <td className="border-b border-border py-2 pr-3">{money(p.total)}</td>
                <td className="border-b border-border py-2 pr-3">{p.metodo_pago}</td>
                <td className="border-b border-border py-2 pr-3">{fechaCorta(p.created_at)}</td>
                <td className="border-b border-border py-2 pr-3">{horaCorta(p.created_at)}</td>
                <td className="border-b border-border py-2 pr-3">{p.estado}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Seccion>
  );
}

/* ---------- 11. Configuración general ---------- */
function ConfiguracionSeccion({
  config,
  stock,
  cadetes,
  recargar,
  avisar,
}: {
  config: Config;
  stock: Awaited<ReturnType<typeof fetchStock>>;
  cadetes: Awaited<ReturnType<typeof fetchCadetes>>;
  recargar: () => void;
  avisar: (t: string) => void;
}) {
  const [general, setGeneral] = useState(config.general);
  const [zona, setZona] = useState(config.zona);
  const [nuevoCadete, setNuevoCadete] = useState("");
  const [nuevoIngrediente, setNuevoIngrediente] = useState("");

  return (
    <>
      <Seccion titulo="Textos y horarios">
        <div className="grid gap-2 md:grid-cols-2">
          <CampoTexto label="Nombre del local" value={general.nombre_local} onChange={(v) => setGeneral({ ...general, nombre_local: v })} />
          <CampoTexto label="WhatsApp del local" value={general.whatsapp} onChange={(v) => setGeneral({ ...general, whatsapp: v })} />
          <CampoTexto label="Horarios del local" value={general.horarios} onChange={(v) => setGeneral({ ...general, horarios: v })} />
          <CampoTexto label="Texto de sucursales" value={general.sucursales_texto} onChange={(v) => setGeneral({ ...general, sucursales_texto: v })} />
          <CampoTexto label="Tiempo Lun — Jue" value={general.tiempo_lun_jue} onChange={(v) => setGeneral({ ...general, tiempo_lun_jue: v })} />
          <CampoTexto label="Tiempo Vie — Dom" value={general.tiempo_vie_dom} onChange={(v) => setGeneral({ ...general, tiempo_vie_dom: v })} />
          <CampoTexto label="Texto de urgencia" value={general.urgencia_texto} onChange={(v) => setGeneral({ ...general, urgencia_texto: v })} />
          <CampoTexto label="Texto de confianza del checkout" value={general.texto_confianza} onChange={(v) => setGeneral({ ...general, texto_confianza: v })} />
          <CampoArea label="Aviso del checkout" value={general.aviso_checkout} onChange={(v) => setGeneral({ ...general, aviso_checkout: v })} />
          <CampoArea label="Texto sobre la zona de envío" value={general.texto_zona} onChange={(v) => setGeneral({ ...general, texto_zona: v })} />
          <CampoArea label="Texto del vuelto" value={general.texto_vuelto} onChange={(v) => setGeneral({ ...general, texto_vuelto: v })} />
          <CampoArea label="Texto de dudas de tiempo" value={general.texto_dudas_tiempo} onChange={(v) => setGeneral({ ...general, texto_dudas_tiempo: v })} />
          <CampoArea label="Mensaje final del cliente" value={general.texto_final} onChange={(v) => setGeneral({ ...general, texto_final: v })} />
          <CampoSwitch label="Local abierto" value={general.abierto} onChange={(v) => setGeneral({ ...general, abierto: v })} />
          <CampoSwitch label="Tutorial del cliente" value={general.tutorial_activo} onChange={(v) => setGeneral({ ...general, tutorial_activo: v })} />
        </div>
        <button
          type="button"
          onClick={async () => {
            await guardarConfig("general", general);
            recargar();
            avisar("Configuración general guardada");
          }}
          className="btn-base btn-primary mt-3 text-sm"
        >
          Guardar
        </button>
      </Seccion>

      <Seccion titulo="Zona geográfica permitida">
        <div className="grid gap-2 md:grid-cols-2">
          <CampoTexto label="Latitud mínima" value={zona.lat_min} onChange={(v) => setZona({ ...zona, lat_min: Number(v) })} />
          <CampoTexto label="Latitud máxima" value={zona.lat_max} onChange={(v) => setZona({ ...zona, lat_max: Number(v) })} />
          <CampoTexto label="Longitud mínima" value={zona.lng_min} onChange={(v) => setZona({ ...zona, lng_min: Number(v) })} />
          <CampoTexto label="Longitud máxima" value={zona.lng_max} onChange={(v) => setZona({ ...zona, lng_max: Number(v) })} />
          <CampoTexto label="Latitud de la sucursal" value={zona.sucursal_lat} onChange={(v) => setZona({ ...zona, sucursal_lat: Number(v) })} />
          <CampoTexto label="Longitud de la sucursal" value={zona.sucursal_lng} onChange={(v) => setZona({ ...zona, sucursal_lng: Number(v) })} />
          <CampoArea label="Mensaje dentro de la zona" value={zona.mensaje_dentro} onChange={(v) => setZona({ ...zona, mensaje_dentro: v })} />
          <CampoArea label="Mensaje fuera de la zona" value={zona.mensaje_fuera} onChange={(v) => setZona({ ...zona, mensaje_fuera: v })} />
        </div>
        <div className="mt-3">
          <MapaClient
            centro={{ lat: (zona.lat_min + zona.lat_max) / 2, lng: (zona.lng_min + zona.lng_max) / 2 }}
            alto={260}
            rectangulo={zona}
            marcadores={[{ lat: zona.sucursal_lat, lng: zona.sucursal_lng, titulo: "Sucursal", color: "#f59e0b" }]}
          />
        </div>
        <button
          type="button"
          onClick={async () => {
            await guardarConfig("zona", zona);
            recargar();
            avisar("Zona de entrega guardada");
          }}
          className="btn-base btn-primary mt-3 text-sm"
        >
          Guardar
        </button>
      </Seccion>

      <Seccion titulo="Cadetes">
        <div className="mb-3 flex gap-2">
          <input
            value={nuevoCadete}
            onChange={(e) => setNuevoCadete(e.target.value)}
            placeholder="Nombre del cadete"
            className="field max-w-64"
          />
          <button
            type="button"
            onClick={async () => {
              if (!nuevoCadete.trim()) return;
              await supabase.from("cadetes").insert({ nombre: nuevoCadete.trim() });
              setNuevoCadete("");
              recargar();
            }}
            className="btn-base btn-primary text-sm"
          >
            Agregar
          </button>
        </div>
        {cadetes.map((c) => (
          <div key={c.id} className="mb-2 flex flex-wrap items-center gap-2 border-b border-border pb-2">
            <input
              defaultValue={c.nombre}
              onBlur={(e) => supabase.from("cadetes").update({ nombre: e.target.value }).eq("id", c.id).then(recargar)}
              className="field max-w-48"
            />
            <input
              defaultValue={c.telefono ?? ""}
              placeholder="Teléfono"
              onBlur={(e) => supabase.from("cadetes").update({ telefono: e.target.value }).eq("id", c.id).then(recargar)}
              className="field max-w-40"
            />
            <button
              type="button"
              onClick={() => supabase.from("cadetes").update({ activo: !c.activo }).eq("id", c.id).then(recargar)}
              className={`btn-base text-sm ${c.activo ? "btn-accent" : "btn-ghost"}`}
            >
              {c.activo ? "Activo" : "Inactivo"}
            </button>
            <button
              type="button"
              onClick={() => supabase.from("cadetes").delete().eq("id", c.id).then(recargar)}
              className="btn-base btn-danger text-sm"
            >
              Eliminar
            </button>
          </div>
        ))}
      </Seccion>

      <Seccion titulo="Stock e ingredientes">
        <div className="mb-3 flex gap-2">
          <input
            value={nuevoIngrediente}
            onChange={(e) => setNuevoIngrediente(e.target.value)}
            placeholder="Ingrediente"
            className="field max-w-64"
          />
          <button
            type="button"
            onClick={async () => {
              if (!nuevoIngrediente.trim()) return;
              await supabase.from("stock").insert({ ingrediente: nuevoIngrediente.trim(), orden: stock.length + 1 });
              setNuevoIngrediente("");
              recargar();
            }}
            className="btn-base btn-primary text-sm"
          >
            Agregar
          </button>
        </div>
        {stock.map((s) => (
          <div key={s.id} className="mb-2 flex flex-wrap items-center gap-2 border-b border-border pb-2">
            <input
              defaultValue={s.ingrediente}
              onBlur={(e) => supabase.from("stock").update({ ingrediente: e.target.value }).eq("id", s.id).then(recargar)}
              className="field max-w-48"
            />
            <input
              defaultValue={s.aviso ?? ""}
              placeholder="Aviso configurable"
              onBlur={(e) => supabase.from("stock").update({ aviso: e.target.value }).eq("id", s.id).then(recargar)}
              className="field max-w-64"
            />
            <button
              type="button"
              onClick={() => supabase.from("stock").update({ disponible: !s.disponible }).eq("id", s.id).then(recargar)}
              className={`btn-base text-sm ${s.disponible ? "btn-accent" : "btn-ghost"}`}
            >
              {s.disponible ? "Disponible" : "Faltante"}
            </button>
            <button
              type="button"
              onClick={() => supabase.from("stock").delete().eq("id", s.id).then(recargar)}
              className="btn-base btn-danger text-sm"
            >
              Eliminar
            </button>
          </div>
        ))}
      </Seccion>
    </>
  );
}
