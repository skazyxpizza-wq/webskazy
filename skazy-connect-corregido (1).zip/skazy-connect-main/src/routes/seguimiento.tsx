import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import EstadoStepper from "@/components/skazy/EstadoStepper";
import MapaClient from "@/components/skazy/MapaClient";
import { cambiarEstado, fetchCadetes, fetchConfig, fetchPedidosPorIds } from "@/lib/data";
import {
  abrirWhatsApp,
  fechaCorta,
  horaCorta,
  mensajeCancelacion,
  misPedidosIds,
  sonarAviso,
} from "@/lib/skazy";
import type { Pedido } from "@/lib/types";

export const Route = createFileRoute("/seguimiento")({
  head: () => ({
    meta: [
      { title: "Seguimiento de mi pedido — SKAZY" },
      {
        name: "description",
        content:
          "Mirá el estado de tus pedidos de SKAZY en vivo: Cliente, Cocina, Envíos y Entregado, con la ubicación del cadete.",
      },
      { property: "og:title", content: "Seguimiento de mi pedido — SKAZY" },
      {
        property: "og:description",
        content: "Estado en vivo de tus pedidos y ubicación del cadete.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SeguimientoPage,
});

function SeguimientoPage() {
  const [ids, setIds] = useState<string[]>([]);
  const [seleccionado, setSeleccionado] = useState<string | null>(null);
  const estadosPrevios = useRef<Record<string, string>>({});
  const [aviso, setAviso] = useState<{ pedidoId: string; texto: string } | null>(null);

  useEffect(() => setIds(misPedidosIds()), []);

  const { data: config } = useQuery({ queryKey: ["config"], queryFn: fetchConfig });
  const { data: cadetes = [] } = useQuery({
    queryKey: ["cadetes"],
    queryFn: fetchCadetes,
    refetchInterval: 15000,
  });
  const { data: pedidos = [], refetch } = useQuery({
    queryKey: ["mis-pedidos", ids],
    queryFn: () => fetchPedidosPorIds(ids),
    enabled: ids.length > 0,
  });

  useEffect(() => {
    if (!ids.length) return;
    const channel = supabase
      .channel("seguimiento-cliente")
      .on("postgres_changes", { event: "*", schema: "public", table: "pedidos" }, () => {
        void refetch();
      })
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [ids, refetch]);

  useEffect(() => {
    pedidos.forEach((p) => {
      const previo = estadosPrevios.current[p.id];
      if (previo && previo !== p.estado) {
        sonarAviso(2);
        setAviso({ pedidoId: p.id, texto: `Pedido ${p.codigo}: ${p.estado}` });
        if (typeof Notification !== "undefined" && Notification.permission === "granted") {
          new Notification(`SKAZY ${p.codigo}`, { body: `Nuevo estado: ${p.estado}` });
        }
      }
      estadosPrevios.current[p.id] = p.estado;
    });
  }, [pedidos]);

  useEffect(() => {
    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      void Notification.requestPermission();
    }
  }, []);

  const detalle = pedidos.find((p) => p.id === seleccionado) ?? null;

  return (
    <main className="min-h-screen px-4 pb-16 pt-4">
      <header className="mb-4 flex items-center gap-2">
        <Link to="/" className="btn-base btn-ghost px-3 py-1.5 text-sm">
          ← Volver
        </Link>
        <h1 className="text-3xl text-primary">Mis pedidos</h1>
      </header>

      {aviso && (
        <button
          type="button"
          onClick={() => {
            setSeleccionado(aviso.pedidoId);
            setAviso(null);
          }}
          className="panel mb-3 w-full border-accent p-3 text-left text-sm"
        >
          🔔 {aviso.texto} — tocá para ver el resumen
        </button>
      )}

      {!ids.length && (
        <p className="panel p-4 text-muted-foreground">
          Todavía no hiciste pedidos desde este dispositivo.
        </p>
      )}

      <p className="mb-3 text-sm text-muted-foreground">
        Cantidad de pedidos realizados: <strong className="text-foreground">{pedidos.length}</strong>
      </p>

      {detalle ? (
        <DetallePedido
          pedido={detalle}
          cadeteLat={cadetes.find((c) => c.id === detalle.cadete_id)?.lat ?? null}
          cadeteLng={cadetes.find((c) => c.id === detalle.cadete_id)?.lng ?? null}
          whatsapp={config?.general.whatsapp ?? ""}
          onVolver={() => setSeleccionado(null)}
          onActualizado={() => void refetch()}
        />
      ) : (
        <div className="space-y-3">
          {pedidos.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setSeleccionado(p.id)}
              className="panel block w-full p-3 text-left"
            >
              <div className="flex items-center gap-2">
                <span className="text-xl text-accent">{p.codigo}</span>
                <span className="ml-auto text-xs text-muted-foreground">
                  {fechaCorta(p.created_at)} · {horaCorta(p.created_at)}
                </span>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                {(p.pedido_items ?? []).map((i) => `${i.cantidad}x ${i.nombre}`).join(", ")}
              </p>
              <p className="mt-2 text-sm font-semibold text-accent">{p.estado}</p>
            </button>
          ))}
        </div>
      )}
    </main>
  );
}

function DetallePedido({
  pedido,
  cadeteLat,
  cadeteLng,
  whatsapp,
  onVolver,
  onActualizado,
}: {
  pedido: Pedido;
  cadeteLat: number | null;
  cadeteLng: number | null;
  whatsapp: string;
  onVolver: () => void;
  onActualizado: () => void;
}) {
  const [trabajando, setTrabajando] = useState(false);
  const puedeCancelar = pedido.estado === "CLIENTE" || pedido.estado === "COCINA";

  async function cancelar() {
    setTrabajando(true);
    try {
      await cambiarEstado(pedido.id, "CANCELADO", { cancelado_motivo: "Cancelado por el cliente" });
      abrirWhatsApp(whatsapp, mensajeCancelacion(pedido));
      onActualizado();
    } finally {
      setTrabajando(false);
    }
  }

  return (
    <section className="space-y-3">
      <button type="button" onClick={onVolver} className="btn-base btn-ghost px-3 py-1.5 text-sm">
        ← Volver
      </button>

      <div className="panel p-4">
        <h2 className="text-2xl text-accent">{pedido.codigo}</h2>
        <p className="text-xs text-muted-foreground">
          {fechaCorta(pedido.created_at)} · {horaCorta(pedido.created_at)}
        </p>
        <ul className="mt-3 space-y-1 text-sm">
          {(pedido.pedido_items ?? []).map((i) => (
            <li key={i.id ?? i.nombre} className="flex justify-between border-b border-border py-1">
              <span>
                {i.cantidad} x {i.nombre}
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div className="panel p-4">
        <h3 className="mb-2 text-xl">Estado</h3>
        <EstadoStepper estado={pedido.estado} />
      </div>

      {pedido.estado === "ENVIOS" && cadeteLat != null && cadeteLng != null && (
        <div className="panel p-3">
          <h3 className="mb-2 text-xl text-accent">Tu pedido está en camino 🛵</h3>
          <MapaClient
            centro={{ lat: cadeteLat, lng: cadeteLng }}
            alto={240}
            marcadores={[
              { lat: cadeteLat, lng: cadeteLng, titulo: "Cadete", color: "#22c55e" },
              ...(pedido.lat != null && pedido.lng != null
                ? [{ lat: pedido.lat, lng: pedido.lng, titulo: "Tu domicilio", color: "#ef4444" }]
                : []),
            ]}
          />
        </div>
      )}

      {pedido.estado === "ENTREGADO" && (
        <div className="panel border-success p-4 text-center">
          <p className="text-xl text-success">Entrega completada ✅</p>
          <p className="text-sm text-muted-foreground">¡Gracias por elegirnos!</p>
        </div>
      )}

      {puedeCancelar && (
        <button
          type="button"
          onClick={cancelar}
          disabled={trabajando}
          className="btn-base btn-base-active btn-danger w-full"
        >
          {trabajando ? "Cancelando…" : "Cancelar pedido"}
        </button>
      )}
      {!puedeCancelar && pedido.estado !== "CANCELADO" && (
        <p className="text-center text-xs text-muted-foreground">
          El pedido ya salió de cocina, no se puede cancelar desde la app.
        </p>
      )}
    </section>
  );
}
