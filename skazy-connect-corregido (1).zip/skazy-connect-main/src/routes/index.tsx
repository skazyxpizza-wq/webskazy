import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, Heart, Search, ShoppingBag, X } from "lucide-react";
import { FaDiscord, FaFacebookF, FaInstagram, FaTiktok, FaWhatsapp, FaYoutube } from "react-icons/fa6";
import { SiLinktree } from "react-icons/si";
import { supabase } from "@/integrations/supabase/client";
import BarraLogos from "@/components/skazy/BarraLogos";
import MapaClient from "@/components/skazy/MapaClient";
import ProductoCard from "@/components/skazy/ProductoCard";
import Tutorial from "@/components/skazy/Tutorial";
import AnuncioPopup from "@/components/skazy/AnuncioPopup";
import AnimatedNumber from "@/components/skazy/AnimatedNumber";
import RevealSection from "@/components/skazy/RevealSection";
import MarcaSkazy from "@/components/skazy/MarcaSkazy";
import FichaProducto from "@/components/skazy/FichaProducto";
import PedidoGrupalEditor from "@/components/skazy/PedidoGrupalEditor";
import { calcularPedidoGrupal } from "@/lib/pedido-grupal";
import {
  fetchAnuncios,
  fetchCategorias,
  fetchCodigos,
  fetchConfig,
  fetchLogos,
  fetchProductos,
} from "@/lib/data";
import {
  abrirWhatsApp,
  agregarMiPedido,
  dentroDeZona,
  favoritos as leerFavoritos,
  guardarFavoritos,
  guardarLocal,
  leerLocal,
  marcarTutorialVisto,
  mensajeWhatsApp,
  money,
  tutorialVisto,
} from "@/lib/skazy";
import type { CarritoItem, Pedido, PersonaGrupo, Producto, SeleccionModificador } from "@/lib/types";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SKAZY — Pedí pizzas y empanadas con envío" },
      {
        name: "description",
        content:
          "Menú de SKAZY: promos, combos, pizzas y empanadas. Pedí online, pagá en efectivo o transferencia y seguí tu envío en vivo.",
      },
      { property: "og:title", content: "SKAZY — Pedí pizzas y empanadas con envío" },
      {
        property: "og:description",
        content: "Promos, combos, pizzas y empanadas con envío a domicilio y seguimiento en vivo.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ClientePage,
});

type Ubicacion = { lat: number; lng: number } | null;

const REDES = [
  { nombre: "Instagram", href: "https://www.instagram.com/skazy.p", icono: FaInstagram },
  { nombre: "TikTok", href: "https://www.tiktok.com/@skazy.p", icono: FaTiktok },
  { nombre: "YouTube", href: "https://www.youtube.com/channel/UC46HhYkB1pOZWVSHhBXGAcQ", icono: FaYoutube },
  { nombre: "Facebook", href: "https://www.facebook.com/people/Skazy/61591492322591/", icono: FaFacebookF },
  { nombre: "WhatsApp", href: "https://api.whatsapp.com/send/?phone=543812119906&text&type=phone_number&app_absent=0", icono: FaWhatsapp },
  { nombre: "Canal de WhatsApp", href: "https://www.whatsapp.com/channel/0029Vb8OHLk1nozB3jBZmv1T", icono: FaWhatsapp },
  { nombre: "Discord", href: "https://discord.com/invite/wcduWr6NGS", icono: FaDiscord },
  { nombre: "Linktree", href: "https://linktr.ee/skazy", icono: SiLinktree },
] as const;

function ClientePage() {
  const { data: config } = useQuery({ queryKey: ["config"], queryFn: fetchConfig });
  const { data: categorias = [] } = useQuery({ queryKey: ["categorias"], queryFn: fetchCategorias });
  const { data: productos = [] } = useQuery({ queryKey: ["productos"], queryFn: fetchProductos });
  const { data: logos = [] } = useQuery({ queryKey: ["logos"], queryFn: fetchLogos });
  const { data: codigos = [] } = useQuery({ queryKey: ["codigos"], queryFn: fetchCodigos });
  const { data: anuncios = [] } = useQuery({ queryKey: ["anuncios"], queryFn: fetchAnuncios });

  const [busquedaAbierta, setBusquedaAbierta] = useState(false);
  const [busqueda, setBusqueda] = useState("");
  const [categoriaSel, setCategoriaSel] = useState<string | null>(null);
  const [soloFavoritos, setSoloFavoritos] = useState(false);
  const [favs, setFavs] = useState<string[]>([]);
  const [carrito, setCarrito] = useState<CarritoItem[]>([]);
  const [vista, setVista] = useState<"menu" | "checkout" | "final">("menu");
  const [mostrarTutorial, setMostrarTutorial] = useState(false);
  const [carritoAbierto, setCarritoAbierto] = useState(false);
  const carritoRef = useRef<HTMLDivElement>(null);
  const [productoAbierto, setProductoAbierto] = useState<Producto | null>(null);
  const [preloader, setPreloader] = useState(true);

  useEffect(() => {
    setFavs(leerFavoritos());
    setCarrito(leerLocal<CarritoItem[]>("skazy_carrito", []));
  }, []);

  useEffect(() => {
    if (config?.general.tutorial_activo && !tutorialVisto()) setMostrarTutorial(true);
  }, [config]);

  useEffect(() => {
    guardarLocal("skazy_carrito", carrito);
  }, [carrito]);

  useEffect(() => {
    if (!carritoAbierto) return;
    const cerrarAlTocarFuera = (event: PointerEvent) => {
      if (carritoRef.current?.contains(event.target as Node)) return;
      setCarritoAbierto(false);
    };
    document.addEventListener("pointerdown", cerrarAlTocarFuera);
    return () => document.removeEventListener("pointerdown", cerrarAlTocarFuera);
  }, [carritoAbierto]);

  useEffect(() => {
    const timer = window.setTimeout(() => setPreloader(false), 1050);
    return () => window.clearTimeout(timer);
  }, []);

  const categoriasVisibles = useMemo(
    () => categorias.filter((c) => c.visible).sort((a, b) => a.orden - b.orden),
    [categorias],
  );

  const productosFiltrados = useMemo(() => {
    const q = busqueda.trim().toLowerCase();
    return productos
      .filter((p) => p.visible)
      .filter((p) => (categoriaSel ? p.categoria_id === categoriaSel : true))
      .filter((p) => (soloFavoritos ? favs.includes(p.id) : true))
      .filter((p) =>
        q ? `${p.nombre} ${p.descripcion ?? ""}`.toLowerCase().includes(q) : true,
      );
  }, [productos, categoriaSel, soloFavoritos, favs, busqueda]);

  const porCategoria = useMemo(() => {
    return categoriasVisibles
      .map((c) => ({ categoria: c, items: productosFiltrados.filter((p) => p.categoria_id === c.id) }))
      .filter((g) => g.items.length > 0);
  }, [categoriasVisibles, productosFiltrados]);

  const subtotal = carrito.reduce((acc, i) => acc + i.precio * i.cantidad, 0);
  const cantidadTotal = carrito.reduce((acc, i) => acc + i.cantidad, 0);

  function irACategoria(id: string) {
    setCategoriaSel(id || null);
    window.setTimeout(() => document.querySelector(`[data-category-id="${id}"]`)?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
  }

  function irAProducto(id: string) {
    setCategoriaSel(null);
    window.setTimeout(() => document.querySelector(`[data-product-id="${id}"]`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 80);
  }

  function toggleFav(id: string) {
    const nuevos = favs.includes(id) ? favs.filter((f) => f !== id) : [...favs, id];
    setFavs(nuevos);
    guardarFavoritos(nuevos);
  }

  function agregar(p: Producto, opciones: SeleccionModificador[] = []) {
    const clave = `${p.id}:${JSON.stringify([...opciones].sort((a, b) => `${a.grupo}:${a.opcion}`.localeCompare(`${b.grupo}:${b.opcion}`)))}`;
    setCarrito((prev) => {
      const existe = prev.find((i) => (i.clave ?? `${i.producto_id}:[]`) === clave);
      if (existe)
        return prev.map((i) => ((i.clave ?? `${i.producto_id}:[]`) === clave ? { ...i, cantidad: i.cantidad + 1 } : i));
      return [
        ...prev,
        {
          clave,
          producto_id: p.id,
          nombre: p.nombre,
          precio: Number(p.precio) + opciones.reduce((s, o) => s + o.precio, 0),
          cantidad: 1,
          imagen_url: p.imagen_url,
          opciones,
        },
      ];
    });
  }

  function cambiarCantidad(id: string, delta: number) {
    setCarrito((prev) =>
      prev
        .map((i) => ((i.clave ?? `${i.producto_id}:[]`) === id ? { ...i, cantidad: i.cantidad + delta } : i))
        .filter((i) => i.cantidad > 0),
    );
  }

  if (!config) {
    return (
      <main className="client-shell flex min-h-screen items-center justify-center text-muted-foreground">
        <div className="stairs-loader"><span /><span /><span /><span /><MarcaSkazy variante="principal" className="loading-brand" /></div>
      </main>
    );
  }

  if (vista === "final") {
    return (
      <main className="client-shell flex min-h-screen flex-col items-center justify-center gap-6 p-8 text-center">
        <MarcaSkazy variante="principal" className="final-brand" />
        <h1 className="text-3xl text-accent">{config.general.nombre_local}</h1>
        <p className="max-w-sm text-lg">{config.general.texto_final}</p>
        <div className="flex gap-2">
          <Link to="/seguimiento" className="btn-base btn-base-active btn-primary">
            Ver mi pedido
          </Link>
          <button
            type="button"
            onClick={() => setVista("menu")}
            className="btn-base btn-base-active btn-ghost"
          >
            Volver al menú
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="client-shell min-h-screen">
      <div className={`client-preloader ${preloader ? "" : "is-finished"}`} aria-hidden={!preloader}>
        <div className="preloader-stairs"><i /><i /><i /><i /><i /></div>
        <MarcaSkazy variante="principal" className="preloader-brand" />
      </div>
      <AnuncioPopup anuncios={anuncios} onCategoria={irACategoria} onProducto={irAProducto} />
      <FichaProducto producto={productoAbierto} productos={productos} onCerrar={() => setProductoAbierto(null)} onAgregar={agregar} onElegir={setProductoAbierto} />
      {mostrarTutorial && (
        <Tutorial
          onFinalizar={() => {
            marcarTutorialVisto();
            setMostrarTutorial(false);
          }}
        />
      )}

      <header className="client-header sticky top-0 z-30">
        <div className="mx-auto grid max-w-6xl grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-3 px-4 py-3 sm:flex">
          <Link to="/" aria-label="SKAZY, ir al inicio" className="client-brand-link sm:mr-auto">
            <MarcaSkazy variante="principal" className="client-header-logo" />
          </Link>
          <Link data-tour="seguimiento" to="/seguimiento" className="client-nav-action min-h-11 px-3 text-sm">
            Mis pedidos
          </Link>
          <button
            data-tour="busqueda"
            type="button"
            aria-label="Buscar"
            onClick={() => setBusquedaAbierta((v) => !v)}
            className="client-icon-button min-h-11 min-w-11"
          >
            {busquedaAbierta ? <X size={21} /> : <Search size={21} />}
          </button>
        </div>
        {busquedaAbierta && (
          <div className="mx-auto max-w-6xl px-4 pb-3">
            <input
              autoFocus
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              placeholder="Buscar en el menú…"
              className="field"
            />
          </div>
        )}
        <div data-tour="categorias" className="client-filter-bar mx-auto flex max-w-6xl items-center gap-3 overflow-x-auto px-4 pb-3">
          <button
            data-tour="favoritos"
            type="button"
            onClick={() => {
              setSoloFavoritos((v) => !v);
              setCategoriaSel(null);
            }}
            className={`client-chip shrink-0 ${soloFavoritos ? "is-active" : ""}`}
          >
            <Heart size={16} fill={soloFavoritos ? "currentColor" : "none"} /> Favoritos
          </button>
          <button
            type="button"
            onClick={() => {
              setSoloFavoritos(false);
              setCategoriaSel(null);
            }}
            className={`client-chip shrink-0 ${categoriaSel === null && !soloFavoritos ? "is-active" : ""}`}
          >
            Todo
          </button>
          {categoriasVisibles.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                setSoloFavoritos(false);
                irACategoria(c.id);
              }}
              className={`client-chip shrink-0 ${categoriaSel === c.id ? "is-active" : ""}`}
            >
              {c.nombre}
            </button>
          ))}
        </div>
      </header>

      {vista === "menu" ? (
        <>
          <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-2 px-4 py-5 text-sm">
            <span
               className={`open-status ${
                config.general.abierto
                  ? "is-open"
                  : "is-closed"
              }`}
            >
              {config.general.abierto ? "ABIERTO" : "CERRADO"}
            </span>
            <span className="text-muted-foreground">{config.general.horarios}</span>
            <span className="font-semibold text-primary">{config.general.urgencia_texto}</span>
          </div>

          <p className="mx-auto max-w-6xl px-4 pb-4 text-sm font-semibold text-foreground">
            {config.general.sucursales_texto}
          </p>

          <div className="my-3">
            <BarraLogos logos={logos} config={config.logos} onSeleccionar={setCategoriaSel} />
          </div>

          <section id="menu" className="mx-auto max-w-6xl px-4 pt-6">
            {porCategoria.length === 0 && (
              <p className="py-10 text-center text-muted-foreground">
                No encontramos productos con ese filtro.
              </p>
            )}
            {porCategoria.map(({ categoria, items }) => {
              const promocional = /promo|combo/i.test(categoria.nombre);
              return (
              <RevealSection key={categoria.id} className="category-stack mb-20" >
                <div data-category-id={categoria.id} className="category-heading scroll-mt-36">
                  <h2>{categoria.nombre}</h2>
                  <i />
                </div>
                <div className={promocional ? "grid gap-5" : "grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3"}>
                  {items.map((p) => (
                    <div key={p.id} data-product-id={p.id} className="scroll-mt-44">
                    <ProductoCard
                      producto={p}
                      esFavorito={favs.includes(p.id)}
                      onFavorito={toggleFav}
                      onAbrir={setProductoAbierto}
                      onAgregar={agregar}
                      destacado={promocional}
                    />
                    </div>
                  ))}
                </div>
              </RevealSection>
            )})}
          </section>

           <footer className="client-footer">
             <div className="mx-auto max-w-6xl px-4 pb-4 pt-12 sm:pb-6 sm:pt-16">
               <MarcaSkazy variante="isologo" className="client-footer-logo" />
               <p className="mt-4 max-w-md text-sm text-muted-foreground">
                 Seguinos, compartí tu pedido y enterate de todo lo nuevo de SKAZY.
               </p>
               <nav aria-label="Redes sociales de SKAZY" className="social-links mt-7">
                 {REDES.map(({ nombre, href, icono: Icono }) => (
                   <a key={nombre} href={href} target="_blank" rel="noreferrer" aria-label={nombre} title={nombre} className="social-link">
                     <Icono aria-hidden="true" size={22} />
                     <span>{nombre}</span>
                   </a>
                 ))}
               </nav>
             </div>
           </footer>
        </>
      ) : (
        <Checkout
          carrito={carrito}
          subtotal={subtotal}
          codigosDisponibles={codigos}
          config={config}
          onCambiarCantidad={cambiarCantidad}
          onVolver={() => setVista("menu")}
          onEnviado={() => {
            setCarrito([]);
            setVista("final");
          }}
        />
      )}

      {vista === "menu" && carrito.length > 0 && (
        <div ref={carritoRef} data-tour="carrito" className={`dynamic-cart ${carritoAbierto ? "is-open" : ""}`}>
          <button type="button" onClick={() => setCarritoAbierto((value) => !value)} className="dynamic-cart-summary" aria-expanded={carritoAbierto} aria-label={carritoAbierto ? "Cerrar detalle del carrito" : `Abrir carrito con ${cantidadTotal} productos`}>
            <span className="cart-icon"><ShoppingBag size={21} /><b>{cantidadTotal}</b></span>
            <ChevronDown size={20} className="cart-chevron" />
          </button>
          <div className="dynamic-cart-content">
          <div className="mb-3 max-h-40 space-y-2 overflow-y-auto">
            {carrito.map((i) => (
              <div key={i.clave ?? i.producto_id} className="flex items-center gap-2 text-sm">
                <span className="mr-auto min-w-0"><span className="block truncate">{i.nombre}</span>{i.opciones?.length ? <small className="block text-primary-foreground/70">{i.opciones.map((o) => o.opcion).join(", ")}</small> : null}</span>
                 <button aria-label={`Quitar una unidad de ${i.nombre}`}
                  type="button"
                  onClick={() => cambiarCantidad(i.clave ?? `${i.producto_id}:[]`, -1)}
                  className="cart-quantity"
                >
                  −
                </button>
                <span className="w-6 text-center font-bold">{i.cantidad}</span>
                 <button aria-label={`Agregar una unidad de ${i.nombre}`}
                  type="button"
                  onClick={() => cambiarCantidad(i.clave ?? `${i.producto_id}:[]`, 1)}
                  className="cart-quantity"
                >
                  +
                </button>
                <span className="w-20 text-right text-accent">{money(i.precio * i.cantidad)}</span>
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={() => setVista("checkout")}
            className="client-cta min-h-12 w-full px-5"
          >
            Ver resumen · {cantidadTotal} items · <AnimatedNumber value={subtotal} formatter={money} />
          </button>
          </div>
        </div>
      )}
    </main>
  );
}

/* ================= CHECKOUT ================= */

interface CheckoutProps {
  carrito: CarritoItem[];
  subtotal: number;
  codigosDisponibles: { codigo: string; porcentaje: number; activo: boolean; expira_at: string | null }[];
  config: NonNullable<Awaited<ReturnType<typeof fetchConfig>>>;
  onCambiarCantidad: (id: string, delta: number) => void;
  onVolver: () => void;
  onEnviado: () => void;
}

function Checkout({
  carrito,
  subtotal,
  codigosDisponibles,
  config,
  onCambiarCantidad,
  onVolver,
  onEnviado,
}: CheckoutProps) {
  const [nombre, setNombre] = useState("");
  const [telefono, setTelefono] = useState("");
  const [domicilio, setDomicilio] = useState("");
  const [metodoPago, setMetodoPago] = useState("");
  const [pagaCon, setPagaCon] = useState("");
  const [grupoActivo, setGrupoActivo] = useState(false);
  const [personas, setPersonas] = useState<PersonaGrupo[]>([]);
  const [asignaciones, setAsignaciones] = useState<Record<string, string>>({});
  const [codigo, setCodigo] = useState("");
  const [ubicacion, setUbicacion] = useState<Ubicacion>(null);
  const [zonaOk, setZonaOk] = useState<boolean | null>(null);
  const [mensajeZona, setMensajeZona] = useState("");
  const [buscandoUbicacion, setBuscandoUbicacion] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState("");

  const descuento = useMemo(() => {
    const c = codigosDisponibles.find(
      (x) =>
        x.codigo.toUpperCase() === codigo.trim().toUpperCase() &&
        x.activo &&
        (!x.expira_at || new Date(x.expira_at).getTime() > Date.now()),
    );
    return c ? Number(c.porcentaje) : 0;
  }, [codigo, codigosDisponibles]);

  const montoDescuento = Math.round((subtotal * descuento) / 100);
  const total = subtotal - montoDescuento;
  const zona = config.zona;
  const paraRetirar = domicilio.trim().toLowerCase().includes("paso a retirar");

  function evaluar(lat: number, lng: number) {
    const ok = dentroDeZona(lat, lng, zona);
    setUbicacion({ lat, lng });
    setZonaOk(ok);
    setMensajeZona(ok ? zona.mensaje_dentro : zona.mensaje_fuera);
  }

  function ubicacionActual() {
    if (!navigator.geolocation) {
      setError("Tu dispositivo no permite compartir la ubicación. Elegila en el mapa.");
      return;
    }
    setBuscandoUbicacion(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        evaluar(pos.coords.latitude, pos.coords.longitude);
        setBuscandoUbicacion(false);
      },
      () => {
        setBuscandoUbicacion(false);
        setError("No pudimos obtener tu ubicación. Marcala en el mapa o escribí tu domicilio.");
      },
      { enableHighAccuracy: true, timeout: 15000 },
    );
  }

  async function buscarDireccion() {
    if (!domicilio.trim() || paraRetirar) return;
    setBuscandoUbicacion(true);
    setError("");
    try {
      const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(
        domicilio + ", Tucumán, Argentina",
      )}`;
      const res = await fetch(url, { headers: { Accept: "application/json" } });
      const json = (await res.json()) as { lat: string; lon: string }[];
      if (!json.length) {
        setError("No encontramos esa dirección. Marcá el punto exacto en el mapa.");
      } else {
        evaluar(Number(json[0]!.lat), Number(json[0]!.lon));
      }
    } catch {
      setError("No pudimos buscar la dirección. Marcá el punto en el mapa.");
    } finally {
      setBuscandoUbicacion(false);
    }
  }

  const nuevaPersona = (): PersonaGrupo => ({
    id: crypto.randomUUID(),
    nombre: "",
    metodo_pago: "EFECTIVO",
    paga_con: null,
  });
  const cambiarGrupo = (activo: boolean) => {
    setGrupoActivo(activo);
    if (activo && personas.length < 2) setPersonas([nuevaPersona(), nuevaPersona()]);
  };
  const pedidoGrupal = grupoActivo ? calcularPedidoGrupal(carrito, personas, asignaciones, total) : null;
  const grupoValido = !grupoActivo || (personas.length >= 2 && personas.every((persona) => persona.nombre.trim().length > 0));
  const montoGrupoEfectivo = pedidoGrupal ? pedidoGrupal.personas.filter((x) => x.metodo_pago === "EFECTIVO").reduce((a, x) => a + x.total, 0) : 0;
  const montoGrupoTransferencia = pedidoGrupal ? pedidoGrupal.personas.filter((x) => x.metodo_pago === "TRANSFERENCIA").reduce((a, x) => a + x.total, 0) : 0;
  const metodoFinal = grupoActivo ? (montoGrupoEfectivo >= montoGrupoTransferencia ? "EFECTIVO" : "TRANSFERENCIA") : metodoPago;
  const datosCompletos =
    nombre.trim() && telefono.trim() && domicilio.trim() && metodoFinal && carrito.length > 0 && grupoValido;
  const puedeEnviar = Boolean(datosCompletos) && (paraRetirar || zonaOk === true);

  async function enviarPedido() {
    setError("");
    if (!datosCompletos) {
      setError(config.general.aviso_checkout);
      return;
    }
    if (!paraRetirar && zonaOk !== true) {
      setError(zona.mensaje_fuera);
      return;
    }
    setEnviando(true);
    try {
      const { data: pedido, error: errPedido } = await supabase
        .from("pedidos")
        .insert({
          codigo: "",
          cliente_nombre: nombre.trim(),
          telefono: telefono.trim(),
          domicilio: domicilio.trim(),
          lat: ubicacion?.lat ?? null,
          lng: ubicacion?.lng ?? null,
          metodo_pago: metodoFinal,
          paga_con: !grupoActivo && pagaCon ? Number(pagaCon) : null,
          pedido_grupal: (pedidoGrupal ?? null) as never,
          subtotal,
          codigo_descuento: descuento > 0 ? codigo.trim().toUpperCase() : null,
          descuento_porcentaje: descuento,
          monto_descuento: montoDescuento,
          total,
          estado: "CLIENTE",
        })
        .select("*")
        .single();
      if (errPedido || !pedido) throw errPedido ?? new Error("No se pudo guardar el pedido");

      const items = carrito.map((i) => ({
        pedido_id: pedido.id as string,
        producto_id: i.producto_id,
        nombre: `${i.nombre}${i.opciones?.length ? ` (${i.opciones.map((o) => `${o.grupo}: ${o.opcion}`).join(", ")})` : ""}`,
        opciones: (i.opciones ?? []) as never,
        cantidad: i.cantidad,
        precio_unitario: i.precio,
        subtotal: i.precio * i.cantidad,
      }));
      const { error: errItems } = await supabase.from("pedido_items").insert(items);
      if (errItems) throw errItems;

      agregarMiPedido(pedido.id as string);
      const completo = { ...(pedido as unknown as Pedido), pedido_items: items as never };
      abrirWhatsApp(config.general.whatsapp, mensajeWhatsApp(completo, config));
      onEnviado();
    } catch (e) {
      setError(
        e instanceof Error
          ? `No pudimos enviar el pedido: ${e.message}`
          : "No pudimos enviar el pedido. Intentá de nuevo.",
      );
    } finally {
      setEnviando(false);
    }
  }

  return (
    <section className="client-checkout mx-auto max-w-3xl px-4 py-8">
      <button type="button" onClick={onVolver} className="btn-base btn-ghost mb-3 px-3 py-1.5 text-sm">
        ← Volver al menú
      </button>

       <div className="checkout-trust mb-5 p-4 text-sm font-semibold">{config.general.aviso_checkout}</div>

      <div className="panel mb-3 space-y-3 p-3">
        <label className="block text-sm">
          Nombre:
          <input value={nombre} onChange={(e) => setNombre(e.target.value)} maxLength={80} className="field mt-1" />
        </label>
        <label className="block text-sm">
          Teléfono/Celular:
          <input
            value={telefono}
            onChange={(e) => setTelefono(e.target.value)}
            maxLength={30}
            inputMode="tel"
            className="field mt-1"
          />
        </label>
        <label className="block text-sm">
          Escribí tu domicilio exacto o "Paso a Retirar":
          <input
            value={domicilio}
            onChange={(e) => setDomicilio(e.target.value)}
            maxLength={160}
            className="field mt-1"
          />
        </label>
        <p className="text-xs text-muted-foreground">{config.general.texto_zona}</p>
      </div>

      {!paraRetirar && (
        <div className="panel mb-3 space-y-2 p-3">
          <h3 className="text-xl text-accent">📍 Zona de entrega</h3>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={ubicacionActual}
              disabled={buscandoUbicacion}
              className="btn-base btn-base-active btn-primary text-sm"
            >
              ENVIAR MI UBICACIÓN ACTUAL
            </button>
            <button
              type="button"
              onClick={buscarDireccion}
              disabled={buscandoUbicacion}
              className="btn-base btn-base-active btn-ghost text-sm"
            >
              Validar mi domicilio escrito
            </button>
          </div>
          <p className="text-xs text-muted-foreground">
            También podés tocar el mapa para marcar tu ubicación exacta.
          </p>
          <MapaClient
            centro={ubicacion ?? { lat: (zona.lat_min + zona.lat_max) / 2, lng: (zona.lng_min + zona.lng_max) / 2 }}
            zoom={14}
            alto={240}
            rectangulo={zona}
            marcadores={ubicacion ? [{ ...ubicacion, titulo: "Tu ubicación", color: zonaOk ? "#22c55e" : "#ef4444" }] : []}
            alClickear={evaluar}
          />
          {zonaOk !== null && (
            <p
              className={`rounded-lg p-2 text-sm font-semibold ${
                zonaOk ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"
              }`}
            >
              {mensajeZona}
            </p>
          )}
        </div>
      )}

      <div className="panel mb-3 p-3">
        <PedidoGrupalEditor
          carrito={carrito}
          total={total}
          activo={grupoActivo}
          onActivo={cambiarGrupo}
          personas={personas}
          onPersonas={setPersonas}
          asignaciones={asignaciones}
          onAsignaciones={setAsignaciones}
        />
        {grupoActivo && !grupoValido && (
          <p className="text-sm text-destructive">Complete el nombre de cada persona del grupo (mínimo 2).</p>
        )}
        {grupoActivo && montoGrupoTransferencia > 0 && (
          <div className="mt-3 rounded-lg bg-surface-2 p-3 text-sm">
            <p>
              Alias: <strong>{config.pagos.alias}</strong>
            </p>
            <p>{config.pagos.medio}</p>
            <p>Titular: {config.pagos.titular}</p>
            {config.pagos.qr_url && (
              <img src={config.pagos.qr_url} alt="QR de pago" className="mt-2 h-40 w-40 rounded-lg object-contain" />
            )}
          </div>
        )}
      </div>

      {!grupoActivo && (
      <div className="panel mb-3 space-y-2 p-3">
        <h3 className="text-xl">💳 Forma de pago</h3>
        <p className="text-sm">💵 ¿Pagás con efectivo y necesitás vuelto?</p>
        <p className="text-xs text-muted-foreground">{config.general.texto_vuelto}</p>
        <select value={metodoPago} onChange={(e) => setMetodoPago(e.target.value)} className="field">
          <option value="">Seleccione forma de pago:</option>
          <option value="EFECTIVO">EFECTIVO</option>
          <option value="TRANSFERENCIA">TRANSFERENCIA</option>
        </select>
        {metodoPago === "EFECTIVO" && (
          <input
            value={pagaCon}
            onChange={(e) => setPagaCon(e.target.value.replace(/[^\d]/g, ""))}
            inputMode="numeric"
            placeholder="¿Con cuánto abonás? (opcional)"
            className="field"
          />
        )}
        {metodoPago === "TRANSFERENCIA" && (
          <div className="rounded-lg bg-surface-2 p-3 text-sm">
            <p>
              Alias: <strong>{config.pagos.alias}</strong>
            </p>
            <p>{config.pagos.medio}</p>
            <p>Titular: {config.pagos.titular}</p>
            {config.pagos.qr_url && (
              <img src={config.pagos.qr_url} alt="QR de pago" className="mt-2 h-40 w-40 rounded-lg object-contain" />
            )}
          </div>
        )}
      </div>
      )}

      <div className="panel mb-3 p-3 text-sm">
        <h3 className="text-xl">⏱ Tiempos de demora estimados</h3>
        <p>📅 Lun — Jue: {config.general.tiempo_lun_jue}</p>
        <p>📅 Vie — Dom: {config.general.tiempo_vie_dom}</p>
        <p className="mt-1 text-muted-foreground">{config.general.texto_dudas_tiempo}</p>
      </div>

      <div className="panel mb-3 p-3">
        <h3 className="mb-2 text-xl">🧾 Tu pedido</h3>
        <div className="space-y-1">
          {carrito.map((i) => (
            <div key={i.clave ?? i.producto_id} className="flex items-center gap-2 border-b border-border py-2 text-sm">
              <span className="mr-auto min-w-0"><span className="block truncate">{i.nombre}</span>{i.opciones?.length ? <small className="block text-muted-foreground">{i.opciones.map((o) => `${o.grupo}: ${o.opcion}`).join(" · ")}</small> : null}</span>
              <button type="button" onClick={() => onCambiarCantidad(i.clave ?? `${i.producto_id}:[]`, -1)} className="btn-base btn-ghost min-h-11 min-w-11 px-2">
                −
              </button>
              <span className="w-6 text-center font-bold">{i.cantidad}</span>
              <button type="button" onClick={() => onCambiarCantidad(i.clave ?? `${i.producto_id}:[]`, 1)} className="btn-base btn-ghost min-h-11 min-w-11 px-2">
                +
              </button>
              <span className="w-20 text-right">{money(i.precio * i.cantidad)}</span>
            </div>
          ))}
        </div>

        <input
          value={codigo}
          onChange={(e) => setCodigo(e.target.value)}
          placeholder="Código de descuento"
          className="field mt-3"
        />

        <div className="total-box mt-3 space-y-1 p-3 text-sm">
          <div className="flex justify-between text-muted-foreground">
            <span>Subtotal</span>
            <span className="font-semibold text-foreground">{money(subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-accent">Descuento {descuento > 0 ? `${descuento}%` : ""}</span>
            <span className="text-accent">-{money(montoDescuento)}</span>
          </div>
          <div className="flex justify-between border-t border-border pt-1 text-base font-bold text-primary">
            <span>Total</span>
            <span>{money(total)}</span>
          </div>
        </div>
         <div className="checkout-trust mt-4 p-4 text-center text-sm font-semibold">✓ {config.general.texto_confianza}</div>
      </div>

      {error && <p className="panel mb-3 border-destructive p-3 text-sm text-destructive">{error}</p>}

      <button
        type="button"
        onClick={enviarPedido}
        disabled={enviando || !puedeEnviar}
        className={`btn-base btn-base-active w-full ${puedeEnviar ? "btn-primary" : "btn-ghost opacity-60"}`}
      >
        {enviando ? "Enviando…" : "Enviar pedido por WhatsApp"}
      </button>
    </section>
  );
}
