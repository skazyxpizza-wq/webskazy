import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Navigation } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import PasswordGate from "@/components/skazy/PasswordGate";
import MapaClient from "@/components/skazy/MapaClient";
import PedidoGrupalResumen from "@/components/skazy/PedidoGrupalResumen";
import { montoPorMetodo } from "@/lib/pedido-grupal";
import { cambiarEstado, fetchCadetes, fetchConfig, fetchPedidos } from "@/lib/data";
import { distanciaKm, hablar, money, ordenarRuta, sonarAviso } from "@/lib/skazy";
import type { Pedido } from "@/lib/types";

export const Route = createFileRoute("/envios")({
  head: () => ({
    meta: [
      { title: "Envíos — SKAZY" },
      { name: "description", content: "Panel de envíos de SKAZY: hoja de ruta y entregas." },
      { property: "og:title", content: "Envíos — SKAZY" },
      { property: "og:description", content: "Panel interno de envíos de SKAZY." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => (
    <PasswordGate sector="envios" titulo="ENVÍOS">
      {() => <Envios />}
    </PasswordGate>
  ),
});

type Pantalla = "pedidos" | "ruta" | "cliente" | "rendicion";
type Punto = { lat: number; lng: number };

/** Abre Google Maps con navegación por calles y voz. Admite paradas intermedias (máx. 9). */
function urlComoLlegar(destino: Punto, origen?: Punto | null, paradas: Punto[] = []) {
  const f = (p: Punto) => `${p.lat},${p.lng}`;
  const q = new URLSearchParams({ api: "1", destination: f(destino), travelmode: "driving" });
  if (origen) q.set("origin", f(origen));
  if (paradas.length) q.set("waypoints", paradas.slice(0, 9).map(f).join("|"));
  return `https://www.google.com/maps/dir/?${q.toString()}`;
}

const ATRAS: Record<Pantalla, Pantalla | null> = {
  pedidos: null,
  ruta: "pedidos",
  cliente: "ruta",
  rendicion: "pedidos",
};

function Envios() {
  const [cadeteId, setCadeteId] = useState<string>("");
  const [pantalla, setPantalla] = useState<Pantalla>("pedidos");
  const [miUbicacion, setMiUbicacion] = useState<{ lat: number; lng: number } | null>(null);
  const [orden, setOrden] = useState<string[]>([]);
  const [pedidoActivo, setPedidoActivo] = useState<string | null>(null);
  const [recibido, setRecibido] = useState("");
  const [error, setError] = useState("");

  const { data: config } = useQuery({ queryKey: ["config"], queryFn: fetchConfig });
  const { data: cadetes = [] } = useQuery({ queryKey: ["cadetes"], queryFn: fetchCadetes });
  const { data: pedidos = [], refetch } = useQuery({
    queryKey: ["envios-pedidos"],
    queryFn: () => fetchPedidos(["CLIENTE", "COCINA", "ENVIOS", "ENTREGADO"]),
  });

  useEffect(() => {
    const guardado = localStorage.getItem("skazy_cadete");
    if (guardado) setCadeteId(guardado);
  }, []);

  useEffect(() => {
    const channel = supabase
      .channel("envios-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "pedidos" }, () => void refetch())
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [refetch]);

  // publicar ubicación del cadete en vivo
  useEffect(() => {
    if (!cadeteId || !navigator.geolocation) return;
    const id = navigator.geolocation.watchPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setMiUbicacion({ lat, lng });
        void supabase
          .from("cadetes")
          .update({ lat, lng, ubicacion_at: new Date().toISOString() })
          .eq("id", cadeteId);
      },
      () => setError("No pudimos acceder a tu ubicación. Activá el GPS."),
      { enableHighAccuracy: true, maximumAge: 5000 },
    );
    return () => navigator.geolocation.clearWatch(id);
  }, [cadeteId]);

  const sucursal = config
    ? { lat: config.zona.sucursal_lat, lng: config.zona.sucursal_lng }
    : { lat: -26.735, lng: -65.252 };
  const cocinaActiva = config?.cocina.activa ?? false;
  const listos = pedidos.filter((p) => p.estado === "ENVIOS" && !p.cadete_id);
  const mios = pedidos.filter((p) => p.estado === "ENVIOS" && p.cadete_id === cadeteId);

  const rutaOrdenada = useMemo(() => {
    const base = miUbicacion ?? sucursal;
    if (orden.length) {
      const mapa = new Map(mios.map((p) => [p.id, p]));
      const ordenados = orden.map((id) => mapa.get(id)).filter(Boolean) as Pedido[];
      const faltantes = mios.filter((p) => !orden.includes(p.id));
      return [...ordenados, ...faltantes];
    }
    return ordenarRuta(base, mios);
  }, [mios, miUbicacion, orden, sucursal]);

  const activo = rutaOrdenada.find((p) => p.id === pedidoActivo) ?? rutaOrdenada[0] ?? null;
  const paradasMapa: Punto[] = rutaOrdenada
    .filter((p) => p.lat != null && p.lng != null)
    .map((p) => ({ lat: p.lat!, lng: p.lng! }));

  async function seleccionar(p: Pedido) {
    if (!cadeteId) {
      setError("Elegí tu nombre de cadete antes de seleccionar pedidos.");
      return;
    }
    setError("");
    const { data, error: errSel } = await supabase
      .from("pedidos")
      .update({ cadete_id: cadeteId })
      .eq("id", p.id)
      .is("cadete_id", null)
      .select("id");
    if (errSel || !data?.length) {
      setError("Ese pedido ya fue tomado por otro cadete o no está disponible.");
      void refetch();
      return;
    }
    sonarAviso(1);
    void refetch();
  }

  async function finalizarEnvio(p: Pedido) {
    const efectivoDebido = montoPorMetodo(p, "EFECTIVO");
    const recibidoNum = efectivoDebido > 0 && recibido ? Number(recibido) : null;
    if (efectivoDebido > 0 && (recibidoNum == null || recibidoNum < efectivoDebido)) {
      setError(`Ingrese el monto recibido en efectivo (mínimo ${money(efectivoDebido)}) antes de finalizar.`);
      return;
    }
    setError("");
    await cambiarEstado(p.id, "ENTREGADO", {
      entregado_at: new Date().toISOString(),
      monto_recibido: recibidoNum,
      vuelto: recibidoNum != null ? recibidoNum - efectivoDebido : null,
    });
    setRecibido("");
    hablar("Entrega finalizada. Siguiente pedido.");
    const restantes = rutaOrdenada.filter((x) => x.id !== p.id);
    setPedidoActivo(restantes[0]?.id ?? null);
    if (!restantes.length) {
      sonarAviso(4);
      hablar("Completaste todos los pedidos. Volvé a la sucursal.");
      setPantalla("rendicion");
    }
    void refetch();
  }

  function moverParada(id: string, delta: number) {
    const actual = rutaOrdenada.map((p) => p.id);
    const i = actual.indexOf(id);
    const j = i + delta;
    if (i < 0 || j < 0 || j >= actual.length) return;
    [actual[i], actual[j]] = [actual[j]!, actual[i]!];
    setOrden(actual);
  }

  function guiar() {
    const p = activo;
    if (!p || !miUbicacion || p.lat == null || p.lng == null) return;
    const km = distanciaKm(miUbicacion, { lat: p.lat, lng: p.lng });
    hablar(`Próxima parada, ${p.cliente_nombre}. A ${km.toFixed(1)} kilómetros. Domicilio ${p.domicilio}`);
  }

  // recalcular guía si el cadete se desvía
  useEffect(() => {
    if (pantalla !== "ruta" || !activo || !miUbicacion || activo.lat == null || activo.lng == null) return;
    const km = distanciaKm(miUbicacion, { lat: activo.lat, lng: activo.lng });
    if (km < 0.15) {
      hablar(`Llegaste al domicilio de ${activo.cliente_nombre}`);
      setPedidoActivo(activo.id);
      setPantalla("cliente");
    }
  }, [miUbicacion, activo, pantalla]);

  const entregadosHoy = pedidos.filter(
    (p) =>
      p.estado === "ENTREGADO" &&
      p.cadete_id === cadeteId &&
      new Date(p.entregado_at ?? p.updated_at).toDateString() === new Date().toDateString(),
  );
  const efectivo = entregadosHoy.filter((p) => montoPorMetodo(p, "EFECTIVO") > 0);
  const transferencias = entregadosHoy.filter((p) => montoPorMetodo(p, "TRANSFERENCIA") > 0);
  const totalEfectivo = efectivo.reduce((a, p) => a + montoPorMetodo(p, "EFECTIVO"), 0);
  const totalTransfer = transferencias.reduce((a, p) => a + montoPorMetodo(p, "TRANSFERENCIA"), 0);
  const atras = ATRAS[pantalla];

  return (
    <main className="min-h-screen p-4">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {atras && (
          <button
            type="button"
            onClick={() => setPantalla(atras)}
            aria-label="Volver"
            className="btn-base btn-ghost grid h-12 w-12 place-items-center p-0"
          >
            <ArrowLeft size={24} />
          </button>
        )}
        <h1 className="text-3xl text-primary">ENVÍOS</h1>
        <select
          value={cadeteId}
          onChange={(e) => {
            setCadeteId(e.target.value);
            localStorage.setItem("skazy_cadete", e.target.value);
          }}
          className="field ml-auto max-w-48"
        >
          <option value="">Elegí tu nombre</option>
          {cadetes
            .filter((c) => c.activo)
            .map((c) => (
              <option key={c.id} value={c.id}>
                {c.nombre}
              </option>
            ))}
        </select>
      </div>

      {error && <p className="panel mb-3 border-destructive p-2 text-sm text-destructive">{error}</p>}

      <nav className="mb-4 flex flex-wrap gap-2">
        {(["pedidos", "ruta", "rendicion"] as Pantalla[]).map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => setPantalla(p)}
            className={`btn-base text-sm ${pantalla === p ? "chip-activa" : "btn-ghost"}`}
          >
            {p === "pedidos" ? "Pedidos" : p === "ruta" ? "Hoja de ruta" : "Rendición"}
          </button>
        ))}
      </nav>

      {pantalla === "pedidos" && (
        <section className="space-y-4">
          <div className="panel p-3">
            <h2 className="text-xl">Seleccionar paquetería en sucursal</h2>
            {!cocinaActiva && (
              <p className="text-sm text-muted-foreground">
                Cocina no tiene actividad: no hay paquetería para seleccionar.
              </p>
            )}
            {cocinaActiva && !listos.length && (
              <p className="text-sm text-muted-foreground">No hay pedidos listos por el momento.</p>
            )}
            <div className="mt-2 space-y-2">
              {cocinaActiva &&
                listos.map((p) => (
                  <div key={p.id} className="flex flex-wrap items-center gap-2 border-b border-border py-2">
                    <span className="text-lg text-accent">{p.codigo}</span>
                    <span className="text-sm">{p.cliente_nombre}</span>
                    <span className="text-xs text-muted-foreground">{p.domicilio}</span>
                    <button
                      type="button"
                      onClick={() => seleccionar(p)}
                      className="btn-base btn-base-active btn-primary ml-auto text-sm"
                    >
                      Seleccionar
                    </button>
                  </div>
                ))}
            </div>
          </div>

          <div className="panel p-3">
            <h2 className="mb-2 text-xl">Mi paquetería ({mios.length})</h2>
            {mios.map((p) => (
              <div key={p.id} className="flex flex-wrap items-center gap-2 border-b border-border py-2">
                <span className="text-lg text-accent">{p.codigo}</span>
                <span className="text-sm">{p.cliente_nombre}</span>
              </div>
            ))}
            {!!mios.length && (
              <p className="mt-2 text-xs text-muted-foreground">
                Un pedido seleccionado solo se quita si el pedido se cancela.
              </p>
            )}
            {!mios.length && <p className="text-sm text-muted-foreground">Todavía no seleccionaste pedidos.</p>}
          </div>

          <div className="panel p-3">
            <h2 className="mb-2 text-xl">Mi ubicación y la sucursal</h2>
            <MapaClient
              centro={miUbicacion ?? sucursal}
              alto={260}
              marcadores={[
                { ...sucursal, titulo: "Sucursal", color: "#f59e0b" },
                ...(miUbicacion ? [{ ...miUbicacion, titulo: "Yo", color: "#22c55e" }] : []),
                ...mios
                  .filter((p) => p.lat != null && p.lng != null)
                  .map((p) => ({ lat: p.lat!, lng: p.lng!, titulo: p.codigo, color: "#ef4444" })),
              ]}
            />
          </div>
        </section>
      )}

      {pantalla === "ruta" && (
        <section className="space-y-3">
          <div className="panel p-3">
            <h2 className="mb-2 text-xl">Hoja de ruta ({rutaOrdenada.length} paradas)</h2>
            {rutaOrdenada.map((p, i) => (
              <div key={p.id} className="flex flex-wrap items-center gap-2 border-b border-border py-2">
                <span className="font-bold">{i + 1}.</span>
                <span className="text-accent">{p.codigo}</span>
                <span className="text-sm">{p.domicilio}</span>
                <div className="ml-auto flex gap-1">
                  <button type="button" onClick={() => moverParada(p.id, -1)} className="btn-base btn-ghost px-2 py-1 text-sm">
                    ↑
                  </button>
                  <button type="button" onClick={() => moverParada(p.id, 1)} className="btn-base btn-ghost px-2 py-1 text-sm">
                    ↓
                  </button>
                  {p.lat != null && p.lng != null && (
                    <a
                      href={urlComoLlegar({ lat: p.lat, lng: p.lng }, miUbicacion)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-base btn-ghost grid min-h-10 place-items-center px-2 py-1 text-sm"
                      aria-label={`Cómo llegar a ${p.domicilio}`}
                    >
                      <Navigation size={18} />
                    </a>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setPedidoActivo(p.id);
                      setPantalla("cliente");
                    }}
                    className="btn-base btn-primary px-2 py-1 text-sm"
                  >
                    Ir
                  </button>
                </div>
              </div>
            ))}
            {!rutaOrdenada.length && <p className="text-sm text-muted-foreground">Sin paradas asignadas.</p>}
          </div>

          <div className="panel p-3">
            <MapaClient
              centro={miUbicacion ?? sucursal}
              alto={300}
              marcadores={[
                ...(miUbicacion ? [{ ...miUbicacion, titulo: "Yo", color: "#22c55e" }] : []),
                ...rutaOrdenada
                  .filter((p) => p.lat != null && p.lng != null)
                  .map((p, i) => ({ lat: p.lat!, lng: p.lng!, titulo: `${i + 1} · ${p.codigo}`, color: "#ef4444" })),
                { ...sucursal, titulo: "Sucursal", color: "#f59e0b" },
              ]}
              ruta={[
                ...(miUbicacion ? [miUbicacion] : [sucursal]),
                ...rutaOrdenada
                  .filter((p) => p.lat != null && p.lng != null)
                  .map((p) => ({ lat: p.lat!, lng: p.lng! })),
              ]}
            />
            {paradasMapa.length > 0 && (
              <a
                href={urlComoLlegar(paradasMapa[paradasMapa.length - 1]!, miUbicacion, paradasMapa.slice(0, -1))}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-base btn-base-active btn-primary mt-3 grid min-h-12 w-full place-items-center text-center"
              >
                🧭 Cómo llegar — ruta completa en Google Maps
              </a>
            )}
            <button type="button" onClick={guiar} className="btn-base btn-base-active btn-accent mt-3 w-full">
              🔊 Asistencia por voz — próxima parada
            </button>
          </div>
        </section>
      )}

      {pantalla === "cliente" && activo && (
        <section className="space-y-3">
          <div className="panel p-4">
            <h2 className="text-2xl text-accent">{activo.codigo}</h2>
            <p>
              {activo.cliente_nombre} · {activo.domicilio}
            </p>
            <ul className="mt-3 space-y-1">
              {(activo.pedido_items ?? []).map((i) => (
                <li key={i.id} className="flex justify-between border-b border-border py-1">
                  <span>
                    {i.cantidad} x {i.nombre}
                  </span>
                  <span>{money(i.subtotal)}</span>
                </li>
              ))}
            </ul>
            <div className="total-box mt-3 p-3 text-xl font-bold text-primary">
              TOTAL A COBRAR {money(activo.total)}
            </div>
            {activo.lat != null && activo.lng != null && (
              <a
                href={urlComoLlegar({ lat: activo.lat, lng: activo.lng }, miUbicacion)}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-base btn-ghost mt-3 grid min-h-12 w-full place-items-center text-center"
              >
                🧭 Cómo llegar a este domicilio
              </a>
            )}
          </div>

          {activo.pedido_grupal && (
            <div className="panel p-4">
              <PedidoGrupalResumen grupo={activo.pedido_grupal} />
            </div>
          )}

          {montoPorMetodo(activo, "TRANSFERENCIA") > 0 && (
            <div className="panel p-4">
              <h3 className="text-xl">Transferencia — {money(montoPorMetodo(activo, "TRANSFERENCIA"))}</h3>
              <p>
                Alias: <strong>{config?.pagos.alias}</strong>
              </p>
              <p>{config?.pagos.medio}</p>
              <p>Titular: {config?.pagos.titular}</p>
              {config?.pagos.qr_url && (
                <img src={config.pagos.qr_url} alt="QR de pago" className="mt-2 h-48 w-48 rounded-lg object-contain" />
              )}
            </div>
          )}

          {montoPorMetodo(activo, "EFECTIVO") > 0 && (
            <div className="panel space-y-2 p-4">
              <h3 className="text-xl">Efectivo</h3>
              <p>Debe pagar: {money(montoPorMetodo(activo, "EFECTIVO"))}</p>
              <input
                value={recibido}
                onChange={(e) => setRecibido(e.target.value.replace(/[^\d]/g, ""))}
                inputMode="numeric"
                placeholder="Monto recibido"
                className="field"
              />
              <p>Vuelto: {money(Math.max(0, Number(recibido || 0) - montoPorMetodo(activo, "EFECTIVO")))}</p>
            </div>
          )}

          <div className="panel flex flex-wrap gap-2 p-4">
            <a href={`tel:${activo.telefono}`} className="btn-base btn-ghost">
              📞 Llamar a {activo.telefono}
            </a>
            <button
              type="button"
              onClick={() => finalizarEnvio(activo)}
              className="btn-base btn-base-active btn-primary ml-auto"
            >
              Finalizar envío
            </button>
          </div>
        </section>
      )}

      {pantalla === "rendicion" && (
        <section className="space-y-3">
          <div className="panel p-4">
            <h2 className="mb-2 text-2xl">Rendición del día</h2>
            <p>Efectivo recaudado: {money(totalEfectivo)}</p>
            <p>Transferencias recibidas: {money(totalTransfer)}</p>
            <p>Pagos en efectivo: {efectivo.length}</p>
            <p>Transferencias: {transferencias.length}</p>
            <div className="total-box mt-3 p-3 text-xl font-bold text-primary">
              Dinero físico a presentar: {money(totalEfectivo)}
            </div>
          </div>
          <div className="panel p-3">
            <h3 className="mb-2 text-xl">Regreso a la sucursal</h3>
            <MapaClient
              centro={miUbicacion ?? sucursal}
              alto={240}
              marcadores={[
                ...(miUbicacion ? [{ ...miUbicacion, titulo: "Yo", color: "#22c55e" }] : []),
                { ...sucursal, titulo: "Sucursal", color: "#f59e0b" },
              ]}
              {...(miUbicacion ? { ruta: [miUbicacion, sucursal] } : {})}
            />
            <a
              href={urlComoLlegar(sucursal, miUbicacion)}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-base btn-base-active btn-primary mt-3 grid min-h-12 w-full place-items-center text-center"
            >
              🧭 Cómo llegar a la sucursal
            </a>
            <button
              type="button"
              onClick={() => hablar("Vuelva a la sucursal para hacer la rendición")}
              className="btn-base btn-accent mt-3 w-full"
            >
              🔊 Guía de regreso
            </button>
          </div>
        </section>
      )}
    </main>
  );
}
