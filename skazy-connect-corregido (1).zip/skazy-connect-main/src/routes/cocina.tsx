import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import PasswordGate from "@/components/skazy/PasswordGate";
import { cambiarEstado, fetchConfig, fetchPedidos, fetchStock, guardarConfig } from "@/lib/data";
import { horaCorta, money, sonarAviso } from "@/lib/skazy";
import type { Pedido } from "@/lib/types";

export const Route = createFileRoute("/cocina")({
  head: () => ({
    meta: [
      { title: "Cocina — SKAZY" },
      { name: "description", content: "Panel de cocina de SKAZY: pedidos entrantes y stock." },
      { property: "og:title", content: "Cocina — SKAZY" },
      { property: "og:description", content: "Panel interno de cocina de SKAZY." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => (
    <PasswordGate sector="cocina" titulo="COCINA">
      {() => <Cocina />}
    </PasswordGate>
  ),
});

function Cocina() {
  const [detalle, setDetalle] = useState<Pedido | null>(null);
  const cantidadPrevia = useRef<number | null>(null);

  const { data: pedidos = [], refetch } = useQuery({
    queryKey: ["cocina-pedidos"],
    queryFn: () => fetchPedidos(["CLIENTE", "COCINA", "ENVIOS"]),
  });
  const { data: stock = [], refetch: refetchStock } = useQuery({
    queryKey: ["stock"],
    queryFn: fetchStock,
  });
  const { data: configCocina, refetch: refetchConfig } = useQuery({ queryKey: ["config"], queryFn: fetchConfig });
  const cocinaActiva = configCocina?.cocina.activa ?? false;
  async function alternarCocina() {
    await guardarConfig("cocina", { activa: !cocinaActiva });
    void refetchConfig();
  }

  useEffect(() => {
    const channel = supabase
      .channel("cocina-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "pedidos" }, () => void refetch())
      .on("postgres_changes", { event: "*", schema: "public", table: "pedido_items" }, () => void refetch())
      .on("postgres_changes", { event: "*", schema: "public", table: "stock" }, () => void refetchStock())
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [refetch, refetchStock]);

  const enCocina = pedidos.filter((p) => p.estado === "CLIENTE" || p.estado === "COCINA");
  const entregas = pedidos.filter((p) => p.estado === "ENVIOS");

  useEffect(() => {
    if (cantidadPrevia.current !== null && enCocina.length > cantidadPrevia.current) sonarAviso(4);
    cantidadPrevia.current = enCocina.length;
  }, [enCocina.length]);

  async function marcarListo(p: Pedido) {
    await cambiarEstado(p.id, "ENVIOS");
    void refetch();
  }

  async function tomarPedido(p: Pedido) {
    await cambiarEstado(p.id, "COCINA");
    void refetch();
  }

  async function toggleStock(id: string, disponible: boolean) {
    await supabase.from("stock").update({ disponible: !disponible }).eq("id", id);
    void refetchStock();
  }

  async function guardarAviso(id: string, aviso: string) {
    await supabase.from("stock").update({ aviso }).eq("id", id);
    void refetchStock();
  }

  if (detalle) {
    return (
      <main className="min-h-screen p-4 text-lg">
        <button type="button" onClick={() => setDetalle(null)} className="btn-base btn-ghost mb-4">
          ← Volver
        </button>
        <h1 className="text-4xl text-accent">{detalle.codigo}</h1>
        <p className="mt-1">
          {detalle.cliente_nombre} · {detalle.telefono}
        </p>
        <p className="text-muted-foreground">{detalle.domicilio}</p>
        <ul className="mt-4 space-y-2 text-2xl">
          {(detalle.pedido_items ?? []).map((i) => (
            <li key={i.id} className="border-b border-border py-2">
              {i.cantidad} x {i.nombre}
            </li>
          ))}
        </ul>
        <p className="mt-4 text-3xl font-bold text-primary">TOTAL {money(detalle.total)}</p>
        <p className="text-lg">Pago: {detalle.metodo_pago}</p>
      </main>
    );
  }

  return (
    <main className="min-h-screen p-4">
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <h1 className="text-4xl text-primary">COCINA</h1>
        <button
          type="button"
          onClick={() => void alternarCocina()}
          aria-pressed={cocinaActiva}
          className={`btn-base ml-auto min-h-12 px-4 text-base font-bold ${cocinaActiva ? "btn-base-active btn-primary" : "btn-ghost"}`}
        >
          {cocinaActiva ? "Cocina ACTIVA — tocar para pausar" : "Cocina en pausa — tocar para activar"}
        </button>
      </div>

      <section className="mb-8">
        <h2 className="mb-3 text-2xl">PEDIDOS ({enCocina.length})</h2>
        <div className="grid gap-3 md:grid-cols-2">
          {enCocina.map((p) => (
            <article key={p.id} className="panel p-4">
              <div className="flex items-baseline gap-3">
                <h3 className="text-3xl text-accent">{p.codigo}</h3>
                <span className="text-lg text-muted-foreground">{horaCorta(p.created_at)}</span>
                <span
                  className={`ml-auto rounded-md px-2 py-1 text-sm font-bold ${
                    p.estado === "CLIENTE" ? "bg-warning/25 text-warning" : "bg-success/20 text-success"
                  }`}
                >
                  {p.estado}
                </span>
              </div>
              {p.grupo_codigo && (
                <p className="mt-1 text-sm text-accent">Caja agrupada: {p.grupo_codigo}</p>
              )}
              <ul className="mt-3 space-y-1 text-2xl">
                {(p.pedido_items ?? []).map((i) => (
                  <li key={i.id}>
                    {i.cantidad} x {i.nombre}
                  </li>
                ))}
              </ul>
              <p className="mt-2 text-lg text-muted-foreground">
                {p.cliente_nombre} · {p.domicilio}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {p.estado === "CLIENTE" && (
                  <button type="button" onClick={() => tomarPedido(p)} className="btn-base btn-base-active btn-ghost text-lg">
                    EN PREPARACIÓN
                  </button>
                )}
                <button type="button" onClick={() => marcarListo(p)} className="btn-base btn-base-active btn-primary text-lg">
                  LISTO → ENVÍOS
                </button>
                <button type="button" onClick={() => setDetalle(p)} className="btn-base btn-ghost text-lg">
                  Ver detalle
                </button>
              </div>
            </article>
          ))}
          {!enCocina.length && <p className="text-muted-foreground">Sin pedidos pendientes.</p>}
        </div>
      </section>

      <section className="mb-8">
        <h2 className="mb-3 text-2xl">EN ENVÍOS / CAJA ({entregas.length})</h2>
        <div className="grid gap-2 md:grid-cols-3">
          {entregas.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => {
                sonarAviso(4);
                setDetalle(p);
              }}
              className="panel p-3 text-left text-xl"
            >
              {p.codigo} · {p.cliente_nombre}
            </button>
          ))}
          {!entregas.length && <p className="text-muted-foreground">Sin entregas en curso.</p>}
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-2xl">STOCK</h2>
        <div className="grid gap-2 md:grid-cols-2">
          {stock.map((s) => (
            <div key={s.id} className="panel flex flex-wrap items-center gap-2 p-3">
              <span className="text-xl">{s.ingrediente}</span>
              <span
                className={`rounded-md px-2 py-1 text-sm font-bold ${
                  s.disponible ? "bg-success/20 text-success" : "bg-destructive/20 text-destructive"
                }`}
              >
                {s.disponible ? "DISPONIBLE" : "FALTANTE"}
              </span>
              <button
                type="button"
                onClick={() => toggleStock(s.id, s.disponible)}
                className="btn-base btn-ghost ml-auto text-sm"
              >
                Cambiar
              </button>
              <input
                defaultValue={s.aviso ?? ""}
                onBlur={(e) => guardarAviso(s.id, e.target.value)}
                placeholder="Aviso de faltante"
                className="field mt-1 text-base"
              />
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
