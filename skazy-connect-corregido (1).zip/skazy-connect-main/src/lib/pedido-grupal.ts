import type { CarritoItem, Pedido, PedidoGrupal, PersonaGrupo } from "./types";

export function unidadesCarrito(carrito: CarritoItem[]) {
  return carrito.flatMap((item) => Array.from({ length: item.cantidad }, (_, indice) => ({
    clave: `${item.clave ?? `${item.producto_id}:[]`}#${indice}`,
    nombre: `${item.nombre}${item.opciones?.length ? ` (${item.opciones.map((o) => `${o.grupo}: ${o.opcion}`).join(", ")})` : ""}`,
    precio: item.precio,
  })));
}

/** Reparte centavos y asigna los residuos de forma estable; la suma siempre coincide con el pedido. */
function repartir(centavos: number, pesos: number[]) {
  const suma = pesos.reduce((s, n) => s + n, 0);
  const exactos = pesos.map((peso) => suma ? centavos * peso / suma : centavos / Math.max(1, pesos.length));
  const valores = exactos.map(Math.floor);
  const orden = exactos.map((n, i) => ({ i, resto: n - (valores[i] ?? 0) })).sort((a, b) => b.resto - a.resto);
  let restante = centavos - valores.reduce((s, n) => s + n, 0);
  for (const { i } of orden) {
    if (restante <= 0) break;
    valores[i] = (valores[i] ?? 0) + 1;
    restante--;
  }
  return valores;
}

export function calcularPedidoGrupal(carrito: CarritoItem[], personas: PersonaGrupo[], asignaciones: Record<string, string>, total: number): PedidoGrupal {
  const subtotales = personas.map(() => 0);
  const unidades = unidadesCarrito(carrito).map((unidad) => {
    const asignado = asignaciones[unidad.clave];
    const indice = personas.findIndex((p) => p.id === asignado);
    const compartido = indice < 0;
    const centavos = Math.round(unidad.precio * 100);
    if (compartido) repartir(centavos, personas.map(() => 1)).forEach((monto, i) => { subtotales[i] = (subtotales[i] ?? 0) + monto; });
    else subtotales[indice] = (subtotales[indice] ?? 0) + centavos;
    return { ...unidad, persona_id: compartido ? null : asignado ?? null, compartido };
  });
  const totales = repartir(Math.round(total * 100), subtotales);
  return {
    version: 1, unidades,
    personas: personas.map((persona, i) => ({ ...persona, nombre: persona.nombre.trim(), subtotal: (subtotales[i] ?? 0) / 100, descuento: ((subtotales[i] ?? 0) - (totales[i] ?? 0)) / 100, total: (totales[i] ?? 0) / 100 })),
  };
}

export function montoPorMetodo(pedido: Pedido, metodo: "EFECTIVO" | "TRANSFERENCIA") {
  if (pedido.pedido_grupal?.personas.length) return pedido.pedido_grupal.personas.filter((p) => p.metodo_pago === metodo).reduce((s, p) => s + Number(p.total), 0);
  return pedido.metodo_pago === metodo ? Number(pedido.total) : 0;
}