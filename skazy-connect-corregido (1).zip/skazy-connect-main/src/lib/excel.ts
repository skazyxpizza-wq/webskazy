import ExcelJS from "exceljs";
import type { Pedido } from "./types";

const COLORES: Record<string, string> = {
  CLIENTE: "FFFFE08A",
  COCINA: "FFFFC078",
  ENVIOS: "FF8FD3FE",
  ENTREGADO: "FF9BE9A8",
  CANCELADO: "FFFFA8A8",
};

export function crearLibroPedidos(pedidos: Pedido[]) {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("Pedidos");

  ws.columns = [
    { header: "Código", key: "codigo", width: 12 },
    { header: "Nombre", key: "nombre", width: 22 },
    { header: "Teléfono", key: "telefono", width: 16 },
    { header: "Detalle", key: "detalle", width: 48 },
    { header: "Subtotal", key: "subtotal", width: 14 },
    { header: "Descuento %", key: "porcentaje", width: 13 },
    { header: "Monto descuento", key: "descuento", width: 16 },
    { header: "Monto total", key: "total", width: 14 },
    { header: "Método de pago", key: "pago", width: 16 },
    { header: "Fecha", key: "fecha", width: 12 },
    { header: "Hora", key: "hora", width: 10 },
    { header: "Estado", key: "estado", width: 14 },
    { header: "Pedido grupal", key: "grupo", width: 60 },
  ];
  ws.getRow(1).font = { bold: true };
  ws.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF2B2B2B" } };
  ws.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };

  pedidos.forEach((p) => {
    const fecha = new Date(p.created_at);
    const row = ws.addRow({
      codigo: p.grupo_codigo || p.codigo,
      nombre: p.cliente_nombre,
      telefono: p.telefono,
      detalle: (p.pedido_items ?? []).map((i) => `${i.cantidad}x ${i.nombre}`).join(" | "),
      subtotal: Number(p.subtotal),
      porcentaje: Number(p.descuento_porcentaje),
      descuento: Number(p.monto_descuento),
      total: Number(p.total),
      pago: p.metodo_pago,
      fecha: fecha.toLocaleDateString("es-AR"),
      hora: fecha.toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" }),
      estado: p.estado,
      grupo: p.pedido_grupal?.personas.map((persona) => `${persona.nombre}: ${persona.total} (${persona.metodo_pago})`).join(" | ") ?? "",
    });
    row.getCell("estado").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: COLORES[p.estado] ?? "FFEEEEEE" },
    };
    // Guardar el importe real, no una fórmula sin resultado calculado.
    row.getCell("total").value = Number(p.total);
    ["subtotal", "descuento", "total"].forEach((k) => {
      row.getCell(k).numFmt = '"$"#,##0';
    });
  });

  const primera = 2;
  const ultima = ws.rowCount;
  const totales = ws.addRow({
    nombre: "TOTALES",
    subtotal: pedidos.reduce((s, p) => s + Number(p.subtotal), 0),
    descuento: pedidos.reduce((s, p) => s + Number(p.monto_descuento), 0),
    total: pedidos.reduce((s, p) => s + Number(p.total), 0),
  });
  totales.font = { bold: true };
  ["subtotal", "descuento", "total"].forEach((k) => {
    totales.getCell(k).numFmt = '"$"#,##0';
  });

  const promedio = ws.addRow({
    nombre: "TICKET PROMEDIO",
    total: pedidos.length ? pedidos.reduce((s, p) => s + Number(p.total), 0) / pedidos.length : 0,
  });
  promedio.font = { italic: true };
  promedio.getCell("total").numFmt = '"$"#,##0';

  return wb;
}

export async function exportarPedidosExcel(pedidos: Pedido[]) {
  const buffer = await crearLibroPedidos(pedidos).xlsx.writeBuffer();
  const blob = new Blob([new Uint8Array(buffer)], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `pedidos-skazy-${new Date().toISOString().slice(0, 10)}.xlsx`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
