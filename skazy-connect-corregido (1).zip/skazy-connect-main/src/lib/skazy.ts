import type { Config, ConfigZona, Estado, Pedido } from "./types";

export const ESTADOS: Estado[] = ["CLIENTE", "COCINA", "ENVIOS", "ENTREGADO"];

export const CONFIG_FALLBACK: Config = {
  cocina: { activa: false },
  general: {
    nombre_local: "SKAZY",
    whatsapp: "5493812119906",
    sucursales_texto: "🚚 SUCURSALES SOLO CON ENVIOS",
    texto_confianza: "Pago seguro · Entrega estimada · Sin costos ocultos",
    aviso_checkout: "⚠️ Completá Nombre, Domicilio, Forma de pago y Tel/Celular antes de enviar.",
    texto_zona: "El vendedor determinará si llegamos a tu zona con el envío seleccionado.",
    texto_vuelto:
      "Indicale al vendedor el monto con el que vas a pagar para que pueda preparar el cambio.",
    texto_final: "cuenta con nosotros, siempre te atenderemos con el corazón en Skazy",
    tiempo_lun_jue: "20 min – 40 min aprox.",
    tiempo_vie_dom: "35 min – 45 min aprox.",
    texto_dudas_tiempo: "💬 ¿Dudas sobre el tiempo de entrega? Consultá con el vendedor",
    abierto: true,
    horarios: "Lun a Dom de 19:00 a 00:30",
    urgencia_texto: "⚡ Pedidos limitados por horario",
    tutorial_activo: true,
  },
  zona: {
    modo: "radio",
    radio_metros: 3000,
    lat_min: -26.761972,
    lat_max: -26.713999,
    lng_min: -65.271194,
    lng_max: -65.23375,
    mensaje_fuera: "Lo sentimos, por el momento no realizamos entregas en esta zona.",
    mensaje_dentro: "Ubicación confirmada. Realizamos entregas en esta zona.",
    sucursal_lat: -26.7333,
    sucursal_lng: -65.2615,
  },
  logos: { cantidad: 5, velocidad: 30, segundos: 20, activo: true },
  pagos: { alias: "SKAZY.PZ", titular: "Isaías Chaile", medio: "Mercado Pago", qr_url: "" },
};

/** Cobertura circular provisional o rectángulo, según configuración de Admin. */
export function dentroDeZona(lat: number, lng: number, zona: ConfigZona): boolean {
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return false;
  if (zona.modo === "radio") return distanciaKm({ lat, lng }, { lat: zona.sucursal_lat, lng: zona.sucursal_lng }) * 1000 <= (zona.radio_metros ?? 3000);
  const latMin = Math.min(zona.lat_min, zona.lat_max);
  const latMax = Math.max(zona.lat_min, zona.lat_max);
  const lngMin = Math.min(zona.lng_min, zona.lng_max);
  const lngMax = Math.max(zona.lng_min, zona.lng_max);
  return lat >= latMin && lat <= latMax && lng >= lngMin && lng <= lngMax;
}

export function money(n: number | null | undefined): string {
  const v = Number(n ?? 0);
  return "$" + v.toLocaleString("es-AR", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

export function fechaCorta(iso: string): string {
  return new Date(iso).toLocaleDateString("es-AR");
}

export function horaCorta(iso: string): string {
  return new Date(iso).toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" });
}

export function tiempoEstimadoHoy(cfg: Config): string {
  const d = new Date().getDay();
  const finDeSemana = d === 5 || d === 6 || d === 0;
  return finDeSemana ? cfg.general.tiempo_vie_dom : cfg.general.tiempo_lun_jue;
}

export function mensajeWhatsApp(pedido: Pedido, cfg: Config): string {
  const items = (pedido.pedido_items ?? [])
    .map((i) => `• ${i.cantidad} x ${i.nombre} — ${money(i.subtotal)}`)
    .join("\n");
  return [
    `*NUEVO PEDIDO ${pedido.codigo}*`,
    `Cliente: ${pedido.cliente_nombre}`,
    `Tel: ${pedido.telefono}`,
    `Domicilio: ${pedido.domicilio}`,
    pedido.lat != null ? `Ubicación: https://maps.google.com/?q=${pedido.lat},${pedido.lng}` : "",
    "",
    "*PEDIDO*",
    items,
    "",
    `Subtotal: ${money(pedido.subtotal)}`,
    pedido.monto_descuento > 0
      ? `Descuento (${pedido.descuento_porcentaje}%): -${money(pedido.monto_descuento)}`
      : "",
    `*TOTAL: ${money(pedido.total)}*`,
    `Pago: ${pedido.metodo_pago}${pedido.paga_con ? ` (paga con ${money(pedido.paga_con)})` : ""}`,
    ...(pedido.pedido_grupal ? [
      "*DESGLOSE DEL PEDIDO GRUPAL*",
      ...pedido.pedido_grupal.personas.flatMap((persona) => [
        `*${persona.nombre}*`,
        ...pedido.pedido_grupal?.unidades.filter((u) => u.compartido || u.persona_id === persona.id).map((u) => `• 1 x ${u.nombre}${u.compartido ? " (a dividir entre todos)" : ""}`) ?? [],
        `Subtotal: ${money(persona.subtotal)} · Descuento: ${money(persona.descuento)}`,
        `Total: ${money(persona.total)} · ${persona.metodo_pago}${persona.paga_con != null ? ` · Abona con ${money(persona.paga_con)} · Vuelto ${money(persona.paga_con - persona.total)}` : ""}`,
      ]),
    ] : []),
    `Demora estimada: ${tiempoEstimadoHoy(cfg)}`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function mensajeCancelacion(pedido: Pedido): string {
  return `*CANCELACIÓN DE PEDIDO ${pedido.codigo}*\nCliente: ${pedido.cliente_nombre}\nTel: ${pedido.telefono}\nEl cliente canceló el pedido desde la aplicación.`;
}

export function abrirWhatsApp(numero: string, texto: string) {
  const url = `https://wa.me/${numero.replace(/\D/g, "")}?text=${encodeURIComponent(texto)}`;
  window.open(url, "_blank");
}

/* ---------- almacenamiento local (sin cuentas) ---------- */

const KEY_PEDIDOS = "skazy_mis_pedidos";
const KEY_FAVS = "skazy_favoritos";
const KEY_TUTORIAL = "skazy_tutorial_visto";

export function leerLocal<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function guardarLocal(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(value));
}

export const misPedidosIds = () => leerLocal<string[]>(KEY_PEDIDOS, []);
export const agregarMiPedido = (id: string) =>
  guardarLocal(KEY_PEDIDOS, Array.from(new Set([id, ...misPedidosIds()])));
export const favoritos = () => leerLocal<string[]>(KEY_FAVS, []);
export const guardarFavoritos = (ids: string[]) => guardarLocal(KEY_FAVS, ids);
export const tutorialVisto = () => leerLocal<boolean>(KEY_TUTORIAL, false);
export const marcarTutorialVisto = () => guardarLocal(KEY_TUTORIAL, true);

export const KEYS = { KEY_PEDIDOS, KEY_FAVS, KEY_TUTORIAL };

/* ---------- sonido de notificación (4 segundos) ---------- */
export function sonarAviso(segundos = 4) {
  if (typeof window === "undefined") return;
  try {
    const Ctx =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    const gain = ctx.createGain();
    gain.gain.value = 0.12;
    gain.connect(ctx.destination);
    const start = ctx.currentTime;
    for (let i = 0; i < segundos * 2; i++) {
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = i % 2 === 0 ? 880 : 660;
      osc.connect(gain);
      osc.start(start + i * 0.5);
      osc.stop(start + i * 0.5 + 0.35);
    }
    setTimeout(() => void ctx.close(), (segundos + 1) * 1000);
  } catch {
    /* sin audio disponible */
  }
}

export function hablar(texto: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  const u = new SpeechSynthesisUtterance(texto);
  u.lang = "es-AR";
  window.speechSynthesis.speak(u);
}

export function distanciaKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1 = (a.lat * Math.PI) / 180;
  const lat2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Ordena paradas por vecino más cercano desde el origen (recorrido eficiente). */
export function ordenarRuta<T extends { lat: number | null; lng: number | null }>(
  origen: { lat: number; lng: number },
  paradas: T[],
): T[] {
  const pendientes = paradas.filter((p) => p.lat != null && p.lng != null);
  const sinCoord = paradas.filter((p) => p.lat == null || p.lng == null);
  const ruta: T[] = [];
  let actual = origen;
  while (pendientes.length) {
    let mejor = 0;
    let mejorD = Infinity;
    pendientes.forEach((p, i) => {
      const d = distanciaKm(actual, { lat: p.lat as number, lng: p.lng as number });
      if (d < mejorD) {
        mejorD = d;
        mejor = i;
      }
    });
    const [elegido] = pendientes.splice(mejor, 1);
    ruta.push(elegido!);
    actual = { lat: elegido!.lat as number, lng: elegido!.lng as number };
  }
  return [...ruta, ...sinCoord];
}
