import { supabase } from "@/integrations/supabase/client";
import { CONFIG_FALLBACK } from "./skazy";
import type {
  Anuncio,
  Cadete,
  Categoria,
  CodigoDescuento,
  Config,
  LogoCategoria,
  Pedido,
  Producto,
  StockItem,
} from "./types";

export async function fetchAnuncios(): Promise<Anuncio[]> {
  const { data, error } = await supabase.from("anuncios").select("*").order("orden");
  if (error) throw error;
  return (data ?? []) as Anuncio[];
}

export async function fetchConfig(): Promise<Config> {
  const { data } = await supabase.from("configuracion_general").select("clave, valor");
  const map = new Map((data ?? []).map((r) => [r.clave as string, r.valor as object]));
  return {
    cocina: { ...CONFIG_FALLBACK.cocina, ...(map.get("cocina") ?? {}) },
    general: { ...CONFIG_FALLBACK.general, ...(map.get("general") ?? {}) },
    zona: { ...CONFIG_FALLBACK.zona, ...(map.get("zona") ?? {}) },
    logos: { ...CONFIG_FALLBACK.logos, ...(map.get("logos") ?? {}) },
    pagos: { ...CONFIG_FALLBACK.pagos, ...(map.get("pagos") ?? {}) },
  } as Config;
}

export async function guardarConfig(clave: string, valor: unknown) {
  const { error } = await supabase
    .from("configuracion_general")
    .upsert(
      { clave, valor: valor as never, updated_at: new Date().toISOString() },
      { onConflict: "clave" },
    );
  if (error) throw error;
}

export async function fetchCategorias(): Promise<Categoria[]> {
  const { data, error } = await supabase.from("categorias").select("*").order("orden");
  if (error) throw error;
  return (data ?? []) as Categoria[];
}

export async function fetchProductos(): Promise<Producto[]> {
  const { data, error } = await supabase.from("productos").select("*").order("orden");
  if (error) throw error;
  return (data ?? []).map((row) => ({
    ...row,
    grupos_modificadores: Array.isArray(row.grupos_modificadores) ? row.grupos_modificadores : [],
    sugeridos_ids: row.sugeridos_ids ?? [],
  })) as unknown as Producto[];
}

export async function fetchLogos(): Promise<LogoCategoria[]> {
  const { data, error } = await supabase.from("logos_categoria").select("*").order("orden");
  if (error) throw error;
  return (data ?? []) as LogoCategoria[];
}

export async function fetchCodigos(): Promise<CodigoDescuento[]> {
  const { data, error } = await supabase.from("codigos_descuento").select("*").order("codigo");
  if (error) throw error;
  return (data ?? []) as CodigoDescuento[];
}

export async function fetchCadetes(): Promise<Cadete[]> {
  const { data, error } = await supabase.from("cadetes").select("*").order("nombre");
  if (error) throw error;
  return (data ?? []) as Cadete[];
}

export async function fetchStock(): Promise<StockItem[]> {
  const { data, error } = await supabase.from("stock").select("*").order("orden");
  if (error) throw error;
  return (data ?? []) as StockItem[];
}

const PEDIDO_SELECT = "*, pedido_items(*)";

export async function fetchPedidos(estados?: string[]): Promise<Pedido[]> {
  let q = supabase.from("pedidos").select(PEDIDO_SELECT).order("created_at", { ascending: false });
  if (estados?.length) q = q.in("estado", estados);
  const { data, error } = await q;
  if (error) throw error;
  return (data ?? []) as unknown as Pedido[];
}

export async function fetchPedidosPorIds(ids: string[]): Promise<Pedido[]> {
  if (!ids.length) return [];
  const { data, error } = await supabase
    .from("pedidos")
    .select(PEDIDO_SELECT)
    .in("id", ids)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as Pedido[];
}

export async function cambiarEstado(id: string, estado: string, extra: object = {}) {
  const { error } = await supabase.from("pedidos").update({ estado, ...extra }).eq("id", id);
  if (error) throw error;
}

export async function verificarAcceso(sector: string, password: string): Promise<boolean> {
  const { data, error } = await supabase.rpc("verificar_acceso", {
    _sector: sector,
    _password: password,
  });
  if (error) throw error;
  return Boolean(data);
}

export async function cambiarAcceso(adminPass: string, sector: string, nueva: string) {
  const { data, error } = await supabase.rpc("cambiar_acceso", {
    _admin_password: adminPass,
    _sector: sector,
    _nueva: nueva,
  });
  if (error) throw error;
  return Boolean(data);
}
