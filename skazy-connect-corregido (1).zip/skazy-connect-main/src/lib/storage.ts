import { supabase } from "@/integrations/supabase/client";
import { optimizarImagenBlob } from "@/lib/image";

export const BUCKET_IMAGENES = "skazy";

/** Optimiza la imagen, la sube a Supabase Storage y devuelve su URL pública (liviana, sin base64). */
export async function subirImagen(
  file: File,
  carpeta: string,
  maxWidth = 1400,
  tipo: "image/webp" | "image/png" = "image/webp",
): Promise<string> {
  const blob = await optimizarImagenBlob(file, maxWidth, tipo);
  const extension = tipo === "image/png" ? "png" : "webp";
  const ruta = `${carpeta}/${crypto.randomUUID()}.${extension}`;
  const { error } = await supabase.storage
    .from(BUCKET_IMAGENES)
    .upload(ruta, blob, { contentType: tipo, cacheControl: "31536000", upsert: false });
  if (error) {
    throw new Error(
      `No se pudo subir la imagen (${error.message}). Verifique que exista el bucket público "${BUCKET_IMAGENES}" en Supabase Storage.`,
    );
  }
  return supabase.storage.from(BUCKET_IMAGENES).getPublicUrl(ruta).data.publicUrl;
}
