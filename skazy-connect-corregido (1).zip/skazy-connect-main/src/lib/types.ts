export type Estado = "CLIENTE" | "COCINA" | "ENVIOS" | "ENTREGADO" | "CANCELADO";

export interface Categoria {
  id: string;
  nombre: string;
  orden: number;
  visible: boolean;
  logo_url: string | null;
}

export interface Producto {
  id: string;
  categoria_id: string | null;
  nombre: string;
  descripcion: string | null;
  descripcion_detallada: string;
  grupos_modificadores: GrupoModificador[];
  sugeridos_ids: string[];
  precio: number;
  imagen_url: string | null;
  imagen_hover_url: string | null;
  orden: number;
  visible: boolean;
  agotado: boolean;
  destacado: boolean;
  mas_vendido: boolean;
}

export interface OpcionModificador {
  id: string;
  nombre: string;
  precio: number;
}

export interface GrupoModificador {
  id: string;
  nombre: string;
  obligatorio: boolean;
  opciones: OpcionModificador[];
}

export interface SeleccionModificador {
  grupo: string;
  opcion: string;
  precio: number;
}

export interface Cadete {
  id: string;
  nombre: string;
  telefono: string | null;
  activo: boolean;
  lat: number | null;
  lng: number | null;
  ubicacion_at: string | null;
}

export interface CodigoDescuento {
  id: string;
  codigo: string;
  porcentaje: number;
  activo: boolean;
  expira_at: string | null;
}

export interface Pedido {
  pedido_grupal?: PedidoGrupal | null;
  id: string;
  codigo: string;
  cliente_nombre: string;
  telefono: string;
  domicilio: string;
  lat: number | null;
  lng: number | null;
  metodo_pago: string;
  paga_con: number | null;
  subtotal: number;
  codigo_descuento: string | null;
  descuento_porcentaje: number;
  monto_descuento: number;
  total: number;
  monto_recibido: number | null;
  vuelto: number | null;
  estado: Estado;
  cadete_id: string | null;
  grupo_codigo: string | null;
  notas: string | null;
  cancelado_motivo: string | null;
  entregado_at: string | null;
  created_at: string;
  updated_at: string;
  pedido_items?: PedidoItem[];
}

export interface PedidoItem {
  id: string;
  pedido_id: string;
  producto_id: string | null;
  nombre: string;
  cantidad: number;
  precio_unitario: number;
  subtotal: number;
  opciones?: SeleccionModificador[];
}

export interface Anuncio {
  id: string;
  titulo: string;
  imagen_url: string | null;
  tamano: "chico" | "mediano" | "grande";
  tiene_boton: boolean;
  boton_texto: string;
  destino_tipo: "producto" | "categoria" | "link";
  destino: string | null;
  activo: boolean;
  orden: number;
  created_at: string;
  updated_at: string;
}

export interface LogoCategoria {
  id: string;
  categoria_id: string | null;
  titulo: string;
  imagen_url: string | null;
  orden: number;
  activo: boolean;
}

export interface StockItem {
  id: string;
  ingrediente: string;
  disponible: boolean;
  aviso: string | null;
  orden: number;
}

export interface ConfigGeneral {
  nombre_local: string;
  whatsapp: string;
  sucursales_texto: string;
  texto_confianza: string;
  aviso_checkout: string;
  texto_zona: string;
  texto_vuelto: string;
  texto_final: string;
  tiempo_lun_jue: string;
  tiempo_vie_dom: string;
  texto_dudas_tiempo: string;
  abierto: boolean;
  horarios: string;
  urgencia_texto: string;
  tutorial_activo: boolean;
}

export interface ConfigZona {
  modo?: "radio" | "rectangulo";
  radio_metros?: number;
  lat_min: number;
  lat_max: number;
  lng_min: number;
  lng_max: number;
  mensaje_fuera: string;
  mensaje_dentro: string;
  sucursal_lat: number;
  sucursal_lng: number;
}

export interface ConfigLogos {
  cantidad: number;
  velocidad: number;
  segundos: number;
  activo: boolean;
}

export interface ConfigPagos {
  alias: string;
  titular: string;
  medio: string;
  qr_url: string;
}

export interface ConfigCocina {
  activa: boolean;
}

export interface Config {
  cocina: ConfigCocina;
  general: ConfigGeneral;
  zona: ConfigZona;
  logos: ConfigLogos;
  pagos: ConfigPagos;
}

export interface CarritoItem {
  clave?: string;
  producto_id: string;
  nombre: string;
  precio: number;
  cantidad: number;
  imagen_url: string | null;
  opciones?: SeleccionModificador[];
}

export interface PersonaGrupo {
  id: string;
  nombre: string;
  metodo_pago: "EFECTIVO" | "TRANSFERENCIA";
  paga_con: number | null;
}

export interface PedidoGrupal {
  version: 1;
  personas: (PersonaGrupo & { subtotal: number; descuento: number; total: number })[];
  unidades: { clave: string; nombre: string; precio: number; persona_id: string | null; compartido: boolean }[];
}
