export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      accesos_sectores: {
        Row: {
          password: string
          sector: string
          updated_at: string
        }
        Insert: {
          password: string
          sector: string
          updated_at?: string
        }
        Update: {
          password?: string
          sector?: string
          updated_at?: string
        }
        Relationships: []
      }
      anuncios: {
        Row: {
          activo: boolean
          boton_texto: string
          created_at: string
          destino: string | null
          destino_tipo: string
          id: string
          imagen_url: string | null
          orden: number
          tamano: string
          tiene_boton: boolean
          titulo: string
          updated_at: string
        }
        Insert: {
          activo?: boolean
          boton_texto?: string
          created_at?: string
          destino?: string | null
          destino_tipo?: string
          id?: string
          imagen_url?: string | null
          orden?: number
          tamano?: string
          tiene_boton?: boolean
          titulo?: string
          updated_at?: string
        }
        Update: {
          activo?: boolean
          boton_texto?: string
          created_at?: string
          destino?: string | null
          destino_tipo?: string
          id?: string
          imagen_url?: string | null
          orden?: number
          tamano?: string
          tiene_boton?: boolean
          titulo?: string
          updated_at?: string
        }
        Relationships: []
      }
      banners: {
        Row: {
          activo: boolean
          banner_alto: number
          created_at: string
          descripcion: string | null
          descripcion_tamano: number
          destino: string | null
          expira_at: string | null
          id: string
          imagen_url: string | null
          orden: number
          titulo: string | null
          titulo_tamano: number
        }
        Insert: {
          activo?: boolean
          banner_alto?: number
          created_at?: string
          descripcion?: string | null
          descripcion_tamano?: number
          destino?: string | null
          expira_at?: string | null
          id?: string
          imagen_url?: string | null
          orden?: number
          titulo?: string | null
          titulo_tamano?: number
        }
        Update: {
          activo?: boolean
          banner_alto?: number
          created_at?: string
          descripcion?: string | null
          descripcion_tamano?: number
          destino?: string | null
          expira_at?: string | null
          id?: string
          imagen_url?: string | null
          orden?: number
          titulo?: string | null
          titulo_tamano?: number
        }
        Relationships: []
      }
      cadetes: {
        Row: {
          activo: boolean
          created_at: string
          id: string
          lat: number | null
          lng: number | null
          nombre: string
          telefono: string | null
          ubicacion_at: string | null
        }
        Insert: {
          activo?: boolean
          created_at?: string
          id?: string
          lat?: number | null
          lng?: number | null
          nombre: string
          telefono?: string | null
          ubicacion_at?: string | null
        }
        Update: {
          activo?: boolean
          created_at?: string
          id?: string
          lat?: number | null
          lng?: number | null
          nombre?: string
          telefono?: string | null
          ubicacion_at?: string | null
        }
        Relationships: []
      }
      categorias: {
        Row: {
          created_at: string
          id: string
          logo_url: string | null
          nombre: string
          orden: number
          visible: boolean
        }
        Insert: {
          created_at?: string
          id?: string
          logo_url?: string | null
          nombre: string
          orden?: number
          visible?: boolean
        }
        Update: {
          created_at?: string
          id?: string
          logo_url?: string | null
          nombre?: string
          orden?: number
          visible?: boolean
        }
        Relationships: []
      }
      codigos_descuento: {
        Row: {
          activo: boolean
          codigo: string
          created_at: string
          expira_at: string | null
          id: string
          porcentaje: number
        }
        Insert: {
          activo?: boolean
          codigo: string
          created_at?: string
          expira_at?: string | null
          id?: string
          porcentaje?: number
        }
        Update: {
          activo?: boolean
          codigo?: string
          created_at?: string
          expira_at?: string | null
          id?: string
          porcentaje?: number
        }
        Relationships: []
      }
      configuracion_general: {
        Row: {
          clave: string
          updated_at: string
          valor: Json
        }
        Insert: {
          clave: string
          updated_at?: string
          valor?: Json
        }
        Update: {
          clave?: string
          updated_at?: string
          valor?: Json
        }
        Relationships: []
      }
      logos_categoria: {
        Row: {
          activo: boolean
          categoria_id: string | null
          created_at: string
          id: string
          imagen_url: string | null
          orden: number
          titulo: string | null
        }
        Insert: {
          activo?: boolean
          categoria_id?: string | null
          created_at?: string
          id?: string
          imagen_url?: string | null
          orden?: number
          titulo?: string | null
        }
        Update: {
          activo?: boolean
          categoria_id?: string | null
          created_at?: string
          id?: string
          imagen_url?: string | null
          orden?: number
          titulo?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "logos_categoria_categoria_id_fkey"
            columns: ["categoria_id"]
            isOneToOne: false
            referencedRelation: "categorias"
            referencedColumns: ["id"]
          },
        ]
      }
      pedido_items: {
        Row: {
          cantidad: number
          created_at: string
          id: string
          nombre: string
          opciones: Json
          pedido_id: string
          precio_unitario: number
          producto_id: string | null
          subtotal: number
        }
        Insert: {
          cantidad?: number
          created_at?: string
          id?: string
          nombre: string
          opciones?: Json
          pedido_id: string
          precio_unitario?: number
          producto_id?: string | null
          subtotal?: number
        }
        Update: {
          cantidad?: number
          created_at?: string
          id?: string
          nombre?: string
          opciones?: Json
          pedido_id?: string
          precio_unitario?: number
          producto_id?: string | null
          subtotal?: number
        }
        Relationships: [
          {
            foreignKeyName: "pedido_items_pedido_id_fkey"
            columns: ["pedido_id"]
            isOneToOne: false
            referencedRelation: "pedidos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pedido_items_producto_id_fkey"
            columns: ["producto_id"]
            isOneToOne: false
            referencedRelation: "productos"
            referencedColumns: ["id"]
          },
        ]
      }
      pedidos: {
        Row: {
          cadete_id: string | null
          cancelado_motivo: string | null
          cliente_nombre: string
          codigo: string
          codigo_descuento: string | null
          created_at: string
          descuento_porcentaje: number
          domicilio: string
          entregado_at: string | null
          estado: string
          grupo_codigo: string | null
          id: string
          lat: number | null
          lng: number | null
          metodo_pago: string
          monto_descuento: number
          monto_recibido: number | null
          notas: string | null
          paga_con: number | null
          pedido_grupal: Json | null
          subtotal: number
          telefono: string
          total: number
          updated_at: string
          vuelto: number | null
        }
        Insert: {
          cadete_id?: string | null
          cancelado_motivo?: string | null
          cliente_nombre: string
          codigo: string
          codigo_descuento?: string | null
          created_at?: string
          descuento_porcentaje?: number
          domicilio: string
          entregado_at?: string | null
          estado?: string
          grupo_codigo?: string | null
          id?: string
          lat?: number | null
          lng?: number | null
          metodo_pago?: string
          monto_descuento?: number
          monto_recibido?: number | null
          notas?: string | null
          paga_con?: number | null
          pedido_grupal?: Json | null
          subtotal?: number
          telefono: string
          total?: number
          updated_at?: string
          vuelto?: number | null
        }
        Update: {
          cadete_id?: string | null
          cancelado_motivo?: string | null
          cliente_nombre?: string
          codigo?: string
          codigo_descuento?: string | null
          created_at?: string
          descuento_porcentaje?: number
          domicilio?: string
          entregado_at?: string | null
          estado?: string
          grupo_codigo?: string | null
          id?: string
          lat?: number | null
          lng?: number | null
          metodo_pago?: string
          monto_descuento?: number
          monto_recibido?: number | null
          notas?: string | null
          paga_con?: number | null
          pedido_grupal?: Json | null
          subtotal?: number
          telefono?: string
          total?: number
          updated_at?: string
          vuelto?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "pedidos_cadete_id_fkey"
            columns: ["cadete_id"]
            isOneToOne: false
            referencedRelation: "cadetes"
            referencedColumns: ["id"]
          },
        ]
      }
      productos: {
        Row: {
          agotado: boolean
          categoria_id: string | null
          created_at: string
          descripcion: string | null
          descripcion_detallada: string
          destacado: boolean
          grupos_modificadores: Json
          id: string
          imagen_hover_url: string | null
          imagen_url: string | null
          mas_vendido: boolean
          nombre: string
          orden: number
          precio: number
          sugeridos_ids: string[]
          visible: boolean
        }
        Insert: {
          agotado?: boolean
          categoria_id?: string | null
          created_at?: string
          descripcion?: string | null
          descripcion_detallada?: string
          destacado?: boolean
          grupos_modificadores?: Json
          id?: string
          imagen_hover_url?: string | null
          imagen_url?: string | null
          mas_vendido?: boolean
          nombre: string
          orden?: number
          precio?: number
          sugeridos_ids?: string[]
          visible?: boolean
        }
        Update: {
          agotado?: boolean
          categoria_id?: string | null
          created_at?: string
          descripcion?: string | null
          descripcion_detallada?: string
          destacado?: boolean
          grupos_modificadores?: Json
          id?: string
          imagen_hover_url?: string | null
          imagen_url?: string | null
          mas_vendido?: boolean
          nombre?: string
          orden?: number
          precio?: number
          sugeridos_ids?: string[]
          visible?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "productos_categoria_id_fkey"
            columns: ["categoria_id"]
            isOneToOne: false
            referencedRelation: "categorias"
            referencedColumns: ["id"]
          },
        ]
      }
      stock: {
        Row: {
          aviso: string | null
          created_at: string
          disponible: boolean
          id: string
          ingrediente: string
          orden: number
        }
        Insert: {
          aviso?: string | null
          created_at?: string
          disponible?: boolean
          id?: string
          ingrediente: string
          orden?: number
        }
        Update: {
          aviso?: string | null
          created_at?: string
          disponible?: boolean
          id?: string
          ingrediente?: string
          orden?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      cambiar_acceso: {
        Args: { _admin_password: string; _nueva: string; _sector: string }
        Returns: boolean
      }
      verificar_acceso: {
        Args: { _password: string; _sector: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
