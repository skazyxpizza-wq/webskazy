# Rediseño del sector Cliente y anuncios configurables

## Alcance
- Rediseñar exclusivamente el menú, carrito, checkout y tutorial del sector Cliente.
- Mantener sin cambios visuales Cocina, Envíos y el panel de Admin.
- En Admin, agregar sólo la sección funcional **Anuncios / Ventanas Emergentes**.
- Descartar por completo las propuestas anteriores y no reutilizar su composición.

## Menú Cliente
- Aplicar fondo crema, texto negro y rojo reservado para precios, badges y acciones principales, con Bebas Neue y Barlow.
- Reorganizar el catálogo como recorrido editorial: Promos y Combos en piezas inmersivas de ancho completo; Pizzas y Empanadas en tarjetas amplias con fotografía protagonista.
- Mantener búsqueda, favoritos, categorías, banners, logos, disponibilidad, carrito, descuentos, pagos, mapa, seguimiento y envío del pedido.
- Reforzar el indicador abierto/cerrado, el badge “Más vendido” y el bloque de confianza del checkout.
- Asegurar controles táctiles cómodos y composición mobile-first, ampliándose correctamente en tablet y escritorio.

## Movimiento e interacción
- Incorporar entrada inicial tipo escalones, revelado de imágenes y secciones al hacer scroll, tarjetas con profundidad 3D y apilado visual durante el recorrido.
- Mantener el producto girando lentamente; durante hover o contacto, detenerlo y hacer emerger la segunda imagen desde abajo hasta retirarlo.
- Convertir el carrito flotante en una isla dinámica compacta con cantidad y total animados, expandible para editar cantidades.
- Respetar `prefers-reduced-motion` y evitar movimientos que dificulten tocar o leer.

## Anuncios emergentes
- Crear almacenamiento persistente para múltiples anuncios independientes con imagen, tamaño, botón opcional, texto, tipo de destino, destino, orden y estado activo.
- Configurar un espacio para subir imágenes desde Admin, además de permitir gestionar cada anuncio: crear, editar, activar/desactivar y eliminar.
- Mostrar anuncios activos en Cliente de forma secuencial, con entrada rápida tipo “whoosh”, cierre automático a los 10 segundos y cierre manual con X más animación de salida.
- Resolver destinos hacia producto, categoría o enlace externo sin romper la navegación del menú.

## Tutorial profesional
- Identificar cada objetivo real mediante marcadores estables en búsqueda, categorías, favoritos, producto, carrito y seguimiento.
- Reemplazar el fondo borroso por cuatro áreas oscuras alrededor del objetivo, dejando un recorte nítido y destacado.
- Posicionar la explicación y la flecha según el espacio disponible, recalculando ante scroll o cambio de tamaño.
- Conservar avance, omisión y finalización, con áreas táctiles amplias.

## Validación
- Verificar datos, alta y edición de anuncios, carga de imagen, activación y destinos.
- Probar en celular, tablet y escritorio el menú, tutorial, anuncio, carrito y checkout.
- Confirmar entrada/salida de anuncios, temporizador, animaciones, ausencia de solapamientos y funcionamiento con movimiento reducido.
- Revisar compilación, errores de pantalla y consola antes de finalizar.

## Detalles técnicos
- Añadir una tabla pública de anuncios con permisos explícitos, reglas de acceso y publicación en tiempo real mediante una migración versionada.
- Añadir un bucket público limitado a imágenes para las cargas del panel.
- Mantener los nuevos estilos dentro de tokens semánticos y utilidades del sistema visual existente.
- No modificar la lógica operativa de Cocina, Envíos ni sus pantallas.
